#!/bin/bash

# Check if .env.example file exists
if [ ! -f "./src/.env.example" ]; then
    echo ".env.example file is missing. Exiting..."
    exit 0
fi

# Path to your .env.example file
ENV_EXAMPLE_FILE="./src/.env.example"

# Path to your Dockerfile
DOCKERFILE="./src/Dockerfile"


# Read all the keys from the .env.example file, ignoring comments and empty lines
KEYS=$(grep -v '^#' "$ENV_EXAMPLE_FILE" | grep -v '^$' | cut -d '=' -f 1)

echo 'FROM oven/bun:1.1.15-alpine AS runner' > $DOCKERFILE
echo '' >> $DOCKERFILE

# Append ARG statements for each key
for KEY in $KEYS; do
    echo "ARG $KEY" >> "$DOCKERFILE"
done

# Append ENV block, split across multiple lines
echo "ENV \\" >> "$DOCKERFILE"
for KEY in $KEYS; do
    echo "    $KEY=\${$KEY} \\" >> "$DOCKERFILE"
done

# Remove the trailing backslash from the last ENV line
sed -i '$ s/ \\$//' "$DOCKERFILE"

echo '' >> $DOCKERFILE
echo 'COPY . .' >> $DOCKERFILE
echo '' >> $DOCKERFILE
echo 'CMD ["bun", "run", "server.js"]' >> $DOCKERFILE


echo "Dockerfile has been updated with properly formatted ARG and ENV variables."
