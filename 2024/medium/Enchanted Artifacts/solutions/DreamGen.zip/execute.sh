# wite file
<src/Dockerfile
echo "FROM oven/bun:1.1.15-alpine AS runner" >src/Dockerfile
echo "COPY . /app" >>src/Dockerfile
echo "WORKDIR /app" >>src/Dockerfile


while IFS= read -r line || [[ -n "$line" ]]; do
    for encoded_str in $line; do
       new_line=$(echo $encoded_str | sed -e 's/=//g')
    echo "ARG $new_line" >>src/Dockerfile
    done
done <src/.env.example


while IFS= read -r line || [[ -n "$line" ]]; do
    for encoded_str in $line; do
        new_line=$(echo $encoded_str | sed -e 's/=//g')
        echo "ENV $encoded_str\$$new_line" >>src/Dockerfile
    done
done <src/.env.example

echo 'CMD ["bun", "run", "server.js"]' >>src/Dockerfile
