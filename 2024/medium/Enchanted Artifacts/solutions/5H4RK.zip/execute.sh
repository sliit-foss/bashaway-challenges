#!/bin/bash

# Check if .env.example file exists
if [ ! -f "./src/.env.example" ]; then
  echo ".env.example file is missing. Exiting."
  exit 0
fi

ARG_LINES=""
ENV_LINES=""

while IFS= read -r line || [[ -n $line ]]; do
    KEY=$(echo "$line" | cut -d '=' -f 1)

    ARG_LINES+="ARG $KEY\n"
    ENV_LINES+="ENV $KEY=\${$KEY}\n"
done < ./src/.env.example

{
  echo "FROM oven/bun:1.1.15-alpine AS runner"
  echo ""
  echo "COPY . ."
  echo ""
  echo -e "$ARG_LINES" 
  echo -e "$ENV_LINES"
  echo ""
  echo "EXPOSE 3000"
  echo ""
  echo "CMD [\"bun\", \"run\", \"server.js\"]"
} > ./src/Dockerfile