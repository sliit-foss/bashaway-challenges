#!/bin/bash

# Check if .env.example file exists
if [ ! -f "./src/.env.example" ]; then
  echo ".env.example file is missing"
fi

# Read the .env.example file and extract keys
keys=$(cat ./src/.env.example | grep -o '^[^=]*')

# Create a temporary Dockerfile with environment variables
cat <<EOF > ./src/Dockerfile.temp
# Use a base image with Bun installed
FROM oven/bun:latest

# Set the working directory
WORKDIR /app

# Copy the rest of the application code
COPY . .

# Copy the .env.example file
COPY .env.example ./

# Expose the application port
EXPOSE 3000

# Command to run the application
CMD ["bun", "run", "server.js"]
EOF

# Append environment variables to the temporary Dockerfile
for key in $keys; do
  echo "ARG $key" >> ./src/Dockerfile.temp
  echo "ENV $key=\$$key" >> ./src/Dockerfile.temp
done

# Append the original CMD to the temporary Dockerfile
cat <<EOF >> ./src/Dockerfile.temp
EXPOSE 3000
CMD ["node", "server.js"]
EOF

# Replace the original Dockerfile with the temporary one
mv ./src/Dockerfile.temp ./src/Dockerfile

# Remove any existing container with the same name
docker rm -f bashaway-2k24-enchanted-artifact &