#!/bin/bash

# Function to check if a command is successful
check_command() {
    if ! "$@"; then
        echo "Error: $1 failed." >&2
        exit 1
    fi
}

# Step 1: Install k3d if it is not installed
if ! command -v k3d &> /dev/null; then
    echo "Installing k3d..."
    curl -s https://raw.githubusercontent.com/rancher/k3d/main/install.sh | bash
else
    echo "k3d is already installed."
fi

# Step 2: Create a k3d cluster
echo "Creating a k3d cluster..."
check_command k3d cluster create mycluster

# Step 3: Set the current context to the new cluster
echo "Setting current context to the new k3d cluster..."
check_command kubectl config use-context k3d-mycluster

# Step 4: Create the "bashaway" namespace if it doesn't exist
echo "Creating namespace 'bashaway'..."
kubectl get namespace bashaway || kubectl create namespace bashaway

# Step 5: Create a Redis password secret
echo "Creating Redis password secret..."
redis_password="your_redis_password_here"  # Change this to your desired password
kubectl create secret generic redis --from-literal=redis-password="$redis_password" -n bashaway

# Step 6: Create a Redis deployment in the "bashaway" namespace
echo "Creating Redis deployment..."
cat <<EOF | kubectl apply -n bashaway -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:latest
        ports:
        - containerPort: 6379
        env:
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis
              key: redis-password
EOF

# Step 7: Expose the Redis deployment as a ClusterIP service
echo "Exposing Redis service as ClusterIP..."
cat <<EOF | kubectl apply -n bashaway -f -
apiVersion: v1
kind: Service
metadata:
  name: redis
spec:
  type: ClusterIP   # Keep the service type as ClusterIP
  ports:
  - port: 6379
    targetPort: 6379
    protocol: TCP
  selector:
    app: redis
EOF

echo "Redis service 'redis' is running in the 'bashaway' namespace."

# Step 8: Wait for the Redis pod to be in a running state
echo "Waiting for the Redis pod to be running..."
kubectl wait --for=condition=available --timeout=60s deployment/redis -n bashaway

# Step 9: Port forward to access Redis locally in the background
echo "Port forwarding Redis service to local port 6381..."
kubectl port-forward svc/redis 6381:6379 -n bashaway &

# Step 10: Disown the background process
disown

echo "Redis is now accessible on localhost:6381."
