#!/bin/bash
    minikube stop
    minikube start 

        kubectl config use-context minikube
        # Create the namespace bashaway if it doesn't already exist
        kubectl get ns bashaway > /dev/null 2>&1
        if [ $? -ne 0 ]; then
            echo "Creating namespace 'bashaway'..."
            kubectl create namespace bashaway
        fi

        # Create a Redis password secret if it doesn't already exist
        kubectl get secret redis -n bashaway > /dev/null 2>&1
        if [ $? -ne 0 ]; then
            echo "Creating Redis password secret..."
            kubectl create secret generic redis --from-literal=redis-password=redis123 -n bashaway
        fi

        # Deploy the Redis service and deployment in the bashaway namespace
        cat <<EOF | kubectl apply -n bashaway -f -
apiVersion: v1
kind: Service
metadata:
  name: redis
  namespace: bashaway
spec:
  ports:
  - port: 6381
    targetPort: 6379
    protocol: TCP
  selector:
    app: redis
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: bashaway
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:latest
        env:
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis
              key: redis-password
        args: ["--requirepass", "\$(REDIS_PASSWORD)"]
        ports:
        - containerPort: 6379
EOF

        # Wait until the Redis pod is running
        echo "Waiting for Redis pod to be in running state..."
        while [[ $(kubectl get pods -n bashaway -l app=redis -o 'jsonpath={..status.conditions[?(@.type=="Ready")].status}') != "True" ]]; do
            echo "Waiting for pod..."
            sleep 2
        done

        # Set up port-forwarding for Redis
        echo "Setting up port-forwarding for Redis on port 6381..."
        nohup kubectl port-forward svc/redis 6381:6381 -n bashaway > /dev/null 2>&1 &

        echo "Redis service is running and accessible on port 6381."