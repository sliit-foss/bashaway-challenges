#!/bin/bash

# Function to install necessary packages
install_packages() {
    echo "Installing required packages..."

    # Update package list and install necessary packages
    sudo apt-get update

    # Install Docker (if not installed)
    if ! command -v docker &> /dev/null; then
        echo "Installing Docker..."
        sudo apt-get install -y docker.io
        sudo systemctl start docker
        sudo systemctl enable docker
    else
        echo "Docker is already installed."
    fi

    # Install kubectl (if not installed)
    if ! command -v kubectl &> /dev/null; then
        echo "Installing kubectl..."
        sudo snap install kubectl --classic
    else
        echo "kubectl is already installed."
    fi

    # Install Minikube (if not installed)
    if ! command -v minikube &> /dev/null; then
        echo "Installing Minikube..."
        curl -Lo minikube https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
        sudo install minikube /usr/local/bin/
        rm minikube
    else
        echo "Minikube is already installed."
    fi

    echo "All required packages are installed."
}

# Call the function to install packages
install_packages

# Start Minikube if not already running
minikube status &> /dev/null
if [ $? -ne 0 ]; then
    echo "Starting Minikube..."
    minikube start
fi

# Set current context to Minikube
kubectl config use-context minikube

# Create bashaway namespace if not already exists
kubectl get namespace bashaway &> /dev/null
if [ $? -ne 0 ]; then
    echo "Creating namespace bashaway..."
    kubectl create namespace bashaway
fi

# Set Redis password
REDIS_PASSWORD="your_secure_password"

# Create a Kubernetes secret to store the Redis password
kubectl create secret generic redis --from-literal=redis-password="${REDIS_PASSWORD}" -n bashaway

# Create Redis Deployment and Service in bashaway namespace
cat <<EOF | kubectl apply -n bashaway -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:6.2
        ports:
        - containerPort: 6379
        env:
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis
              key: redis-password
        command: ["redis-server", "--requirepass", "$(REDIS_PASSWORD)"]
---
apiVersion: v1
kind: Service
metadata:
  name: redis
spec:
  selector:
    app: redis
  ports:
    - protocol: TCP
      port: 6379
      targetPort: 6379
EOF

# Wait for Redis to be ready
echo "Waiting for Redis to be ready..."
kubectl rollout status deployment/redis -n bashaway

# Forward the port 6381 to access Redis service
kubectl port-forward svc/redis 6381:6379 -n bashaway &
echo "Redis service is now available at port 6381."

# Exit script
exit 0
