#!/bin/bash
kubectl port-forward svc/redis 6381:6381 -n bashaway
