#!/bin/bash

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check if kubectl is installed
if ! command_exists kubectl; then
    exit 0
fi

# Check if minikube is installed
if ! command_exists minikube; then
    exit 0
fi

# Start minikube if it's not running
if ! minikube status | grep -q "Running"; then
    minikube start
    if [ $? -ne 0 ]; then
        exit 0
    fi
fi

# Set the current context to minikube
kubectl config use-context minikube

# Wait for the Kubernetes API to become available
echo "Waiting for the Kubernetes API to become available..."
while ! kubectl get nodes &>/dev/null; do
    sleep 5
done

# Create the bashaway namespace if it doesn't exist
echo "Checking for the bashaway namespace..."
if ! kubectl get namespace bashaway &> /dev/null; then
    kubectl create namespace bashaway
    if [ $? -eq 0 ]; then
        echo "Namespace 'bashaway' created successfully."
    else
        exit 0
    fi
else
    echo "Namespace 'bashaway' already exists."
fi

# Deploy Redis pod

cat << EOF | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: bashaway
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:alpine
        ports:
        - containerPort: 6379
EOF

# Check if the deployment was created
if kubectl get deployments -n bashaway | grep -q redis; then
    echo "Redis deployment created successfully."
else
    kubectl get pods -n bashaway
    kubectl describe deployment redis -n bashaway
    exit 0
fi

# Wait for the pod to be ready
echo "Waiting for our redis horse to settle in..."
timeout=2
while [ $timeout -gt 0 ]; do
    if kubectl get pods -n bashaway | grep -q Running; then
        echo "Redis pod is running!"
        break
    else
       
        sleep 5
        ((timeout--))
    fi
done

if [ $timeout -eq 0 ]; then
    echo "Failed to start the Redis pod within the timeout period."
    exit 1
fi

# Create a secret for Redis (optional, if you need a password)
echo "Creating secret for Redis..."
kubectl create secret generic redis --from-literal=redis-password=$(openssl rand -base64 12) -n bashaway
if [ $? -eq 0 ]; then
    echo "Secret for Redis created successfully."
else
    echo "Failed to create secret for Redis."
fi

# Expose Redis as a service
echo "Opening the village gate for our redis horse..."
cat << EOF | kubectl apply -f -
apiVersion: v1
kind: Service
metadata:
  name: redis
  namespace: bashaway
spec:
  selector:
    app: redis
  ports:
  - port: 6381
    targetPort: 6379
  type: NodePort
EOF



# Check if the service was created
if kubectl get svc -n bashaway | grep -q redis; then
    echo "Redis service created successfully."
else
    echo "Failed to create Redis service."
    exit 1
fi

kubectl port-forward svc/redis 6381:6381 -n bashaway &

./src/port_forward.sh &

sleep 5

# Capture the PID of the port-forwarding process
PF_PID=$!

# Give it a moment to start
sleep 5