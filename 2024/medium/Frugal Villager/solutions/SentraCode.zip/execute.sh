#!/bin/bash

# Exit if any command fails
set -e

# Step 1: Install k3d if not installed
if ! command -v k3d &> /dev/null; then
    echo "k3d is not installed. Installing k3d..."
    curl -s https://raw.githubusercontent.com/rancher/k3d/main/install.sh | bash
fi

# Step 2: Create a new k3d cluster named 'bashaway'
echo "Creating k3d cluster 'bashaway'..."
k3d cluster create bashaway

# Step 3: Set the current context to the new cluster
kubectl config use-context k3d-bashaway

# Step 4: Create the 'bashaway' namespace
echo "Creating 'bashaway' namespace..."
kubectl create namespace bashaway || echo "Namespace 'bashaway' already exists"

# Step 5: Create a secret for Redis (if needed)
echo "Creating Redis secret..."
kubectl create secret generic redis --from-literal=redis-password=mysecretpassword -n bashaway || echo "Secret 'redis' already exists"

# Step 6: Deploy Redis in 'bashaway' namespace
echo "Deploying Redis in 'bashaway' namespace..."
kubectl apply -n bashaway -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: bashaway
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:6.2
        ports:
        - containerPort: 6379
        env:
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis
              key: redis-password
EOF

# Step 7: Expose Redis as a service
kubectl expose deployment redis -n bashaway --type=ClusterIP --name=redis --port=6379

# Step 8: Wait for Redis pod to be ready
echo "Waiting for Redis pod to be ready..."
for i in {1..10}; do
    if kubectl get pods -n bashaway | grep -q "redis"; then
        echo "Redis pod found, waiting for it to be ready..."
        kubectl wait --for=condition=ready pod -l app=redis -n bashaway --timeout=60s && break
    fi
    echo "Waiting for Redis pod to be created..."
    sleep 5
done

# Check if the pod is still not ready
if ! kubectl get pods -l app=redis -n bashaway | grep "Running"; then
    echo "Error: Redis pod is not running."
    exit 1
fi

# Step 9: Set up port forwarding
echo "Setting up port forwarding for Redis..."
kubectl port-forward service/redis -n bashaway 6381:6379 &

# Step 10: Print connection details
echo "Redis service is now running in the 'bashaway' namespace."
echo "Access Redis using the following command:"
echo "redis-cli -h localhost -p 6381"

# # Keep the script running to maintain port forwarding
# wait
sleep 10
