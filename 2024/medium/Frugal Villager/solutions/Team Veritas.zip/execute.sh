#!/bin/bash

# Ensure the script exits if any command fails
set -e

# Install minikube for x86_64 Linux if it's not already installed
if ! command -v minikube &>/dev/null; then
    echo "Installing Minikube..."
    curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
    sudo install minikube-linux-amd64 /usr/local/bin/minikube
    rm minikube-linux-amd64
else
    echo "Minikube is already installed."
fi

# Start Minikube if it's not already running
if ! minikube status &>/dev/null; then
    echo "Starting Minikube..."
    minikube start
else
    echo "Minikube is already running."
fi

# Set Minikube as the current context
kubectl config use-context minikube

# Create a namespace named "bashaway" if it doesn't exist
if ! kubectl get namespace bashaway &>/dev/null; then
    echo "Creating namespace bashaway..."
    kubectl create namespace bashaway
else
    echo "Namespace bashaway already exists."
fi

# Create a secret for Redis password if it doesn't exist
if ! kubectl get secret redis -n bashaway &>/dev/null; then
    echo "Creating Redis secret..."
    REDIS_PASSWORD=$(openssl rand -base64 16) # Generates a random password
    kubectl create secret generic redis --from-literal=redis-password="${REDIS_PASSWORD}" -n bashaway
else
    echo "Redis secret already exists."
fi

# Create a Redis deployment in the "bashaway" namespace
echo "Creating Redis deployment..."
kubectl apply -n bashaway -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: bashaway
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:latest
        ports:
        - containerPort: 6379
EOF

# Create a service to expose Redis at port 6381, targeting the Redis container port 6379
echo "Creating Redis service..."
kubectl apply -n bashaway -f - <<EOF
apiVersion: v1
kind: Service
metadata:
  name: redis
  namespace: bashaway
spec:
  selector:
    app: redis
  ports:
  - name: redis-port
    protocol: TCP
    port: 6381
    targetPort: 6379
EOF

# Wait for Redis to be ready
echo "Waiting for Redis to be ready..."
kubectl rollout status deployment/redis -n bashaway

#Fetch the name of the Redis pod
REDIS_POD=$(kubectl get pod -l app=redis -n bashaway -o jsonpath="{.items[0].metadata.name}")

# Forward port 6381 on localhost to the Redis service
echo "Forwarding port 6381 to Redis service..."
kubectl port-forward pod/$REDIS_POD 6381:6379 -n bashaway &
echo "Redis service is now available at localhost:6381."

# Script end