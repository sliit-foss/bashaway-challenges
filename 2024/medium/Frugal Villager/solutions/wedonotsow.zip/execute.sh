#!/bin/bash

minikube start

kubectl config use-context minikube

kubectl create namespace bashaway

REDIS_PASSWORD=$(openssl rand -base64 20)

kubectl create secret generic redis --from-literal=redis-password=$REDIS_PASSWORD -n bashaway

cat <<EOF | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: bashaway
spec:
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis
        args: ["--requirepass", "$(REDIS_PASSWORD)"]
        env:
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis
              key: redis-password
        ports:
        - containerPort: 6379
EOF

kubectl expose deployment redis --name=redis --port=6379 --target-port=6379 -n bashaway

kubectl wait --for=condition=ready pod -l app=redis -n bashaway --timeout=60s

kubectl port-forward service/redis 6381:6379 -n bashaway &

sleep 5

kubectl get services -n bashaway

echo "Redis password: $REDIS_PASSWORD"