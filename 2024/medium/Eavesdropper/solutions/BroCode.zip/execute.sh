#!/bin/bash

# Step 1: Check for existing Kubernetes cluster and delete if necessary
if minikube status &>/dev/null; then
    echo "Deleting existing Minikube cluster..."
    minikube delete
fi

# Step 2: Start a new Minikube cluster
echo "Starting Minikube cluster..."
minikube start

# Step 3: Set the current context to the new cluster
echo "Setting kubectl context to Minikube..."
kubectl config use-context minikube

# Step 4: Enable the Metrics Server
echo "Enabling Metrics Server..."
minikube addons enable metrics-server

# Step 5: Verify the Metrics Server
echo "Verifying Metrics Server..."
kubectl wait --for=condition=available --timeout=300s deployment/metrics-server -n kube-system

# Step 6: Wait for Metrics Server to be ready
echo "Waiting for Metrics Server to be ready..."
until kubectl top nodes &>/dev/null; do
    echo "Metrics Server is not ready yet. Waiting..."
    sleep 10
done

echo "Metrics Server is running. You can now use 'kubectl top nodes' to see metrics."