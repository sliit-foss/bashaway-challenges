#!/bin/bash

# Function to check if a command exists
command_exists () {
    command -v "$1" >/dev/null 2>&1
}

# Check if minikube is installed
if ! command_exists minikube; then
    echo "Error: Minikube is not installed."
    exit 1
fi

# Check if kubectl is installed
if ! command_exists kubectl; then
    echo "Error: kubectl is not installed."
    exit 1
fi

# Step 1: Start the Minikube Kubernetes cluster
echo "Starting Minikube..."
minikube start

# Step 2: Set Minikube as the current kubectl context
echo "Setting Minikube as the current kubectl context..."
kubectl config use-context minikube

# Step 3: Enable the Metrics Server addon in Minikube
echo "Enabling the Metrics Server..."
minikube addons enable metrics-server

# Wait for the Metrics Server to be ready (retry mechanism)
max_retries=10
retry_count=0
sleep_time=10

until kubectl top nodes > /dev/null 2>&1 || [ $retry_count -eq $max_retries ]; do
    echo "Waiting for Metrics Server to become available... (attempt: $((retry_count+1)))"
    retry_count=$((retry_count+1))
    sleep $sleep_time
done

# If Metrics Server is still not available, exit with an error
if [ $retry_count -eq $max_retries ]; then
    echo "Error: Metrics Server is not available after $max_retries attempts."
    exit 1
fi

# Step 4: Confirm that the metrics server is running by displaying node metrics
echo "Metrics Server is running. Fetching node metrics..."
kubectl top nodes

