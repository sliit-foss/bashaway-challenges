#!/bin/bash

if ! command -v k3d &> /dev/null; then
    curl -s https://raw.githubusercontent.com/rancher/k3d/main/install.sh | bash
fi

k3d cluster create mycluster --wait

kubectl config use-context k3d-mycluster

kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml

kubectl wait --for=condition=available --timeout=60s deployment/metrics-server -n kube-system

kubectl get --raw "/apis/metrics.k8s.io/"
if [ $? -eq 0 ]; then
    echo "Metrics API is available!"
else
    echo "Metrics API is not available."
    exit 1
fi

kubectl top nodes

kubectl top pods --all-namespaces

echo "Done!"
