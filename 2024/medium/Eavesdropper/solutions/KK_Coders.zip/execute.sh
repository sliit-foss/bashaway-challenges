#!/bin/bash

# Start Minikube with Docker as the driver and enable metrics-server addon.
minikube start  --wait=all --driver=docker

# Set the current context to Minikube.
kubectl config use-context minikube

# Enable the metrics-server addon in Minikube.
minikube addons enable metrics-server

# Wait for the metrics API to be available by checking if metrics-server is running.
echo "Waiting for metrics-server to be up..."
while ! kubectl get apiservices | grep -q 'v1beta1.metrics.k8s.io.*True'; do
    sleep 1
done

while ! kubectl get --raw "/apis/metrics.k8s.io/v1beta1/nodes" >/dev/null 2>&1; do
  echo "Metrics API not available yet, retrying in 5 seconds..."
  sleep 5
done

# Confirm that the metrics API is available.
echo "Metrics API is available!"

while true; do
    # Check if the metrics-server pod is running
    if kubectl get pods -n kube-system | grep metrics-server | grep Running >/dev/null; then
        echo "Metrics Server is running!"
        break
    else
        echo "Waiting for Metrics Server to be ready..."
        sleep 5
    fi
done

sleep 90

# Verify that the cluster is running and the metrics API is responding.
kubectl top nodes