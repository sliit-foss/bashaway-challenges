#!/bin/bash

# Step 0: Check if kubectl is installed
if ! command -v kubectl &> /dev/null; then
  echo "kubectl could not be found, please install kubectl and try again."
  exit 1
fi

# Step 1: Start Minikube with Docker as the driver
echo "Starting Minikube cluster..."
minikube start --driver=docker

# Step 2: Set the current context to the Minikube cluster
echo "Setting Minikube as the current kubectl context..."
kubectl config use-context minikube

# Step 3: Enable the Metrics Server addon in Minikube
echo "Enabling the Metrics Server..."
minikube addons enable metrics-server

# Step 4: Wait for Metrics Server to become available
echo "Waiting for Metrics Server to become available..."
for i in {1..20}; do
  if kubectl get apiservices | grep -q "v1beta1.metrics.k8s.io.*True"; then
    echo "Metrics Server is now available."
    break
  else
    echo "Attempt $i: Metrics Server not yet available. Retrying in 10 seconds..."
    sleep 10
  fi
done

# Step 5: Fetch node metrics to verify that the Metrics Server is working
echo "Fetching node metrics..."
kubectl top nodes

sleep 100

#Get the name of the metrics server pod
METRICS_SERVER_POD=$(kubectl get pods -n kube-system | grep metrics-server | awk '{print $1}')

#Get the logs of the metrics server pod
kubectl logs -n kube-system $METRICS_SERVER_POD

echo "Kubernetes cluster is up and running, and Metrics Server is enabled."