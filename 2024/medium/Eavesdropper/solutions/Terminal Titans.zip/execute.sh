#!/bin/bash

# Convert the script to Unix format
dos2unix ./submission/execute.sh

# Install k3d for local Kubernetes cluster setup
curl -s https://raw.githubusercontent.com/rancher/k3d/main/install.sh | bash

# Create a Kubernetes cluster with k3d
k3d cluster create mycluster

# Switch to the newly created cluster's context
kubectl config use-context k3d-mycluster

# Deploy the Metrics Server
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml

# Wait for the Metrics Server deployment to be ready
kubectl wait --namespace kube-system --for=condition=available --timeout=90s deployment/metrics-server

# Check if Metrics API is available
kubectl get --raw "/apis/metrics.k8s.io/" | jq '.'

# Print resource usage as an example output
echo "Metrics API is available!"
kubectl top node
kubectl top pod --namespace kube-system

echo "Done!"