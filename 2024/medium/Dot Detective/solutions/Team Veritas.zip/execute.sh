#!/bin/bash

mkdir -p out

# Function to flatten JSON
flatten_json() {
  local json="$1"

  # Use jq to flatten the JSON
  echo "$json" | jq -r '
    def flatten:
      . as $in |
      reduce (paths(scalars) as $p | { ([$p[]] | join(".")): getpath($p) }) as $item ({}; . * $item);
    
    flatten
  '
}

# Read the JSON input from a file
input_file="src/chaos.json" # Change this to your input file path
output_file="out/transformed.json" # Change this to your desired output file path

# Flatten the JSON and save it to the output file
flattened_json=$(flatten_json "$(cat "$input_file")")
echo "$flattened_json" > "$output_file"

echo "Flattened JSON has been saved to $output_file"
