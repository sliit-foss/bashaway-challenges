#!/bin/bash
process_json() {
  local prefix="$1"
  local json="$2"
  while IFS= read -r -d $'\n' line; do
    key=$(echo "$line" | jq -r '.key')
    value=$(echo "$line" | jq -r '.value')
    if [[ "$value" =~ ^\{.*\}$ ]]; then
      process_json "${prefix}${key}." "$value"
    else
      echo "\"$prefix$key\": \"$value\"," >> out/transformed.json
    fi
  done < <(echo "$json" | jq -c 'to_entries[]')
}

mkdir -p out

echo "{" >> out/transformed.json
process_json "" "$(cat src/chaos.json)"
sed -i ':a;N;$!ba;s/,\([^,]*\)$/} \1/' out/transformed.json
