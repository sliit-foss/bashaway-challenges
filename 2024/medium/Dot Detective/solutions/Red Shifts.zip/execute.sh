#!/bin/bash

mkdir -p out

CLEANJSON=$(sed 's/  //g' src/chaos.json | tr -d '\n')

# Function to recursively flatten the JSON
flatten_json() {
    local json=$1
    local prefix=$2
    local output=""

    # Parse each key-value pair
    while [[ $json =~ \"([^\"]+)\":([^\{]*)(\{[^\}]*\})? ]]; do
        key="${BASH_REMATCH[1]}"
        value="${BASH_REMATCH[2]}"
        nested="${BASH_REMATCH[3]}"

        if [[ -n $value ]]; then
        	value=$(echo $value | cut -d "," -f 1)
        fi

        
        if [[ -n $nested ]]; then
            # Process the nested object recursively
            nested_content=$(echo "$nested" | sed 's/^{//;s/}$//')
            output+=$(flatten_json "$nested_content" "$prefix$key.")
        else
            # Append the key-value pair in the flattened format
            output+="\"$prefix$key\": $value,"
        fi

        # Move to the next part of the JSON
        json="${json#*$nested}"
        json="${json#*$value}"
    done

    # Return the flattened key-value pairs
    echo "$output"
}


flattened=$(flatten_json "$CLEANJSON" "")
echo "{${flattened%,}}" > out/transformed.json