#!/bin/bash

mkdir -p out

jq -r '
  def flatten($path):
    . as $in
    | if type == "object" then
        reduce keys[] as $key (
          {};
          . + (
            ($in[$key] | flatten($path + [$key])) as $flat
            | if $flat == {} then
                { "\($path + [$key] | join("."))": $in[$key] }
              else
                $flat
              end
          )
        )
      else
        if $path == [] then . else empty end
      end;
  flatten([])
' src/chaos.json > out/transformed.json