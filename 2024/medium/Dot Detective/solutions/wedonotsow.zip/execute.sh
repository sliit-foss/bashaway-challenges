#!/bin/bash


mkdir -p out


process_json() {
    local prefix="$1"
    local indent="$2"
    

    while IFS= read -r line; do

        line=$(echo "$line" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')
        

        [[ -z "$line" || "$line" =~ ^[}\]]?,?$ ]] && continue
        

        if [[ "$line" =~ ^\"(.+)\":\ (.+) ]]; then
            key="${BASH_REMATCH[1]}"
            value="${BASH_REMATCH[2]}"
            

            value="${value%,}"
            

            if [[ "$value" =~ ^[{\[]$ ]]; then
                process_json "${prefix}${key}." "$((indent + 2))"
            else

                echo "  \"${prefix}${key}\": ${value},"
            fi
        fi
    done
}


(
    echo "{"
    process_json "" 0 < "./src/chaos.json" | sed '$ s/,$//'
    echo "}"
) > "./out/transformed.json"


sed -i '/^$/d' "./out/transformed.json"