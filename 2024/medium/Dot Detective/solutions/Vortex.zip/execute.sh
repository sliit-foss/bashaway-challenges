# jq 'paths | map(tostring) | join(".")' src/chaos.json


# flatten_json() {
#   jq -r 'def flatten: 
#       . as $in 
#       | reduce paths(scalars) as $path ({}; . + {($path | map(tostring) | join(".")): getpath($path)}); 
#       flatten' src/chaos.json
# }

# flatten_json

# flatten_json() {
#   jq -r 'def flatten: 
#       . as $in 
#       | reduce paths(scalars) as $path ({}; . + {($path | map(tostring) | join(".")): getpath($path)}); 
#       flatten | keys[] | "\""+.+"\""' src/chaos.json
# }

# flatten_json



# mkdir -p out
# touch out/transformed.json

# flatten_json() {
#   # Get the keys and store them in an array
#   mapfile -t keys < <(jq -r 'def flatten: 
#       . as $in 
#       | reduce paths(scalars) as $path ({}; . + {($path | map(tostring) | join(".")): getpath($path)}); 
#       flatten | keys[]' src/chaos.json)

# # Loop through each key in the array
# for key in "${keys[@]}"; do
#   # Check if the key contains quotation marks
#   if [[ "$key" =~ ^\"(.*)\"$ ]]; then
#     key="${BASH_REMATCH[1]}"
#   fi

#   # Get the value without quotation marks
#   value=$(jq -r ".$key" src/chaos.json)

#   # Print key and value as separate variables
#   echo $key
#   echo $value

#   # Run the jq command to append the new key-value pair
#   jq '. + {"'${key}'": "'${value}'"}' src/chaos.json > out/transformed.json
# done

# }

# flatten_json













mkdir -p out
touch out/transformed.json

flatten_json() {
  # Get the keys and store them in an array
  mapfile -t keys < <(jq -r 'def flatten: 
      . as $in 
      | reduce paths(scalars) as $path ({}; . + {($path | map(tostring) | join(".")): getpath($path)}); 
      flatten | keys[]' src/chaos.json)

  # Initialize transformed JSON as an empty object
  transformed_json="{}"

  # Loop through each key in the array
  for key in "${keys[@]}"; do
    # Get the value using jq
    value=$(jq -r ".$key" src/chaos.json)

    # Print key and value for debugging
    echo "Key: $key"
    echo "Value: $value"

    # Check if the value is null
    if [ "$value" == "null" ]; then
      echo "Warning: Value for key '$key' is null."
      continue  # Skip if the value is null
    fi

    # Append the new key-value pair to the transformed JSON
    transformed_json=$(echo "$transformed_json" | jq --arg k "$key" --arg v "$value" '. + {($k): $v}')
  done

  # Write the final transformed JSON to the output file
  echo "$transformed_json" > out/transformed.json
}

flatten_json
