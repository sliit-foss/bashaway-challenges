#!/bin/bash

install_jq() {
  echo "jq is not installed. Attempting to install..."
  if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    if command -v apt-get &> /dev/null; then
      sudo apt-get update && sudo apt-get install -y jq
    elif command -v dnf &> /dev/null; then
      sudo dnf install -y jq
    elif command -v yum &> /dev/null; then
      sudo yum install -y jq
    else
      echo "Unsupported package manager. Please install jq manually."
      exit 1
    fi
  elif [[ "$OSTYPE" == "darwin"* ]]; then
    if command -v brew &> /dev/null; then
      brew install jq
    else
      echo "Homebrew is not installed. Please install jq manually."
      exit 1
    fi
  else
    echo "Unsupported OS. Please install jq manually."
    exit 1
  fi
}

if ! command -v jq &> /dev/null; then
  install_jq
fi

mkdir -p out

input_file="./src/chaos.json"
output_file="./out/transformed.json"

if [ ! -f "$input_file" ]; then
  echo "Input file not found!"
  exit 1
fi

jq -c 'def flatten: . as $in | reduce paths(scalars) as $path ({}; . + {($path | map(tostring) | join(".")): $in|getpath($path)}); flatten' "$input_file" > "$output_file"

if [ $? -eq 0 ]; then
  echo "Transformation successful. Output written to $output_file"
else
  echo "Transformation failed."
  exit 1
fi