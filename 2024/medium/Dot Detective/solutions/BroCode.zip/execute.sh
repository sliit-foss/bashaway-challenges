#!/bin/bash

# Ensure the out directory exists
mkdir -p out

# Function to process JSON object
process_json() {
    local prefix="$1"
    local depth="$2"
    local line
    local in_object=false

    while IFS= read -r line; do
        # Remove leading and trailing whitespace
        line=$(echo "$line" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')

        # Check if we're entering a new object
        if [[ $line == "{" ]]; then
            in_object=true
            continue
        fi

        # Check if we're exiting an object
        if [[ $line == "}" || $line == "}," ]]; then
            in_object=false
            [ $depth -gt 1 ] && return
            continue
        fi

        # Check if line is a key-value pair
        if [[ $line =~ ^\"(.+)\":\ (.+) ]]; then
            key="${BASH_REMATCH[1]}"
            value="${BASH_REMATCH[2]}"

            # Remove trailing comma if present
            value="${value%,}"

            # If value is an object, recurse
            if [[ $value == "{" ]]; then
                process_json "${prefix}${key}." $((depth + 1))
            else
                # Output the flattened key-value pair
                echo "  \"${prefix}${key}\": ${value}," >> "$temp_file"
            fi
        fi
    done
}

# Create a temporary file
temp_file=$(mktemp)

# Start JSON object
echo "{" > "$temp_file"

# Process the input file
process_json "" 1 < src/chaos.json

# Remove the trailing comma from the last entry and close the JSON object
sed -i '$s/,$//' "$temp_file"
echo "}" >> "$temp_file"

# Move the temporary file to the output location
mv "$temp_file" out/transformed.json