#!/bin/bash

# Create the output directory if it doesn't exist
mkdir -p out

# Flatten the JSON and write to transformed.json
jq -r 'reduce ( tostream | select(length==2) | .[0] |= [join(".")] ) as [$p,$v] (
     {}
     ; setpath($p; $v)
  )' src/chaos.json > out/transformed.json
