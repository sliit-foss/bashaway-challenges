#!/bin/bash

# Input JSON file
input_file="src/chaos.json"
output_file="out/transformed.json"

# Create output directory if it doesn't exist
mkdir -p out

# Function to transform nested JSON to dot notation
transform_json() {
  jq -r 'paths as $p | 
          { ( $p | map(tostring) | join(".")): getpath($p) }' "$1" | 
          jq -s 'add' |   # Combine all the individual objects into one
          jq -c .        # Compact the final output
}

# Call the function and write output to file
transform_json "$input_file" > "$output_file"

echo "Transformed JSON written to $output_file"
