#!/bin/bash

set -e  # Exit immediately if a command exits with a non-zero status.

# Check if jq is installed
if ! command -v jq &> /dev/null; then
    echo "Error: jq is not installed. Please install jq to run this script."
    exit 1
fi

# Input and output file paths
INPUT_FILE="src/chaos.json"
OUTPUT_DIR="out"
OUTPUT_FILE="$OUTPUT_DIR/transformed.json"

# Create output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Debug: Check if input file exists and is readable
if [ ! -r "$INPUT_FILE" ]; then
    echo "Error: Cannot read input file $INPUT_FILE"
    exit 1
fi

# Debug: Display content of input file
echo "Content of input file:"
cat "$INPUT_FILE"
echo

# Function to flatten JSON
flatten_json() {
    jq -r '
    def flatten($path):
      . as $in
      | if type == "object" then
          reduce keys[] as $key (
            {};
            . + (
              ($in[$key] | flatten($path + [$key])) as $flattened
              | if $flattened == {} then
                  { ($path + [$key] | join(".")): $in[$key] }
                else
                  $flattened
                end
            )
          )
        else
          if $path == [] then . else {($path | join(".")): .} end
        end;
    flatten([])
    ' "$INPUT_FILE"
}

# Transform JSON and save to output file
flatten_json > "$OUTPUT_FILE"

echo "Transformation complete. Output saved to $OUTPUT_FILE"

# Display the content of the transformed file
echo "Transformed JSON:"
cat "$OUTPUT_FILE"