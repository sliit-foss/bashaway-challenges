#!/bin/bash

# Debugging information
echo "Current directory: $(pwd)"
echo "Files in current directory:"
ls -la

# Automatically set the input JSON file path
input_json_file="./src/chaos.json"
output_json_file="./out/transformed.json"
error_log_file="./out/error.log"

# Create output directory if it doesn't exist
mkdir -p ./out

# Verify the input JSON file exists
if [ ! -f "$input_json_file" ]; then
  echo "Error: Input JSON file '${input_json_file}' does not exist."
  exit 1
fi

# Function to transform nested JSON to dot notation
transform_json() {
  local json="$1"
  local result=""

  # Check if the input JSON is valid
  if [[ -z "$json" || "$json" == "{}" ]]; then
    echo "{}"  # Return an empty JSON object if the input is invalid
    return
  fi

  # Use jq to transform nested JSON to dot notation
  result=$(echo "$json" | jq -c 'to_entries | map({(.key): .value}) | add' 2> "$error_log_file")

  # Check if jq encountered an error
  if [ $? -ne 0 ]; then
    echo "Error during jq processing." >> "$error_log_file"
    echo "$result" >> "$error_log_file"
    echo "{}"  # Return an empty JSON object if there's an error
    return
  fi

  # Check if the result is valid and not null
  if [[ "$result" == "null" || -z "$result" ]]; then
    echo "{}"  # Return an empty JSON object if the result is null
  else
    echo "$result"  # Return the valid result
  fi
}

# Read the input JSON file and transform it
json_content=$(cat "$input_json_file")

# Debug information before transformation
echo "Input JSON content:"
echo "$json_content"

transformed_content=$(transform_json "$json_content")

# Save the transformed content to the output JSON file
echo "$transformed_content" > "$output_json_file"

# Debug information on completion
echo "Transformed JSON saved to '${output_json_file}'."
echo "Execution completed successfully."