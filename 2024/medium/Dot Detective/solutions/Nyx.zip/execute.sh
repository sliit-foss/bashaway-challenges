#!/bin/bash

mkdir -p out

flatten_json() {
  local prefix=$1
  local json=$2
  local result=""

  for key in $(echo "$json" | jq -r 'keys[]'); do
    local value=$(echo "$json" | jq -c --arg key "$key" '.[$key]')
    local new_key="$prefix$key"

    if [[ $(echo "$value" | jq 'type') == "\"object\"" ]]; then
      result+=$(flatten_json "$new_key." "$value")
    else
      result+="\"$new_key\": $value,"
    fi
  done

  echo "$result"
}

input_json=$(cat src/chaos.json)

flattened_json=$(flatten_json "" "$input_json" | sed 's/,$//')

echo "{$flattened_json}" | jq '.' > out/transformed.json