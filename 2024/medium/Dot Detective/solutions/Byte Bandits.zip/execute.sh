#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# Create the output directory if it doesn't exist
mkdir -p out

# Define input and output file paths
INPUT_FILE="src/chaos.json"
OUTPUT_FILE="out/transformed.json"

# Check if the input file exists
if [[ ! -f "$INPUT_FILE" ]]; then
  echo "Input file $INPUT_FILE does not exist."
  exit 1
fi

# Use jq to flatten the JSON structure into dot notation
jq -r '
  def flatten:
    paths(scalars) as $p
    | { key: ($p | map(tostring) | join(".")), value: getpath($p) };
  
  reduce (flatten) as $item ({}; . + { ($item.key): $item.value })
' "$INPUT_FILE" > "$OUTPUT_FILE"

echo "Transformed JSON has been saved to $OUTPUT_FILE"

