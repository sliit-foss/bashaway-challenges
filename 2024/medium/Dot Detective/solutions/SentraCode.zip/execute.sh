mkdir -p ./out
jq 'paths as $p | select(getpath($p) | type != "object" and type != "array") | { ([$p[] | tostring] | join(".")): getpath($p) }' ./src/chaos.json | jq -s 'add' > ./out/transformed.json