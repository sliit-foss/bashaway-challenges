#!/bin/bash

INPUT_FILE="./src/chaos.json"
OUTPUT_DIR="./out"
OUTPUT_FILE="${OUTPUT_DIR}/transformed.json"

# Create the output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Function to transform nested JSON to dot notation
json_to_dot() {
    local json="$1"
    local prefix="$2"
    local result=""

    # Loop through the keys and values in the JSON object
    for key in $(echo "$json" | jq -r 'keys_unsorted[]'); do
        local value=$(echo "$json" | jq -c --arg k "$key" '.[$k]')

        if [[ "$(echo "$value" | jq 'type')" == '"object"' ]]; then
            result+=$(json_to_dot "$(echo "$value")" "${prefix}${key}.")
        else
            result+="\"${prefix}${key}\": $(echo "$value"),"
        fi
    done

    # Remove the trailing comma if there is any
    echo "${result%,}"
}

# Read the JSON input file and convert it to dot notation
if [ -f "$INPUT_FILE" ]; then
    json_content=$(<"$INPUT_FILE")
    echo "Input JSON content: $json_content"  # Debugging line
    transformed_json=$(json_to_dot "$json_content" "")
    
    if [[ -z "$transformed_json" ]]; then
        echo "{}" > "$OUTPUT_FILE"
        echo "Output JSON is empty."  # Debugging line
    else
        echo "{$transformed_json}" > "$OUTPUT_FILE"
        echo "Transformed JSON: {$transformed_json}"  # Debugging line
    fi
else
    echo "Input file not found: $INPUT_FILE"
    exit 1
fi
