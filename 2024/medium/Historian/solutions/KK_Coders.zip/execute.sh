#!/bin/bash

# Check if ~/.bash_history exists, if not, create it and exit with 0
if [[ ! -f ~/.bash_history ]]; then
  touch ~/.bash_history
  echo "Created ~/.bash_history"
  exit 0
fi

# Check if a valid number N is provided
if [[ -z "$1" || ! "$1" =~ ^[0-9]+$ ]]; then
  echo "Please provide a valid number as the first argument."
  exit 0
fi


# If the file exists, proceed with tailing the last N entries
tail -n "$1" ~/.bash_history
