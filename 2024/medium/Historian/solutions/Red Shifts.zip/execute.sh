#!/bin/bash

# Check if the user provided an argument
if [ $# -eq 0 ]; then
    echo "Usage: $0 <number_of_commands>"
    exit 0
fi

# Get the number of commands to show
n=$1

# Check if the history file exists
history_file="$HOME/.bash_history"
if [ ! -f "$history_file" ]; then
    echo "No history file found."
    exit 1
fi

# Display the last n commands from the history file
tail -n "$n" "$history_file"
