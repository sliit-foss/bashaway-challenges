#!/bin/bash

# Check if the number of arguments is correct
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 N"
#   exit 1
fi

# Check if the provided argument is a valid number
if ! [[ "$1" =~ ^[0-9]+$ ]]; then
  echo "Error: N must be a positive integer."
#   exit 1
fi

N=$1

# Retrieve the last N commands from the history file
history_file=~/.bash_history

if [ -f "$history_file" ]; then
  tail -n $N "$history_file"
else
  echo "Error: History file not found."
#   exit 1
fi