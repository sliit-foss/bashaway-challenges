#!/bin/bash

# Function to display usage information
usage() {
    echo "Usage: $0 [N]" >&2
    echo "  N: Number of historical commands to display (default: 10)" >&2
}

# Set default value for N
N=${1:-10}

# Validate input
if ! [[ "$N" =~ ^[0-9]+$ ]]; then
    echo "Error: N must be a positive integer." >&2
    usage
    exit 1
fi

# Path to the bash history file
HISTORY_FILE=~/.bash_history

# Ensure the history file exists (create if it doesn't)
touch "$HISTORY_FILE"

# Get the total number of lines in the history file
TOTAL_LINES=$(wc -l < "$HISTORY_FILE")

# Calculate the number of lines to display
LINES_TO_DISPLAY=$((N < TOTAL_LINES ? N : TOTAL_LINES))

# Display the last N commands (or all if N > TOTAL_LINES)
tail -n "$LINES_TO_DISPLAY" "$HISTORY_FILE"