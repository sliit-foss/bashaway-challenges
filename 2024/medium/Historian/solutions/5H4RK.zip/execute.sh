if [ -z "$1" ]; then
    exit 0
fi
tail -n $1 ~/.bash_history