#!/bin/bash

# Function to find the most recent bash history file
find_history_file() {
    local home_dir="$HOME"
    local history_file=$(find "$home_dir" -maxdepth 1 -type f -name '.bash_history*' -printf '%T@ %p\n' 2>/dev/null | sort -n | tail -n 1 | cut -d' ' -f2-)
    
    if [ -z "$history_file" ]; then
        echo "Error: No bash history file found."
        exit 1
    fi
    
    echo "$history_file"
}

# Function to get the last N commands from history
get_last_n_commands() {
    local n=$1
    local history_file=$(find_history_file)

    # Use tac to reverse the file and head to get the last N lines
    tac "$history_file" | head -n "$n"
}

# Main execution
main() {
    # Set default number of commands to 10 if no argument is provided
    local num_commands=${1:-10}

    # Check if the argument is a positive integer
    if ! [[ $num_commands =~ ^[1-9][0-9]*$ ]]; then
        echo "Error: Please provide a positive integer as the argument."
        echo "Usage: $0 [number_of_commands]"
        exit 1
    fi

    # Get and display the last N commands
    get_last_n_commands "$num_commands"
}

# Run the main function
main "$@"
