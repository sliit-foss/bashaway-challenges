#!/bin/bash
mkdir -p out
diff -u src/gears.js src/gears-*.js > out/gearsmith.patch
exit 0