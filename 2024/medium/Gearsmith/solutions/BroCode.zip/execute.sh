mkdir -p out
diff -u src/gears.js src/gears-1719135696714.js > out/gearsmith.patch || true