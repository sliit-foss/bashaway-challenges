#!/bin/bash

sudo rm -rf /usr/local/go

rm -rf ./out
mkdir -p ./out

rm -f ./src/go.mod
sudo rm -f /bin/go

curl -OL https://golang.org/dl/go1.17.2.linux-amd64.tar.gz
sudo tar -C /usr/local -xzf go1.17.2.linux-amd64.tar.gz

rm -f go1.17.2.linux-amd64.tar.gz

sudo ln -sf /usr/local/go/bin/go /bin/go
sudo chmod +x /bin/go

go version

cd ./src

go mod init blade
go mod tidy
go build -o ../out/blade .

rm -f ./src/go.mod
