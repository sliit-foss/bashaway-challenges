#!/bin/bash

OUT_DIR="out"
GO_VERSION_REQUIRED="1.17.2"
GO_TAR="go$GO_VERSION_REQUIRED.linux-amd64.tar.gz"
GO_URL="https://golang.org/dl/$GO_TAR"
GO_INSTALL_PATH="/usr/local/go1.17.2"

# Create output directory
mkdir -p "$OUT_DIR"

# Function to install Go 1.17.2 if not already installed
install_go_1172() {
    echo "Go $GO_VERSION_REQUIRED is not installed. Installing..."
    
    # Download Go tarball
    curl -LO "$GO_URL"
    
    # Extract Go to a specific path
    sudo tar -C /usr/local -xzf "$GO_TAR"
    
    # Rename the Go installation directory to include version
    sudo mv /usr/local/go "$GO_INSTALL_PATH"
    
    # Clean up downloaded tar file
    rm "$GO_TAR"
    
    echo "Go $GO_VERSION_REQUIRED installed successfully at $GO_INSTALL_PATH."
}

# Check if Go 1.17.2 is already installed
if [ ! -d "$GO_INSTALL_PATH" ]; then
    install_go_1172
else
    echo "Go $GO_VERSION_REQUIRED is already installed."
fi

# Use Go 1.17.2 explicitly for building
export PATH="$GO_INSTALL_PATH/bin:$PATH"

# Verify that the correct version is being used
CURRENT_GO_VERSION=$(go version | awk '{print $3}')
if [ "$CURRENT_GO_VERSION" != "go$GO_VERSION_REQUIRED" ]; then
    echo "Failed to use Go $GO_VERSION_REQUIRED. Current Go version is $CURRENT_GO_VERSION."
    exit 1
else
    echo "Using Go $GO_VERSION_REQUIRED."
fi

# Create Go source file
GO_FILE="blade.go"
cat <<EOF > $GO_FILE
package main

import "fmt"

func main() {
    fmt.Println("Hello there... Welcome to Bashaway 2k24!")
}
EOF

# Build the Go executable using Go 1.17.2
go build -o "$OUT_DIR/blade" "$GO_FILE"

# Clean up Go source file
rm "$GO_FILE"

echo "Build successful. Executable created at $OUT_DIR/blade."