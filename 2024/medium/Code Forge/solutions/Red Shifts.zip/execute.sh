#!/bin/bash
# echo "GO111MODULE=on">>$GITHUB_ENV
# echo "GOVERSION=1.17.2">>$GITHUB_ENV

sudo apt-get install curl git mercurial make binutils bison gcc
bash < <(curl -s -S -L https://raw.githubusercontent.com/moovweb/gvm/master/binscripts/gvm-installer)
source ~/.gvm/scripts/gvm

gvm install go1.17.2

gvm use go1.17.2 --default

mkdir -p out
go build -o out/blade src/script.go