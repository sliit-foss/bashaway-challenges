#!/bin/bash

curl -O https://dl.google.com/go/go1.17.2.linux-amd64.tar.gz

tar -xf go1.17.2.linux-amd64.tar.gz

mkdir -p  out

go/bin/go build -o out/blade src/script.go

rm -rf go

rm go1.17.2.linux-amd64.tar.gz
