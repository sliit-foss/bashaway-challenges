#!/bin/bash

# Define Go version and installation directory
GO_VERSION="1.17.2"
INSTALL_DIR="$PWD/out/go"
go_file="$PWD/src/script.go"
GO_TAR_FILE="go${GO_VERSION}.linux-amd64.tar.gz"

# Check if Go is already installed in the specified directory
if [ ! -d "$INSTALL_DIR" ]; then
    echo "Go $GO_VERSION is not installed. Installing Go $GO_VERSION in $INSTALL_DIR..."

    # Install required dependencies
    sudo apt-get update
    sudo apt-get install -y wget tar

    # Download Go 1.17.2 tarball if it doesn't already exist
    if [ ! -f "$GO_TAR_FILE" ]; then
        wget "https://golang.org/dl/$GO_TAR_FILE"
    fi

    # Extract Go to the specified directory
    mkdir -p "$INSTALL_DIR"
    tar -C "$PWD/out" -xzf "$GO_TAR_FILE"

    # Clean up the tarball
    rm "$GO_TAR_FILE"
else
    echo "Go $GO_VERSION is already installed in $INSTALL_DIR."
fi

# Set Go environment variables to use the locally installed Go
export GOROOT="$INSTALL_DIR"
export PATH="$GOROOT/bin:$PATH"

# Verify Go installation
go_version=$(go version 2>/dev/null)
if [ "$go_version" != "go version go1.17.2 linux/amd64" ]; then
    echo "Error: Go $GO_VERSION installation failed."
    exit 1
else
    echo "Go $GO_VERSION successfully installed in $INSTALL_DIR!"
fi

# Define output directory and file names for the compiled executable
output_dir="$PWD/out"
output_file="$output_dir/blade"
 # Path to the Go source file

# Create the output directory if it doesn't exist
mkdir -p "$output_dir"

# Compile the Go script (no module mode)
GO111MODULE=off go build -o "$output_file" "$go_file"

# Check if the compilation was successful
if [ $? -eq 0 ]; then
    echo "Compilation successful! Executable created at $output_file"
else
    echo "Error: Compilation failed."
    exit 1
fi
