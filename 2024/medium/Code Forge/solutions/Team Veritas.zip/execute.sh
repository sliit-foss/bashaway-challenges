#!/bin/bash

# Define variables
SRC_FILE="src/script.go"
OUT_DIR="out"
OUT_FILE="blade"

# Create the output directory
mkdir -p $OUT_DIR

# Compile the Go source file using the official Go Docker image
docker run -d --rm -v "$PWD":/usr/src/myapp -w /usr/src/myapp golang:1.17.2 go build -o $OUT_DIR/$OUT_FILE $SRC_FILE