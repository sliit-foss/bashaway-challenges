#!/bin/bash

# Set variables for script paths
SCRIPT_PATH="./src/script.go"
OUTPUT_DIR="./out"
OUTPUT_FILE="$OUTPUT_DIR/blade"
GO_VERSION="1.17.2"
GO_TARBALL="go$GO_VERSION.linux-amd64.tar.gz"
GO_URL="https://golang.org/dl/$GO_TARBALL"

# Create the output directory if it doesn't exist
mkdir -p $OUTPUT_DIR

# Check if Go 1.17.2 is already installed locally in the script environment
if ! go version | grep -q "go$GO_VERSION"; then
    echo "Go version $GO_VERSION is required. Installing Go $GO_VERSION..."

    # Download Go 1.17.2 tarball
    wget $GO_URL -O /tmp/$GO_TARBALL

    # Remove any existing Go installation in /usr/local/go
    sudo rm -rf /usr/local/go

    # Extract the downloaded tarball to /usr/local
    sudo tar -C /usr/local -xzf /tmp/$GO_TARBALL

    # Clean up the tarball
    rm /tmp/$GO_TARBALL
fi

# Force update the PATH to use Go 1.17.2
export PATH="/usr/local/go/bin:$PATH"

# Verify that Go 1.17.2 is being used
go version

# Compile the Go script using the required Go version
go build -o $OUTPUT_FILE $SCRIPT_PATH

# Check if the compilation was successful
if [ $? -eq 0 ]; then
    echo "Compilation successful. The executable has been forged as '$OUTPUT_FILE'."
else
    echo "Error: Compilation failed."
    exit 1
fi
