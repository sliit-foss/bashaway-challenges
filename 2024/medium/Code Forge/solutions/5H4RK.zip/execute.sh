#!/bin/bash

GO_VERSION="1.17.2"
OUT_DIR="out"
EXECUTABLE="blade"

mkdir -p $OUT_DIR

docker run --rm -v ./src:/app -v ./out:/out -w /app golang:$GO_VERSION bash -c "
    go build -o /$OUT_DIR/$EXECUTABLE script.go
"