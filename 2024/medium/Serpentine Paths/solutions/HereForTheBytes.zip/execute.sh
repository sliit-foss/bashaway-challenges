#!/bin/bash

sudo apt install docker.io docker-compose -y
sudo systemctl restart docker

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check if Docker is installed
if ! command_exists docker; then
    echo "Docker is not installed. Please install Docker and try again."
    exit 1
fi

# Check if the Firestore emulator container is already running
if docker ps --format '{{.Names}}' | grep -q "firestore-emulator"; then
    echo "Firestore emulator is already running."
else
    # Run the Firestore emulator in a Docker container
    echo "Starting Firestore emulator..."
    docker run -d --name firestore-emulator -p 9000:8080 \
        gcr.io/google.com/cloudsdktool/cloud-sdk:emulators \
        gcloud beta emulators firestore start --host-port 0.0.0.0:8080
    
    # Wait for the emulator to start
    echo "Waiting for Firestore emulator to start..."
    sleep 5
fi

# Set the Firestore emulator host environment variable
export FIRESTORE_EMULATOR_HOST="localhost:9000"

