#!/bin/bash

# Set the working directory to $PWD/src
WORKING_DIR="$PWD/src"

# Create the src directory if it doesn't exist
if [ ! -d "$WORKING_DIR" ]; then
    echo "Creating src directory at $WORKING_DIR."
    mkdir -p "$WORKING_DIR"
fi

# Change to the working directory
cd "$WORKING_DIR"

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null
then
    echo "Firebase CLI not found. Installing Firebase CLI."
    npm install -g firebase-tools
fi

# Create a firebase.json configuration file if it doesn't exist
if [ ! -f "firebase.json" ]; then
    echo "Creating firebase.json configuration for Firestore emulator."
    cat <<EOT >> firebase.json
{
  "emulators": {
    "firestore": {
      "port": 9000
    }
  }
}
EOT
fi

# Start the Firestore emulator on port 9000 without authentication
echo "Starting Firestore emulator on localhost:9000"
firebase emulators:start --only firestore --project demo-project 2>&1 &
