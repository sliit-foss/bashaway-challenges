#!/bin/bash

if ! command -v firebase &> /dev/null
then
    curl -sL https://firebase.tools | bash
fi

if [ ! -f "firebase.json" ]; then
    echo '{"emulators": {"firestore": {"port": 9000}}}' > firebase.json
fi

nohup firebase emulators:start --only firestore > firestore-emulator.log 2>&1 &

sleep 10

rm firebase.json
rm firebase-debug.log
rm firestore-debug.log
rm firestore-emulator.log

ls -a 