#!/bin/bash

# Create firebase.json if it doesn't exist
if [ ! -f firebase.json ]; then
    cat <<EOT >> firebase.json
{
  "emulators": {
    "firestore": {
      "host": "localhost",
      "port": 9000
    }
  }
}
EOT
fi

# Install Firebase CLI if it's not installed
if ! command -v firebase &> /dev/null; then
    echo "Installing Firebase CLI..."
    npm install -g firebase-tools
fi

# Start Firestore emulator on the specified host/port
firebase emulators:start --only firestore &
EMULATOR_PID=$!

# Wait for a few seconds to ensure the emulator starts and logs are created
sleep 5

# Remove firebase.json
rm firebase.json

# Check if firebase-debug.log exists before attempting to delete
if [ -f firebase-debug.log ]; then
    rm firebase-debug.log
else
    echo "firebase-debug.log does not exist."
fi

if [ -f firestore-debug.log ]; then
    rm firestore-debug.log
else
    echo "firestore-debug.log does not exist."
fi