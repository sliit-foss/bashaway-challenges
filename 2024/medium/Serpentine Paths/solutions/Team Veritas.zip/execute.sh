#!/bin/bash

# Start Firebase Firestore Emulator
echo "Starting the Firebase Firestore Emulator..."
docker run -d -p 9000:8080 --rm --name firestore-emulator -e FIRESTORE_PROJECT_ID="hello" mtlynch/firestore-emulator-docker