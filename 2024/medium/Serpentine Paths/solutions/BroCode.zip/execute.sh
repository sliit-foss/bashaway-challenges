#!/bin/bash

# Check if Docker is installed
if ! command -v docker &> /dev/null
then
    echo "Docker not found. Installing..."
    # Install Docker (this is for Debian-based systems; adjust if using a different OS)
    sudo apt-get update
    sudo apt-get install -y docker.io
    sudo systemctl start docker
    sudo systemctl enable docker
fi

# Pull the Firestore emulator Docker image
echo "Pulling Firestore emulator Docker image..."
docker pull gcr.io/google.com/cloudsdktool/cloud-sdk:emulators

# Create a firebase.json file with Firestore emulator configuration
cat <<EOL > firebase.json
{
  "emulators": {
    "firestore": {
      "port": 9000
    }
  }
}
EOL

# Run the Firestore emulator in a Docker container
echo "Starting Firestore emulator on localhost:9000..."
docker run -d --name firestore-emulator -p 9000:8080 -v "$(pwd)/firebase.json:/firebase.json" gcr.io/google.com/cloudsdktool/cloud-sdk:emulators gcloud beta emulators firestore start --host-port=0.0.0.0:8080 --project=fake-project-id

# Wait for a few seconds to ensure the emulator starts
sleep 10

# Verify if the Firestore emulator is running
if docker ps | grep -q firestore-emulator; then
    echo "Firestore emulator is running on port 9000"
else
    echo "Failed to start Firestore emulator on port 9000"
    exit 1
fi

# Clean up
sudo rm -rf firebase.json