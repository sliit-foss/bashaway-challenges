#!/bin/bash
docker run -d \
  --name test \
  --env "FIRESTORE_PROJECT_ID=test" \
  --env "PORT=8080" \
  --publish 9000:8080 \
  mtlynch/firestore-emulator-docker