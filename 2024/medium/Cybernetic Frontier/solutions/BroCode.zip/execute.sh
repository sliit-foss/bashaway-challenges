#!/bin/bash

# Start Install Google Chrome (You may comment out these lines during local testing if you already have Chrome installed. Though the chromedriver installed here might not work with your Chrome version)

sudo apt update

wget https://mirror.cs.uchicago.edu/google-chrome/pool/main/g/google-chrome-stable/google-chrome-stable_126.0.6478.114-1_amd64.deb
sudo dpkg -i google-chrome-stable_google-chrome-stable_126.0.6478.114-1_amd64.deb

sudo apt-get install -y -f

rm google-chrome-stable_126.0.6478.114-1_amd64.deb

# End Install Google Chrome

# Install JDK
sudo apt-get update
sudo apt-get install -y default-jdk

# Verify Java installation
java -version
cd src/web

sudo apt-get update
sudo apt-get install -y tomcat9

ls

echo "Contents of the directory:"
ls

# Update security.jsp with the necessary changes
sudo cat <<EOL > security.jsp
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="javax.crypto.Mac" %>
<%@ page import="javax.crypto.spec.SecretKeySpec" %>
<%@ page import="java.security.InvalidKeyException" %>
<%@ page import="java.security.NoSuchAlgorithmException" %>
<%@ page import="java.io.UnsupportedEncodingException" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.Iterator" %>
<%@ page import="java.util.Base64" %>

<%! private static final String HMAC_SHA256 = "HmacSHA256";
    private static final String SECRET_KEY = "<REPLACE WITH SECRET KEY>";

    private String sign(HashMap params) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {
        return sign(buildDataToSign(params), SECRET_KEY);
    }

    private String sign(String data, String secretKey) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {
        SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(), HMAC_SHA256);
        Mac mac = Mac.getInstance(HMAC_SHA256);
        mac.init(secretKeySpec);
        byte[] rawHmac = mac.doFinal(data.getBytes("UTF-8"));
        return Base64.getEncoder().encodeToString(rawHmac).replace("\n", "");
    }

    private String buildDataToSign(HashMap params) {
        String[] signedFieldNames = String.valueOf(params.get("signed_field_names")).split(",");
        ArrayList<String> dataToSign = new ArrayList<String>();
        for (String signedFieldName : signedFieldNames) {
            dataToSign.add(signedFieldName + "=" + String.valueOf(params.get(signedFieldName)));
        }
        return commaSeparate(dataToSign);
    }

    private String commaSeparate(ArrayList<String> dataToSign) {
        StringBuilder csv = new StringBuilder();
        for (Iterator<String> it = dataToSign.iterator(); it.hasNext(); ) {
            csv.append(it.next());
            if (it.hasNext()) {
                csv.append(",");
            }
        }
        return csv.toString();
    }
%>
EOL

sudo cp -r * /var/lib/tomcat9/webapps/ROOT/
ls /var/lib/tomcat9/webapps/ROOT/

sudo sed -i 's/port="8080"/port="5000"/' /etc/tomcat9/server.xml

sudo systemctl restart tomcat9
sudo ufw allow 5000/tcp

if systemctl is-active --quiet tomcat9; then
    echo "Tomcat is running on http://localhost:5000"
else
    echo "Tomcat failed to start"
    exit 1
fi

# Visit each page on the server to ensure they are compiled
pages=("payment_form.jsp" "payment_confirmation.jsp" "receipt.jsp") # Add more pages as needed

for page in "${pages[@]}"; do
    curl -s "http://localhost:5000/$page" > /dev/null
    sleep 2
    if [ $? -eq 0 ]; then
        echo "Visited $page successfully."
    else
        echo "Failed to visit $page."
    fi
done