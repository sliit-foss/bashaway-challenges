#!/bin/bash

pkill -9 YALB
pkill -9 YALB2
pkill -9 srcsvr
rm -f /tmp/YALB
rm -f /tmp/YALB2
rm -f /tmp/srcsvr

sudo apt-get install -f libboost-all-dev

g++ -o /tmp/srcsvr src/server.cpp -lstdc++ -lpthread
timeout 2m nohup /tmp/srcsvr &
disown

sleep 5

curl "https://f003.backblazeb2.com/file/linux-pkg-cdn/846207b1-e5ed-4057-a034-a8fee72a25c9/YetAnotherLoadBalancer/YALB" -o /tmp/YALB

cp /tmp/YALB /tmp/YALB2
chmod +x /tmp/YALB
chmod +x /tmp/YALB2

export MAX_RATE_PER_MINUTE=500
export TARGET="localhost:8080"
export PORT=7000

timeout 2m nohup /tmp/YALB2 &
disown

sleep 5

export MAX_RATE_PER_MINUTE=5
export TARGET="localhost:7000"
export PORT=8000

timeout 2m nohup /tmp/YALB &
disown

sleep 5
