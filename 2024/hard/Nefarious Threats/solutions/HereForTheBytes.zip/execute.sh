#!/bin/bash

sudo apt install docker.io docker-compose -y
sudo systemctl restart docker

MONGO_VERSION="3.6.2-jessie"
DB_NAME="bashaway"
MONGO_PORT=27020
DOMAIN_NAME="localhost"

PROJECT_DIR=$HOME/mongo_project
SSL_DIR="$PROJECT_DIR/ssl"
SCRIPTS_DIR="$PROJECT_DIR/scripts"
CONFIG_FILE="$PROJECT_DIR/mongod.conf"
DOCKER_IMAGE="mongo_ssl"
DOCKER_CONTAINER="mymongo"

export MONGO_TLS_CA_FILE_PATH="$SSL_DIR/ca.pem"
export MONGO_TLS_CERT_KEY_PATH="$SSL_DIR/mongodb.pem"

echo "export MONGO_TLS_CA_FILE_PATH=\"$MONGO_TLS_CA_FILE_PATH\"" >> ~/.bashrc
echo "export MONGO_TLS_CERT_KEY_PATH=\"$MONGO_TLS_CERT_KEY_PATH\"" >> ~/.bashrc
echo "MONGO_TLS_CA_FILE_PATH=$SSL_DIR/ca.pem" >> $GITHUB_ENV
echo "MONGO_TLS_CERT_KEY_PATH=$SSL_DIR/mongodb.pem" >> $GITHUB_ENV


# Reload .bashrc to apply changes
source ~/.bashrc

echo "Preparing project directories..."
mkdir -p "$SSL_DIR" "$SCRIPTS_DIR"

echo "Generating SSL certificates..."
openssl req -newkey rsa:4096 -nodes -keyout "$SSL_DIR/mongodb-key.pem" -x509 -days 365 -out "$SSL_DIR/mongodb-cert.pem" -subj "/C=US/ST=NewYork/L=NewYork/O=MyOrganization/OU=MyUnit/CN=$DOMAIN_NAME"
cat "$SSL_DIR/mongodb-key.pem" "$SSL_DIR/mongodb-cert.pem" > "$SSL_DIR/mongodb.pem"
cp "$SSL_DIR/mongodb-cert.pem" "$SSL_DIR/ca.pem"

echo "Creating Dockerfile..."
cat <<EOF > "$PROJECT_DIR/Dockerfile"
FROM mongo:$MONGO_VERSION

COPY scripts /home/mongodb/scripts
COPY ssl /home/mongodb/ssl
COPY mongod.conf /home/mongodb

WORKDIR /home/mongodb

RUN ["chmod", "+x", "/home/mongodb/scripts/run.sh"]

CMD ["/home/mongodb/scripts/run.sh"]
EOF

echo "Creating mongod.conf..."
cat <<EOF > "$CONFIG_FILE"
net:
  bindIp: 0.0.0.0
  port: $MONGO_PORT
  ssl:
    CAFile: /home/mongodb/ssl/ca.pem
    PEMKeyFile: /home/mongodb/ssl/mongodb.pem
    mode: requireSSL
    disabledProtocols: "TLS1_0,TLS1_1"
    allowConnectionsWithoutCertificates: false
storage:
  journal:
    enabled: true
security:
  authorization: "disabled"
EOF

echo "Creating run.sh script..."
cat <<EOF > "$SCRIPTS_DIR/run.sh"
#!/bin/bash

sleep 5

chown -R mongodb:mongodb /home/mongodb

nohup gosu mongodb mongod --dbpath=/data/db --config mongod.conf --bind_ip_all &

# Wait for MongoDB to start
nohup gosu mongodb mongo admin --eval "help" > /dev/null 2>&1
RET=\$?

while [[ "\$RET" -ne 0 ]]; do
  echo "Waiting for MongoDB to start..."
  mongo admin --eval "help" > /dev/null 2>&1
  RET=\$?
  sleep 2
done

# nohup gosu mongodb mongo $DB_NAME --eval "db.createCollection('test');"

echo "MongoDB started without user authentication."
EOF


echo "Building Docker image..."
docker build -t $DOCKER_IMAGE "$PROJECT_DIR"

echo "Running Docker container..."
docker run -d -p $MONGO_PORT:$MONGO_PORT --mount source=mongodb,target=/data/db --mount source=configdb,target=/data/configdb --name $DOCKER_CONTAINER $DOCKER_IMAGE

echo "Adding domain to /etc/hosts (requires sudo)..."
echo "127.0.0.1           localhost $DOMAIN_NAME" | sudo tee -a /etc/hosts

echo "MongoDB container running. Check logs with: docker logs -f $DOCKER_CONTAINER"
