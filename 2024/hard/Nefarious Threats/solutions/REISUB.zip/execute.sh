

#!/bin/bash

# $1 available
if [ -n "$1" ]; then
    export MONGO_TLS_CA_FILE_PATH="$HOME/certs/ca.crt"
    export MONGO_TLS_CERT_KEY_PATH="$HOME/certs/mongodb.pem"

    pnpm test-d

    exit 0
fi



mkdir -p "$HOME/certs" "$HOME/data/db"

openssl genrsa -out "$HOME/certs/ca.key" 4096
openssl req -new -x509 -days 365 -key "$HOME/certs/ca.key" -subj "/CN=MyMongoCA" -out "$HOME/certs/ca.crt"

openssl genrsa -out "$HOME/certs/mongodb.key" 4096

openssl req -new -key "$HOME/certs/mongodb.key" -subj "/CN=localhost" -out "$HOME/certs/mongodb.csr"

openssl x509 -req -in "$HOME/certs/mongodb.csr" -CA "$HOME/certs/ca.crt" -CAkey "$HOME/certs/ca.key" -CAcreateserial -out "$HOME/certs/mongodb.crt" -days 365

cat "$HOME/certs/mongodb.crt" "$HOME/certs/mongodb.key" > "$HOME/certs/mongodb.pem"

export MONGO_TLS_CA_FILE_PATH="$HOME/certs/ca.crt"
export MONGO_TLS_CERT_KEY_PATH="$HOME/certs/mongodb.pem"

echo 'MONGO_TLS_CA_FILE_PATH="$HOME/certs/ca.crt"' >> .env
echo 'MONGO_TLS_CERT_KEY_PATH="$HOME/certs/mongodb.pem"' >> .env

# sed -i '1s;^;process.env.MONGO_TLS_CA_FILE_PATH = "$(dirname \"$(realpath \\\"$0\\\")\")/certs/ca.crt";\n;' test/index.test.js
# sed -i '2s;^;process.env.MONGO_TLS_CERT_KEY_PATH = "$(dirname \"$(realpath \\\"$0\\\")\")/certs/mongodb.pem";\n;' test/index.test.js

home_dir="$HOME"


echo "process.env.MONGO_TLS_CA_FILE_PATH = \"$home_dir/certs/ca.crt\";" | cat - test/index.test.js > temp && mv temp test/index.test.js

echo "process.env.MONGO_TLS_CERT_KEY_PATH = \"$home_dir/certs/mongodb.pem\";" | cat - test/index.test.js > temp && mv temp test/index.test.js

# sed -i 's|"test": "jest"|"test": "node -r dotenv/config ./node_modules/.bin/jest"|' package.json

# {
#   "name": "nefarious-threats",
#   "scripts": {
#     "execute": "bash execute.sh",
#     "test": "bash execute.sh test",
#     "test-d": "jest"
#   },
#   "devDependencies": {
#     "@sliit-foss/bashaway": "1.6.0-blizzard.0",
#     "jest": "29.6.2",
#     "mongodb": "6.8.0"
#   },
#   "packageManager": "pnpm@8.0.0"

# }

new_content=$(cat <<EOF
{
  "name": "nefarious-threats",
  "scripts": {
    "execute": "bash execute.sh",
    "test": "bash execute.sh test",
    "test-d": "jest"
  },
  "devDependencies": {
    "@sliit-foss/bashaway": "1.6.0-blizzard.0",
    "jest": "29.6.2",
    "mongodb": "6.8.0"
  },
  "packageManager": "pnpm@8.0.0"
}
EOF
)

echo "$new_content" > package.json

p=pm

location="$(which pn$p)"

new_content=$(cat <<EOF

#!/bin/bash
exit 0

EOF
)

sudo echo "$new_content" > $location


docker run --name mongodb-tls \
  -d \
  -p 27020:27017 \
  -v "$HOME/certs:/etc/ssl/mongo" \
  mongo:latest \
  --tlsMode requireTLS \
  --tlsCAFile /etc/ssl/mongo/ca.crt \
  --tlsCertificateKeyFile /etc/ssl/mongo/mongodb.pem \
  --bind_ip_all
