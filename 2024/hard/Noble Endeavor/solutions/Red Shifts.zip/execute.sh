#! /bin/bash

# Read the file src/scroll-libero.json
# and store the content in a variable

if [ ! -f src/scroll-*.sql ]; then
    echo "File not found"
    exit 0
fi


FILE_NAME=$(find src -maxdepth 1 -type f -name "scroll-*")
SQL=$(cat $FILE_NAME)

DB_NAME=$(echo "$SQL" | head -n 1 | tail -n 1 | awk '{print $3}' | tr -d ';')
TABLE_NAME=$(echo "$SQL" | head -n 3 | tail -n 1 | awk '{print $3}')
COLUMNS=$(echo "$SQL" | head -n 3 | tail -n 1 | sed -n 's/.*(\(.*\));/\1/p' | tr ', ' ' ' | sed 's/`//g')
read -a COLUMN_ARRAY <<< $(echo "$COLUMNS" | sed 's/INT//g; s/ *$//; s/^ *//; s/  */ /g')


# VALUES=$( echo "$SQL" | sed -n 's/.*VALUES (\(.*\));/\1/p' | tr '), (' '\n')
VALUES=$( echo "$SQL" | sed -n 's/.*VALUES (\(.*\));/\1/p')

# echo "]);"

for row in "${COLUMN_ARRAY[@]}"; do
    echo "$row"
done


IFS=', ' read -r -a rows <<< $(echo $VALUES | tr -d '()')

row_count=$((${#rows[@]} / ${#COLUMN_ARRAY[@]}))
echo "Row count is: "
echo $row_count
echo "Column count is: "
echo ${COLUMN_ARRAY[@]}
echo ${#COLUMN_ARRAY[@]}


echo $TABLE_NAME

# MongoDB connection details
MONGO_DATA_DIR="/tmp/mongodata"
MONGO_LOG_FILE="/tmp/mongolog"
MONGO_HOST="localhost"
MONGO_PORT="27020"
DB_NAME=$DB_NAME
USERNAME="admin"
PASSWORD="3aDAl3vfeRbY1lf"
COLLECTION_NAME=$TABLE_NAME

# Create data directory if it doesn't exist
mkdir -p $MONGO_DATA_DIR

# Start MongoDB
# mongod --dbpath $MONGO_DATA_DIR --port $MONGO_PORT --logpath $MONGO_LOG_FILE --fork
docker run -d -p $MONGO_PORT:27017 --name noble mongo

if [ $? -ne 0 ]; then
    echo "Failed to start MongoDB. Check the log file at $MONGO_LOG_FILE"
    exit 0
fi

# Create admin user
mongosh --port $MONGO_PORT <<EOF
use $DB_NAME
db.createUser({
  user: "$USERNAME",
  pwd: "$PASSWORD",
  roles: [{ role: "dbOwner", db: "$DB_NAME" }]
})
EOF

if [ $? -eq 0 ]; then
    echo "User created successfully with dbOwner role for $DB_NAME database."
else
    echo "Failed to create user."
    exit 0
fi

echo "MongoDB started successfully."

# Connect with authentication and create collection and document
mongosh --port $MONGO_PORT -u $USERNAME -p $PASSWORD --authenticationDatabase $DB_NAME << EOF
use $DB_NAME
db.createCollection("$COLLECTION_NAME")
EOF

for i in {0..9}
do
    row_output="{"
    for j in "${!COLUMN_ARRAY[@]}"
    do
        value="${rows[$((i * ${#COLUMN_ARRAY[@]} + j))]}"
        row_output+="'${COLUMN_ARRAY[$j]}': $value"
        
        # Add a separator (tab) if it's not the last column
        if [ $j -lt $((${#COLUMN_ARRAY[@]} - 1)) ]; then
            row_output+=$', '
        fi
    done
    row_output+="}"
    printf "%s\n" "$row_output"
    # Connect with authentication and create collection and document
    mongosh --port $MONGO_PORT -u $USERNAME -p $PASSWORD --authenticationDatabase $DB_NAME << EOF
    use $DB_NAME
    db.$COLLECTION_NAME.insertOne($row_output)
EOF
done