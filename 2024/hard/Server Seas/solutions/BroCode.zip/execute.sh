#!/bin/bash

# Install HAProxy if not installed
if ! command -v haproxy &> /dev/null; then
    echo "HAProxy not found, installing..."
    sudo apt-get update
    sudo apt-get install -y haproxy
    echo "HAProxy installed"
fi
check_server() {
    nc -z localhost $1
    return $?
}

all_servers_running=true

check_server 11001 || all_servers_running=false
check_server 11002 || all_servers_running=false
check_server 11003 || all_servers_running=false

if [ "$all_servers_running" = true ]; then
    # Create HAProxy configuration
    cat <<EOL > haproxy.cfg
global
    log /dev/log    local0
    log /dev/log    local1 notice
    chroot /var/lib/haproxy
    stats socket /run/haproxy/admin.sock mode 660 level admin
    stats timeout 30s
    user haproxy
    group haproxy
    daemon

defaults
    log     global
    mode    http
    option  httplog
    option  dontlognull
    timeout connect 5000
    timeout client  50000
    timeout server  50000

frontend http_front
    bind localhost:11000
    default_backend http_back

backend http_back
    balance roundrobin
    server server1 localhost:11001 check
    server server2 localhost:11002 check
    server server3 localhost:11003 check
EOL

    echo "HAProxy configuration created"
    # Start HAProxy with the new configuration
    sudo -S haproxy -f haproxy.cfg

    sudo rm -rf haproxy.cfg

    echo "HAProxy started"
else
    echo "One or more servers are not running. HAProxy will not be started."
fi