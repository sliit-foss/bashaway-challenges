cat <<EOF > tmp
# Check if Nginx is installed
if ! command -v nginx &> /dev/null; then
    sudo apt update
    sudo apt install -y nginx

    sudo service nginx start
    exit 0
else
    echo "Nginx is already installed."
fi


cat <<EOL | sudo tee /etc/nginx/conf.d/load_balancer.conf
upstream backend {
    server localhost:11001;
    server localhost:11002;
    server localhost:11003;
}

server {
    listen 11000;
    listen [::]:11000;

    location / {
        proxy_pass http://backend;
    }
}
EOL

echo "Configuration is valid. Restarting Nginx..."
sudo service nginx restart


echo "Nginx load balancer is running on port 11000, balancing traffic to ports 11001, 11002, and 11003."
EOF

mv tmp execute.sh