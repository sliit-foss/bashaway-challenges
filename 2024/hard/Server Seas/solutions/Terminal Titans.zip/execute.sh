#!/bin/bash

PORT=11001

if ! command -v caddy &> /dev/null; then

    sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list
    sudo apt update
    sudo apt install caddy
else
    echo "Caddy is already installed."
fi

CADDYFILE="/etc/caddy/Caddyfile"


if nc -z localhost $PORT; then
    echo "Server is running on port $PORT."
    #sudo systemctl start haproxy
else
    echo "No server is running on port $PORT."
    exit
fi

sudo bash -c "cat > $CADDYFILE" <<EOF
{
    http_port 11000
}

:11000 {
    # Reverse proxy to specified backends
    reverse_proxy {
        to localhost:11001 localhost:11002 localhost:11003
    }

}
EOF

#caddy validate --config $CADDYFILE

sudo systemctl restart caddy

sleep 5

