#!/bin/bash


# Variables
CADDY_VERSION="latest"  # You can specify a version or keep it as latest
CADDY_DIR="$HOME/caddy"
CADDYFILE="$CADDY_DIR/Caddyfile"
REVERSE_PROXIES=("http://localhost:11001" "http://localhost:11002" "http://localhost:11003")

# Function to check if a server is reachable using curl
check_servers() {
    for server in "${REVERSE_PROXIES[@]}"; do
        echo "Checking $server..."
        if ! curl --silent --head --fail "$server" > /dev/null; then
            echo "Error: $server is not reachable."
            return 1
        fi
    done
    return 0
}

# Step 1: Download the Caddy binary
echo "Downloading Caddy..."
mkdir -p "$CADDY_DIR"  # Ensure the directory is created
wget https://github.com/caddyserver/caddy/releases/download/v2.8.4/caddy_2.8.4_linux_amd64.tar.gz
tar xvf caddy_2.8.4_linux_amd64.tar.gz -C "$CADDY_DIR"

# Step 2: Move the binary to /usr/local/bin
echo "Installing Caddy..."
sudo mv "$CADDY_DIR/caddy" /usr/local/bin/
sudo chmod +x /usr/local/bin/caddy

# Clean up
rm -r ./caddy*

# Step 3: Create Caddy configuration directory
echo "Creating Caddy configuration directory..."

# Step 4: Write the Caddyfile
echo "Writing Caddyfile..."
cat <<EOF > "$CADDYFILE"
http://localhost:11000 {
    reverse_proxy {
        to localhost:11001
        to localhost:11002
        to localhost:11003
        lb_policy round_robin
        health_interval 5s
        health_timeout 2s
        health_status 200
    }
}
EOF

# Step 5: Check if reverse proxy servers are reachable
echo "Checking if reverse proxy servers are reachable..."
if check_servers; then
    echo "All reverse proxy servers are reachable. Starting Caddy server..."
    caddy run --config "$CADDYFILE" &
    echo "Caddy load balancer is running at http://localhost:11000"
else
    echo "One or more reverse proxy servers are not reachable. Caddy will not be started."
    exit 0
fi


echo "Caddy server stopped and port is now available."
sleep 20 && killall caddy &