# test cadddy has been installed if not install it
if [ -z "$(command -v caddy)" ]; then
    sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https curl
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list
    sudo apt update
    sudo apt install caddy

    sudo apt install screen

else
    echo "RUN"
    cat <<EOL >Caddyfile
:11000 {
    reverse_proxy  {
        to localhost:11001 localhost:11002 localhost:11003
        lb_policy round_robin
    }
}
EOL
    sudo caddy stop
    screen -dmS sudo caddy run --config Caddyfile

    sleep 3

    rm -f Caddyfile

fi
