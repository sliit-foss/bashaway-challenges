#!/bin/bash

# Define ports
SERVER1_PORT=11001
SERVER2_PORT=11002
SERVER3_PORT=11003
LOAD_BALANCER_PORT=11000

# Function to check if a port is in use
check_port() {
    lsof -i :$1 &> /dev/null
}

sudo sysctl -w net.ipv6.conf.all.disable_ipv6=1
sudo sysctl -w net.ipv6.conf.default.disable_ipv6=1


# Check if all three backend servers are running
if ! check_port $SERVER1_PORT; then
    echo "Error: Server on port $SERVER1_PORT is not running."
fi

if ! check_port $SERVER2_PORT; then
    echo "Error: Server on port $SERVER2_PORT is not running."
fi

if ! check_port $SERVER3_PORT; then
    echo "Error: Server on port $SERVER3_PORT is not running."
fi

echo "All required backend servers are running. Proceeding with HAProxy setup..."


# Install HAProxy if it's not already installed
if ! command -v haproxy &> /dev/null; then
    echo "HAProxy is not installed. Installing HAProxy..."
    sudo apt-get update
    sudo apt-get install -y haproxy
    echo "HAProxy installed successfully."
else
    echo "HAProxy is already installed."
fi

# Create HAProxy configuration file
HAPROXY_CONFIG="/etc/haproxy/haproxy.cfg"

# Backup existing HAProxy configuration
if [ -f "$HAPROXY_CONFIG" ]; then
    sudo cp "$HAPROXY_CONFIG" "$HAPROXY_CONFIG.bak"
fi

# Write new HAProxy configuration
cat <<EOL | sudo tee "$HAPROXY_CONFIG" > /dev/null
global
    log /dev/log local0
    maxconn 2000

defaults
    log global
    mode http
    option httplog
    balance roundrobin
    option httpchk
    timeout client 30s
    timeout server 30s
    timeout connect 5s

frontend http_front
    bind *:$LOAD_BALANCER_PORT
    default_backend http_back

backend http_back
    balance roundrobin
    server server1 127.0.0.1:$SERVER1_PORT check
    server server2 127.0.0.1:$SERVER2_PORT check
    server server3 127.0.0.1:$SERVER3_PORT check
EOL

# sudo ufw allow 11000

curl http://127.0.0.1:11001
curl http://127.0.0.1:11002
curl http://127.0.0.1:11003


# Restart HAProxy to apply the new configuration only if the servers are running
echo "Starting HAProxy..."
sudo systemctl stop haproxy
sudo systemctl start haproxy

sudo ufw status
cat /var/log/haproxy.log
sudo lsof -i :11000

ifconfig


echo "Load balancer set up successfully on port $LOAD_BALANCER_PORT!"
