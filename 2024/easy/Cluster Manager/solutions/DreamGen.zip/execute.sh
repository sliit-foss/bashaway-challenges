#!/bin/bash

# Start Minikube to create a local Kubernetes cluster
minikube start --driver=docker

# Set the current context to Minikube
kubectl config use-context minikube

# Create the bashaway namespace
kubectl create namespace bashaway

# Verify the namespace has been created
kubectl get namespaces
