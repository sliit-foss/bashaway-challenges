#!/bin/bash

# Start local Kubernetes cluster with Minikube
echo "Starting local Kubernetes cluster..."
minikube start --driver=docker

# Check if the cluster started successfully
if [ $? -ne 0 ]; then
    echo "Failed to start Minikube cluster. Exiting."
    exit 1
fi

# Set the current context to the Minikube cluster
echo "Setting current context to Minikube..."
kubectl config use-context minikube

# Create the bashaway namespace
echo "Creating bashaway namespace..."
kubectl create namespace bashaway

# Verify that the namespace was created
echo "Verifying namespaces..."
kubectl get namespaces

# Check if the bashaway namespace is active
if kubectl get namespaces | grep -q "bashaway"; then
    echo "Namespace bashaway created successfully and is active."
else
    echo "Failed to create bashaway namespace."
    exit 1
fi

sleep 30

echo "Cluster setup complete."
