#!/bin/bash

# Start a local Kubernetes cluster if not already running
if ! kubectl cluster-info > /dev/null 2>&1; then
    echo "Starting local Kubernetes cluster..."
    minikube start
fi

# Set the current context to the local cluster
kubectl config use-context minikube

# Create the bashaway namespace if it doesn't exist
if ! kubectl get ns bashaway > /dev/null 2>&1; then
    echo "Creating bashaway namespace..."
    kubectl create namespace bashaway
    if [ $? -ne 0 ]; then
        echo "Failed to create bashaway namespace"
        exit 1
    fi
else
    echo "bashaway namespace already exists"
fi

# Verify the namespace creation
echo "Verifying namespaces..."
kubectl get ns

echo "Cluster setup complete."