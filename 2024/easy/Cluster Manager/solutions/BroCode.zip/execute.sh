#!/bin/bash

# Exit script if any command fails
set -e

# Check if Minikube is installed
if ! command -v minikube &> /dev/null
then
    echo "Minikube could not be found, please install it first."
    exit 1
fi

# Start Minikube cluster
echo "Starting Minikube cluster..."
minikube start

# Ensure that the Minikube context is set
echo "Setting Minikube as the current context..."
kubectl config use-context minikube

# Check if the bashaway namespace already exists
if kubectl get namespace bashaway &> /dev/null
then
    echo "Namespace 'bashaway' already exists."
else
    # Create the bashaway namespace
    echo "Creating namespace 'bashaway'..."
    kubectl create namespace bashaway
fi

# Verify the namespace is listed
echo "Verifying the 'bashaway' namespace..."
if kubectl get namespaces | grep -q 'bashaway'; then
    echo "'bashaway' namespace is successfully created and listed."
else
    echo "Failed to create 'bashaway' namespace."
    exit 1
fi

echo "Kubernetes cluster with 'bashaway' namespace is set up successfully."

