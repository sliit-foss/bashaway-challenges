#!/bin/bash

create_cluster() {
    echo "Creating Kubernetes cluster..."
    kind create cluster --name underworld-cluster
}

set_context() {
    echo "Setting current context to the new cluster..."
    kubectl config use-context kind-underworld-cluster
}

create_namespace() {
    echo "Creating bashaway namespace..."
    kubectl create namespace bashaway
}

check_namespace() {
    echo "Checking if bashaway namespace exists..."
    if kubectl get namespaces | grep -q "bashaway"; then
        echo "Namespace bashaway created successfully."
    else
        echo "Failed to create namespace bashaway."
    fi
}

create_cluster
set_context
create_namespace
check_namespace
