
sudo snap install microk8s --classic --channel=latest/stable

sudo snap install kubectl --classic
mkdir $HOME/.kube
CONFIG=$(sudo microk8s config)
echo "$CONFIG" > $HOME/.kube/config

kubectl create namespace bashaway
