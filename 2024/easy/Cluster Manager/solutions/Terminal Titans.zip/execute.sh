#!/bin/bash

# Start a local Kubernetes cluster using Minikube
minikube start

# Set the cluster as the current context
kubectl config use-context minikube

# Create the bashaway namespace
kubectl create namespace bashaway

# Display the namespaces to confirm that bashaway namespace is present
kubectl get namespaces
