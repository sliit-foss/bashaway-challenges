#!/bin/bash

# Start Minikube
minikube start

# Set the Kubeconfig environment variable
export KUBECONFIG=$(minikube kubeconfig)

# Ensure Minikube context is set
kubectl config use-context minikube

# Wait for the Kubernetes API to be accessible
until kubectl get nodes; do
    echo "Waiting for Kubernetes API..."
    sleep 5
done

kubectl create namespace bashaway

kubectl get namespaces
