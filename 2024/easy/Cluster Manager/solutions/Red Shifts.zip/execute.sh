#!/bin/bash

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check for required tools
if ! command_exists kubectl || ! command_exists kind; then
    echo "Error: kubectl and kind are required. Please install them first."
    exit 1
fi

# Create a Kind cluster
echo "Conjuring the underworld cluster..."
kind create cluster --name underworld-cluster

# Set the current context to the new cluster
kubectl config use-context kind-underworld-cluster

# Create the bashaway namespace
echo "Opening the portal to the bashaway realm..."
kubectl create namespace bashaway

# Verify the namespace creation
echo "Verifying the existence of the bashaway realm..."
kubectl get namespaces

echo "The underworld cluster is ready. Those who fail shall be banished to the bashaway namespace!"