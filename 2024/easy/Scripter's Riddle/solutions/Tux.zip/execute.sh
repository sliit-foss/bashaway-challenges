#!/usr/bin/env bash

curl -s https://api.ipify.org
