#!/bin/bash

# Fetch the public IP address using a service like 'ifconfig.me'
public_ip=$(curl -s ifconfig.me)

# Print the public IP address to the console
echo "$public_ip"
