public_ip=$(curl -s ifconfig.me)

# Print the result to the console.
echo $public_ip