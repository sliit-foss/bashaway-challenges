#!/bin/bash

ip=$(curl ipinfo.io/ip)

echo $ip