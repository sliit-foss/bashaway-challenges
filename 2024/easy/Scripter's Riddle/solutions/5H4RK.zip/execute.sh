#!/bin/bash
echo "$(curl -s ifconfig.me)"