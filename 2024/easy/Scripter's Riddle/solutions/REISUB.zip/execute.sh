#!/bin/bash
curl -s ifconfig.me
