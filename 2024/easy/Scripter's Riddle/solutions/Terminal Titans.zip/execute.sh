#!/bin/bash
curl ipinfo.io/ip
