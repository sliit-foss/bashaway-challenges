#!/bin/bash
command -v curl >/dev/null 2>&1 || { echo >&2 "curl is required but not installed."; exit 1; }
curl -s ifconfig.me

