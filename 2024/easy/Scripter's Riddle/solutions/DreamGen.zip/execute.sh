#!/bin/bash

public_ip=$(curl -s https://ifconfig.me)

echo "$public_ip"
