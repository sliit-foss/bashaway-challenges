#! bin/bash

if [$# -eq 0];
then
    exit 0
fi

iso_time=$1
EPOCH_SECONDS=$(date -d "$iso_time" +%s)
echo $EPOCH_SECONDS