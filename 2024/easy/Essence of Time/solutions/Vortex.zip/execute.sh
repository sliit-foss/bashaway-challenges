#!/bin/bash

if [ -n "$1" ]; then
    iso="$1"
    epoch=$(date -d "$iso" +"%s")
    echo "$epoch"
fi

