#!/bin/bash

if [ $# -eq 0 ]; then
  exit 0
fi

iso_to_epoch() {
  date -d "$1" +%s
}

if ! iso_to_epoch "$1" >> /dev/null 2>&1; then
  echo "Invalid ISO timestamp: $1"
  exit 1
fi

echo "$(iso_to_epoch "$1")"
