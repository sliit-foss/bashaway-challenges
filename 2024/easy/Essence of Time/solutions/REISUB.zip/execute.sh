#!/bin/bash

convert_to_epoch() {
    epoch=$(date -d "$1" +"%s" 2>/dev/null)
    if [ $? -ne 0 ]; then
        echo "Invalid ISO timestamp."
    else
        echo $epoch
    fi
}

if [ -z "$1" ]; then
    echo "No timestamp provided. Please enter a timestamp in ISO format (e.g., 2022-01-01T00:00:00Z):"
    read input_timestamp
    convert_to_epoch "$input_timestamp"
else
    convert_to_epoch "$1"
fi
