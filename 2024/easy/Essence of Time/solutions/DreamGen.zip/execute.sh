#!/bin/bash

if [ -z "$1" ]; then
    exit 0
fi

timestamp="$1"

epoch=$(date -d "$timestamp" +%s 2>/dev/null)

if [ $? -ne 0 ]; then
    echo "Invalid timestamp format."
    exit 1
fi

echo "$epoch"
