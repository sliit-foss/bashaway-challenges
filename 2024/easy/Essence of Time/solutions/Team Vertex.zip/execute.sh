#!/bin/bash

convert_to_epoch() {
    local iso_timestamp="$1"
    local offset=19800  # Fixed offset in seconds

    # Check if the input is provided
    if [[ -z "$iso_timestamp" ]]; then
        echo "Error: No input provided."
        exit 1
    fi

    # Convert the ISO timestamp to epoch
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        epoch=$((date -j -f "%Y-%m-%dT%H:%M:%SZ" "$iso_timestamp" +%s 2>/dev/null) + offset)

        if [[ $? -ne 0 ]]; then
            # Try without the 'Z' for local time interpretation
            epoch=$(date -j -f "%Y-%m-%dT%H:%M:%S" "$iso_timestamp" +%s 2>/dev/null)
        fi

        epoch=$((epoch + offset))
    else
        # Linux
        epoch=$(date -d "$iso_timestamp" +%s 2>/dev/null)
        
        if [[ $? -ne 0 ]]; then
            # Try without the 'Z'
            epoch=$(date -d "${iso_timestamp:0:-1}" +%s 2>/dev/null)
        fi
    fi

    # Check if the conversion was successful
    if [[ $? -ne 0 || -z "$epoch" ]]; then
        echo "Error: Invalid ISO timestamp."
        exit 1
    fi

    # Add the fixed offset to the epoch time
    
    echo "$epoch"
}

output=$(convert_to_epoch "$1")
echo "$output" 
