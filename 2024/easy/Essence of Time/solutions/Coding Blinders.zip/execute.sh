#!/bin/bash

# Check if a timestamp is provided
if [ -z "$1" ]; then
  echo "No timestamp provided"
  exit 0
fi

# Convert ISO 8601 timestamp to epoch time (seconds since 1970-01-01)
# Using date command to parse the input and convert it to seconds
epoch_time=$(date -d "$1" +"%s" 2>/dev/null)

# Check if the conversion was successful
if [ $? -eq 0 ]; then
  echo "$epoch_time"
else
  echo "Invalid timestamp format"
  exit 1
fi
