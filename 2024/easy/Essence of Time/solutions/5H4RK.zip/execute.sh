#!/bin/bash

epoch=$(date -d "$1" +"%s" 2>/dev/null)
echo "$epoch"