#!/bin/bash


epoch_timestamp=$(date -d "$1" +%s 2>/dev/null)

# Check if the conversion was successful
if [ $? -ne 0 ]; then
    echo "Invalid ISO timestamp format."
    exit 1
fi

# Output the epoch timestamp
echo "$epoch_timestamp"
