#!/bin/bash

# Check if an argument is provided
if [ -z "$1" ]; then
  echo "No input provided. Please provide an ISO timestamp."

fi

# Convert ISO timestamp to epoch timestamp using date
epoch=$(date -u -d "$1" +%s 2>/dev/null)

# Check if the conversion was successful
if [ $? -ne 0 ]; then
  echo "Invalid ISO timestamp format."
 
fi

# Output the epoch timestamp
echo "$epoch"
