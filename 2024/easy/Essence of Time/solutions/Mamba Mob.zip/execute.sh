#!/bin/bash

# Default timestamp if none is provided
DEFAULT_TIMESTAMP="1970-01-01T00:00:00Z"

# Check if an argument is provided; if not, use the default
if [ -z "$1" ]; then
  TIMESTAMP="$DEFAULT_TIMESTAMP"
else
  TIMESTAMP="$1"
fi

# Attempt to convert the ISO timestamp to epoch
epoch=$(date -d "$TIMESTAMP" +%s 2>/dev/null)

# Fallback for systems where the first method fails (like macOS)
if [ $? -ne 0 ]; then
  epoch=$(date -j -f "%Y-%m-%dT%H:%M:%SZ" "$TIMESTAMP" +%s 2>/dev/null)
fi

# Check if the conversion was successful
if [ $? -ne 0 ] || [ -z "$epoch" ]; then
  echo "Invalid timestamp format."
  exit 1
fi

# Output the epoch timestamp
echo "$epoch"
