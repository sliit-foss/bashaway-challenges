#!/bin/bash

if [ -n "$1" ]; then
  date -d "$1" +%s
else
  echo "0"
fi