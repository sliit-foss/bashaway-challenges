#!/bin/bash

# Function to convert ISO 8601 to epoch
iso_to_epoch() {
    local iso_time="$1"
    if [[ -z "$iso_time" ]]; then
        echo "Error: No input provided"
        return 1
    fi
    
    # Use date command to convert ISO 8601 to epoch
    if date -d "$iso_time" +%s 2>/dev/null; then
        return 0
    elif date -j -f "%Y-%m-%dT%H:%M:%SZ" "$iso_time" +%s 2>/dev/null; then
        return 0
    else
        echo "Error: Invalid date format"
        return 1
    fi
}

# Main script
if [[ $# -eq 0 ]]; then
    echo "Error: No input provided"
else
    iso_to_epoch "$1"
fi