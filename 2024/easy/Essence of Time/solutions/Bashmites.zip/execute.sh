#!/bin/bash

while true; do
  # Check if a timestamp was provided as an argument
  if [ -z "$1" ]; then
    read -p "Please provide an ISO timestamp: " input
  else
    input=$1
    shift
  fi

  # Convert the provided ISO timestamp to epoch time
  epoch_time=$(date -d "$input" +%s 2>/dev/null)

  # Check if the conversion was successful
  if [ $? -eq 0 ]; then
    # Valid timestamp, print epoch time and exit the loop
    echo "$epoch_time"
    break
  else
    # Invalid timestamp, prompt again
    echo "Invalid timestamp format. Please provide a valid ISO timestamp."
    # Clear input so it loops again
    input=""
  fi
done
