#!/bin/bash

if [ -z "$1" ]; then
  exit 0
fi

epoch=$(date -d "$1" +"%s" 2>/dev/null)

if [ $? -eq 0 ]; then
  echo "$epoch"
else
  exit 1
fi