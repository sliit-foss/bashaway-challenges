#!/bin/bash
# Convert the ISO timestamp to epoch using date command
# -u ensures the timestamp is treated as UTC
epoch_timestamp=$(date -u -d "$1" +"%s" 2>/dev/null)

# Check if the conversion succeeded
if [ $? -eq 0 ]; then
  echo "$epoch_timestamp"
else
  echo "Invalid ISO timestamp format. Please provide a valid ISO timestamp."
  exit 1
fi

