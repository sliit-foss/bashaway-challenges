#!/bin/bash

# # Check if an argument is provided
# if [ -z "$1" ]; then
#   echo "No input provided"
#   exit 0  # Exit gracefully with code 0 to avoid failing tests
# fi

# Convert the ISO 8601 timestamp to epoch seconds
date_input="$1"
epoch_time=$(date -d "$date_input" +%s 2>/dev/null)

# Check if date conversion was successful
if [ $? -eq 0 ]; then
  echo "$epoch_time"
else
  echo "Invalid date format"
  exit 1
fi
