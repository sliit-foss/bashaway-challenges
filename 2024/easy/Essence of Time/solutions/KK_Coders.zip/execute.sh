# Check if an argument is provided
if [ -z "$1" ]; then
  echo "No ISO timestamp provided."
fi

# Convert the provided ISO timestamp to epoch timestamp
epoch=$(date -d "$1" +%s 2>/dev/null)

# Check if the conversion was successful
if [ $? -eq 0 ]; then
  echo "$epoch"
else
  echo "Invalid ISO timestamp."
fi
