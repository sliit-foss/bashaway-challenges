#!/bin/bash

# Check if a date argument is provided
if [ -z "$1" ]; then
  # No argument provided, output current timestamp
  EPOCH_TIME=$(date +%s)
else
  # Convert the given date-time argument to an epoch timestamp (in seconds)
  DATE_INPUT="$1"
  EPOCH_TIME=$(date -d "$DATE_INPUT" +%s 2>/dev/null)

  # Check if the date conversion failed
  if [ -z "$EPOCH_TIME" ]; then
    echo "Error: Invalid date format. Please provide a valid ISO date."
    exit 1
  fi
fi

# Output the epoch time
echo "$EPOCH_TIME"
