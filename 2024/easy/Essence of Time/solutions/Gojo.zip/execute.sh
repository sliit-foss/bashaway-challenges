#!/bin/bash

# Check if an argument is provided
if [ -z "$1" ]; then
  echo "Input the correct ISO timestamp"
else 
    epoch_timestamp=$(date -d "$1" +%s)
    echo $epoch_timestamp

fi


