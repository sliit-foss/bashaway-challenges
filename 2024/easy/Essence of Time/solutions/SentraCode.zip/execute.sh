#!/bin/bash

convert_to_epoch() {
    if [[ $(uname) == "Darwin" ]]; then
        date -j -f "%Y-%m-%dT%H:%M:%SZ" "$1" "+%s" 2>/dev/null
    else
        date -d "$1" "+%s" 2>/dev/null
    fi
}

if [ $# -eq 0 ]; then
    exit 0
fi

epoch=$(convert_to_epoch "$1")


if [ -z "$epoch" ]; then
    exit 0
fi

echo "$epoch"