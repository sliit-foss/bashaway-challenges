if [ -z "$1" ]; then
    echo "No input provided. Please provide an ISO timestamp."
    exit 0
fi

epoch=$(date -d "$1" +%s)

if [ $? -ne 0 ]; then
    echo "Invalid ISO timestamp format."
    exit 0
fi

echo "$epoch"