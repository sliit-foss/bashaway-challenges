#!/bin/bash

# Get the system uptime in seconds
uptime_seconds=$(awk '{print int($1+0.5)}' /proc/uptime)

# Print the uptime in the required format
echo "System uptime: $uptime_seconds"