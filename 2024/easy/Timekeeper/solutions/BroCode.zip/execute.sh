#!/bin/bash

# Get the system uptime in seconds
uptime_seconds=$(awk '{print $1}' /proc/uptime)

# Round the uptime to the nearest whole number
rounded_uptime=$(printf "%.0f" "$uptime_seconds")

# Print the uptime in the required format
echo "System uptime: $uptime_seconds"