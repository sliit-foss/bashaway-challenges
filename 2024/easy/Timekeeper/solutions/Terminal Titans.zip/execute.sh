#!/bin/bash

# Get the system uptime in seconds
uptime_seconds=$(cat /proc/uptime | awk '{print $1}')

# Round the uptime to the nearest whole number
rounded_uptime=$(printf '%.0f' "$uptime_seconds")

# Print the result in the required format
echo "System uptime: $rounded_uptime"