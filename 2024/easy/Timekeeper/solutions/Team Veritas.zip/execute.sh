#!/bin/bash

start_time=$(date -d "$(uptime -s)" +%s)

# Get the current time in seconds since the epoch
current_time=$(date +%s)

# Calculate the uptime in seconds
uptime_seconds=$(echo "$current_time - $start_time" | bc)

# Round to the nearest whole number
rounded_uptime_seconds=$(printf "%.0f" "$uptime_seconds")

# Print the result
echo "System uptime: $rounded_uptime_seconds"