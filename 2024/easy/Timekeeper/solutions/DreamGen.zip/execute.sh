uptime=$(awk '{print $1}' /proc/uptime)
formatted=$(printf "%.0f" "$uptime")
echo "System uptime: $formatted"