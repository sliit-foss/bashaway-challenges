#!/bin/bash

uptime_seconds=$(awk '{print int($1 + 0.5)}' /proc/uptime)

echo "System uptime: $uptime_seconds"