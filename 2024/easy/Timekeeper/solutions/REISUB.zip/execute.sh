#!/bin/bash

uptime_seconds=$(cat /proc/uptime | awk '{print $1}')
rounded_uptime=$(printf "%.0f" "$uptime_seconds")
echo "System uptime: $rounded_uptime"
