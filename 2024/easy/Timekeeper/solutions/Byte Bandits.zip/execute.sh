#!/bin/bash

# Fetch the uptime in seconds from /proc/uptime
uptime_seconds=$(awk '{print $1}' /proc/uptime)

# Round the uptime to the nearest whole number
uptime_seconds_rounded=$(printf "%.0f" "$uptime_seconds")

# Output the result in the required format: "System uptime: X seconds"
echo "System uptime: $uptime_seconds_rounded"

