#!/bin/bash

# Retrieve uptime in seconds
uptime_seconds=$(awk '{print int($1)}' /proc/uptime)

# Print the uptime in the required format
echo "System uptime: $uptime_seconds"
