#!/bin/bash

if [ -z "$1" ]; then
  exit 0
fi

branch_prefix="$1"

branches_to_delete=$(git branch --list "$branch_prefix*")

if [ -z "$branches_to_delete" ]; then
  exit 0
fi

for branch in $branches_to_delete; do
  git branch -D "$branch"
done