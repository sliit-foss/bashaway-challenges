#!/bin/bash
prefix="$1"

branches=$(git branch --format="%(refname:short)" | grep -v '^main$')

for branch in $branches; do
    if [[ $branch == $prefix/* ]]; then
        echo "Deleting branch: $branch"
        git branch -D "$branch"
    fi
done