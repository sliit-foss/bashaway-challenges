#!/bin/bash


branch_prefix="$1"

# Get a list of all local branches that start with the given prefix
branches_to_delete=$(git branch --list "$branch_prefix*")

# Loop through and delete each matching branch
for branch in $branches_to_delete; do
  if [ "$branch" != "main" ]; then
    echo "Deleting branch: $branch"
    git branch -D "$branch"
  fi
done

echo "Operation completed."

