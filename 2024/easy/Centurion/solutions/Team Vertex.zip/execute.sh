if [ -z "$1" ]; then
    echo "No prefix provided"
    exit 0
fi

PREFIX="$1"
branches=$(git branch --format='%(refname:short)' | grep "^$PREFIX")
if [ -z "$branches" ]; then
    echo "No matching found"
    exit 0
fi

git branch -D $branches
echo "Deleted matched branches"
