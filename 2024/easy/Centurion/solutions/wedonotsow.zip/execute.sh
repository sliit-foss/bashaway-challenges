#!/bin/bash

# Check if a branch prefix is provided
if [ -z "$1" ]; then
  echo "No branch prefix provided. Exiting."
  exit 0
fi

# Get the branch prefix from the first argument
branch_prefix="$1"

# Get a list of branches that start with the given prefix
branches_to_delete=$(git branch --format="%(refname:short)" | grep "^$branch_prefix")

# Check if there are any branches to delete
if [ -z "$branches_to_delete" ]; then
  echo "No branches found with prefix '$branch_prefix'."
  exit 0
fi

# Delete each branch
for branch in $branches_to_delete; do
  git branch -D "$branch"
done

echo "Deleted branches with prefix '$branch_prefix'."