#!/bin/bash

# Check if a branch name argument is provided
if [ -z "$1" ]; then
  echo "Please provide a branch name to delete."
  exit 0
fi

# Define the branch name pattern to match
branch_pattern="$1*"

# Get all branches in the current directory
branches=$(git branch --list)

# Loop through each branch and delete if it matches the pattern
for branch in $branches; do
  if [[ $branch == $branch_pattern ]]; then
    echo "Deleting branch: $branch"
    git branch -d "$branch" || echo "Error deleting branch: $branch"
  fi
done

echo "Branch deletion complete."