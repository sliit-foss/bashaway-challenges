if [ -z "$1" ]; then
  echo "No branch name prefix provided. Exiting."
  exit 0
fi

branch_prefix=$1

branches_to_delete=$(git branch --format="%(refname:short)" | grep "^$branch_prefix")

if [ -z "$branches_to_delete" ]; then
  echo "No branches found with prefix '$branch_prefix'."
  exit 0
fi

for branch in $branches_to_delete; do
  git branch -D "$branch"
  echo "Deleted branch: $branch"
done

echo "All branches starting with '$branch_prefix' have been deleted."