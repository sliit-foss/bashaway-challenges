#!/bin/bash

# Check if a branch name is provided
if [ -z "$1" ]; then
  echo "No branch name provided. Exiting without making changes."
  exit 0
fi

# Store the branch prefix
branch_prefix="$1"

# Fetch all branches that start with the given prefix
branches_to_delete=$(git branch --list "${branch_prefix}*")

# Check if there are any branches to delete
if [ -z "$branches_to_delete" ]; then
  echo "No branches starting with '$branch_prefix' found."
  exit 0
fi

# Delete the branches
echo "Deleting branches starting with '$branch_prefix':"
echo "$branches_to_delete"

# Use a loop to delete each branch
for branch in $branches_to_delete; do
  # Trim whitespace
  branch=$(echo "$branch" | xargs)
  
  # Delete the branch
  git branch -d "$branch" || echo "Failed to delete branch '$branch'. It may not be fully merged."
done

echo "Deletion process completed."
