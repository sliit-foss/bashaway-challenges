#!/bin/bash

if [ -z "$1" ]; then
  exit 0
fi

PREFIX=$1
branches=$(git branch --list "$PREFIX*" | sed 's/*//g' | tr -d ' ')

if [ -z "$branches" ]; then
  exit 0
fi

for branch in $branches; do
  git branch -D "$branch"
  echo "Deleted branch: $branch"
done
