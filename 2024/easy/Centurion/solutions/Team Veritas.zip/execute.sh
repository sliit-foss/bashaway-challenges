#!/bin/bash

if [ -z "$1" ]; then
  exit 0
fi

prefix=$1

branches=$(git branch --list "$prefix*")

for branch in $branches; do
  git branch -D "$branch"
done