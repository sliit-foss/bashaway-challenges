#!/bin/bash

if [ -z "$1" ]; then
    # echo "Please provide a branch name prefix."
    exit 0
fi

BRANCH_PREFIX=$1

BRANCHES=$(git branch --list "$BRANCH_PREFIX*" | sed 's/*//g' | awk '{$1=$1};1')

if [ -z "$BRANCHES" ]; then
    echo "No branches found with the prefix '$BRANCH_PREFIX'."
    exit 0
fi

echo "The following branches will be deleted:"
echo "$BRANCHES"

echo "$BRANCHES" | while read -r BRANCH; do
    git branch -D "$BRANCH"
done

echo "Branches deleted successfully."

