#!/bin/bash

# Check if an argument (branch name) is provided
if [ -z "$1" ]; then
  echo "No branch name provided. Please provide a branch name."
fi

# Store the provided branch name
branch_prefix="$1"

# Fetch all branches that start with the provided name
branches_to_delete=$(git branch | grep "^  $branch_prefix")

# Check if any branches match
if [ -z "$branches_to_delete" ]; then
  echo "No branches starting with '$branch_prefix' found."
else
  # Delete the matching branches
  echo "Deleting branches starting with '$branch_prefix':"
  for branch in $branches_to_delete; do
    git branch -d "${branch#* }"  # Remove leading spaces and delete the branch
    echo "Deleted branch: ${branch#* }"
  done
fi
