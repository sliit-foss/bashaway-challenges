#!/bin/bash

if [ -n "$1" ]; then # Check if a branch name prefix is provided
  git branch | grep "^\s*$1" | cut -c 3- | xargs -n1 git branch -D
fi