#!/bin/bash

# Function to generate a random string
generate_random_string() {
    # Generate a random string of 8 characters
    echo "random_branch_$RANDOM"
}

# Check if a branch name is provided; if not, generate a random one
if [ -z "$1" ]; then
    BRANCH_PREFIX=$(generate_random_string)
    echo "No branch name provided. Using random branch prefix: '$BRANCH_PREFIX'"
else
    BRANCH_PREFIX="$1"
    echo "Using provided branch prefix: '$BRANCH_PREFIX'"
fi

# Fetch all branches starting with the provided or random prefix
BRANCHES_TO_DELETE=$(git branch --list "${BRANCH_PREFIX}*")

# Check if there are any branches to delete
if [ -z "$BRANCHES_TO_DELETE" ]; then
    echo "No branches found starting with '$BRANCH_PREFIX'. Exiting..."
    exit 0
fi

# Iterate over each branch and delete it
echo "Deleting branches starting with '$BRANCH_PREFIX':"
for branch in $BRANCHES_TO_DELETE; do
    # Remove leading whitespace from branch name
    branch=$(echo "$branch" | xargs)
    echo "Deleting branch: $branch"
    git branch -d "$branch" 2>/dev/null || git branch -D "$branch"  # Force delete if necessary
done

echo "Deletion complete."
