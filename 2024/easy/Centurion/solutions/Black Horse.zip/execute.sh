#!/bin/bash

if [[ -z "$1" ]]; then
  echo "Please provide a branch name."
 
fi

BRANCH_NAME=$1

git branch --list "$BRANCH_NAME*" | grep -v '\*' | while read -r branch; do
  git branch -D "$branch"
done
