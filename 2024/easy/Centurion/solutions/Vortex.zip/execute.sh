#!/bin/bash

# Check if a branch name argument is provided
if [ -n "$1" ]; then
# Store the branch name prefix
BRANCH_NAME_PREFIX="$1"

# Fetch the list of branches starting with the specified name
BRANCHES_TO_DELETE=$(git branch --list "${BRANCH_NAME_PREFIX}*")

# Check if any branches match the specified prefix
if [ -z "$BRANCHES_TO_DELETE" ]; then
    echo "No branches starting with '$BRANCH_NAME_PREFIX' found."
    exit 0
fi

# Delete the matched branches
echo "Deleting branches starting with '$BRANCH_NAME_PREFIX':"
for branch in $BRANCHES_TO_DELETE; do
    # Strip leading spaces
    branch=$(echo $branch | xargs)
    echo "Deleting branch: $branch"
    git branch -d "$branch" 2>/dev/null || git branch -D "$branch" # -d attempts a safe delete, -D forces delete
done

echo "Deletion completed."
fi


