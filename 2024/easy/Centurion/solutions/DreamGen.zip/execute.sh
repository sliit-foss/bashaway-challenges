#!/bin/bash

if ! command -v git &> /dev/null; then
    echo "git command not found. Please install git."
    exit 1
fi

if ! git rev-parse --is-inside-work-tree &> /dev/null; then
    echo "Not in a Git repository. Please navigate to a valid Git repository."
    exit 1
fi

if [ -z "$1" ]; then
    exit 0  
fi

BRANCH_PREFIX=$1

git branch --list "$BRANCH_PREFIX*" | sed 's/^[ *]*//' | xargs -r git branch -D &>/dev/null
