#!/bin/bash

chmod +x "$0"

if [ $# -eq 0 ]; then
    exit 0
fi

branch_prefix="$1"

git switch main

git branch | grep "^[[:space:]]*$branch_prefix" | while read -r branch; do
    git branch -D "${branch##*( )}"
done