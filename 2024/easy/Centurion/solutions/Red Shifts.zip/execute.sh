#!/bin/bash

# Check if a branch name argument is provided
if [ -z "$1" ]; then
  exit 0
fi

branch_prefix=$1

# Fetch the latest branches from the remote
git fetch --prune

# Find all local branches that start with the provided name
branches=$(git branch --list "$branch_prefix*")

# Check if there are any branches to delete
if [ -z "$branches" ]; then
  exit 0
fi

# Delete the branches
for branch in $branches; do
  git branch -D "$branch"
done
