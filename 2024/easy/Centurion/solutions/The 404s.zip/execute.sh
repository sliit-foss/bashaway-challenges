#!/bin/bash

# Check if the branch prefix is provided
if [ -z "$1" ]; then
  echo "No branch prefix provided. Exiting."
  exit 0
fi

branch_prefix="$1"

# Get all branches that start with the provided prefix
branches_to_delete=$(git branch --format="%(refname:short)" | grep "^$branch_prefix")

# If no branches match the prefix, print a message and exit
if [ -z "$branches_to_delete" ]; then
  echo "No branches found with the prefix '$branch_prefix'."
  exit 0
fi

# Loop through the branches and delete them
for branch in $branches_to_delete; do
  current_branch=$(git branch --show-current)
  if [ "$branch" != "$current_branch" ]; then
    git branch -D "$branch"
    echo "Deleted branch: $branch"
  else
    echo "Skipping the current branch: $branch"
  fi
done

exit 0
