#!/bin/bash

# Create the out directory if it doesn't exist
mkdir -p out

# Function to replicate the directory structure and copy files
replicate_structure() {
    local src_dir=$1
    local out_dir=$2

    # Loop through all files and directories in the current src directory
    for item in "$src_dir"/*; do
        if [ -d "$item" ]; then
            # If it's a directory, create the same directory in out and call the function recursively
            local subdir=$(basename "$item")
            mkdir -p "$out_dir/$subdir"
            replicate_structure "$item" "$out_dir/$subdir"
        elif [ -f "$item" ] && [[ "$item" == *.js ]]; then
            # If it's a .js file, copy it with _clone suffix in the out directory
            local filename=$(basename "$item" .js)
            cp "$item" "$out_dir/${filename}_clone.js"
            echo "Copying $item to $out_dir/${filename}_clone.js"

        fi
    done
}

# Start the replication from the root of src
replicate_structure "src" "out"
