#! /bin/bash

outDirectory="out"
inDirectory="src"

mkdir -p "$outDirectory"

find "$inDirectory" -type f -name "*.js" | while read -r file; do
    # Get the relative path of the file
    relative_path="${file#$inDirectory/}"
    
    # Create the necessary directories in the backup location
    backup_path="$outDirectory/$(dirname "$relative_path")"
    mkdir -p "$backup_path"
    
    # Construct the new filename
    base=$(basename "$file" .js)
    new_file="$backup_path/${base}_clone.js"
    
    # Copy the file to the new location with the new name
    cp "$file" "$new_file"
    
done