#!/bin/bash

# Define source and destination directories
SRC_DIR="src"
OUT_DIR="out"

# Create the directory structure in the out directory
find "$SRC_DIR" -type d | while read -r dir; do
  mkdir -p "$OUT_DIR/${dir#$SRC_DIR/}"
done

# Find all .js files in the src directory and copy them to the out directory with _clone suffix
find "$SRC_DIR" -type f -name "*.js" | while read -r file; do
  # Get the relative path of the file
  relative_path="${file#$SRC_DIR/}"
  # Create the destination path with _clone suffix
  dest_path="$OUT_DIR/${relative_path%.js}_clone.js"
  # Copy the file to the destination path
  cp "$file" "$dest_path"
done
