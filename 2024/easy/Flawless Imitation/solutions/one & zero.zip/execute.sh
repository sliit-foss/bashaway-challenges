#!/bin/bash

SRC_DIR="src"
OUT_DIR="out"

if [ ! -d "$SRC_DIR" ]; then
  echo "Source directory 'src' not found!"
  exit 1
fi

find "$SRC_DIR" -type f -name "*.js" | while read -r FILE; do
  RELATIVE_PATH="${FILE#$SRC_DIR/}"

  OUT_PATH="$OUT_DIR/$(dirname "$RELATIVE_PATH")"
  
  mkdir -p "$OUT_PATH"

  DEST_FILE="$OUT_PATH/$(basename "$RELATIVE_PATH" .js)_clone.js"

  echo "Copying $FILE to $DEST_FILE"

  cp "$FILE" "$DEST_FILE"
done

echo "All .js files have been copied to the out directory with _clone suffix."