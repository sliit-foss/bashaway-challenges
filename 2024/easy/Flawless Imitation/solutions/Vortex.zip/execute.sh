#!/bin/bash

# Define the source and destination directories
SRC="src"
OUT="out"

# Create the out directory if it doesn't exist
mkdir -p "$OUT"

# Function to copy files and directories
copy_structure() {
    local current_dir="$1"
    local target_dir="$2"

    # Create the target directory
    mkdir -p "$target_dir"

    # Iterate over files and directories in the current directory
    for item in "$current_dir"/*; do
        if [[ -d "$item" ]]; then
            # If it's a directory, recurse
            copy_structure "$item" "$target_dir/$(basename "$item")"
        elif [[ -f "$item" ]]; then
            # If it's a file, check if it's a .js file
            if [[ "$item" == *.js ]]; then
                # Copy the .js file with the suffix _close
                cp "$item" "$target_dir/$(basename "${item%.js}")_clone.js"
            else
                # Otherwise, just copy the file
                cp "$item" "$target_dir/$(basename "$item")"
            fi
        fi
    done
}

# Start copying from the src directory to the out directory
copy_structure "$SRC" "$OUT"
