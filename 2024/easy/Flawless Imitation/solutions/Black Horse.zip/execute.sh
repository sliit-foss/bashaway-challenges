#!/bin/bash

# Set the source and output directories
src="src"
out="out"

# Use find to locate all .js files in src
find "$src" -type f -name "*.js" | while read -r file; do
    # Construct the output path, replacing "src" with "out" and appending "_clone" to the filename
    output_file="${file/src/$out}"
    output_file="${output_file%.js}_clone.js"
    
    # Create the directory structure in the out directory
    mkdir -p "$(dirname "$output_file")"
    
    # Copy the file to the new location with the "_clone" suffix
    cp "$file" "$output_file"
done
