#!/bin/bash

# Define source and output directories
src_dir="src"
out_dir="out"

# Check if src directory exists
if [ ! -d "$src_dir" ]; then
  echo "Source directory 'src' does not exist."
  exit 1
fi

# Find all .js files in the src directory and iterate over them
find "$src_dir" -type f -name "*.js" | while read -r filepath; do
  # Get the directory path of the current file relative to src
  relative_dir=$(dirname "${filepath#$src_dir/}")
  
  # Create the corresponding directory structure in out directory
  mkdir -p "$out_dir/$relative_dir"
  
  # Extract the filename from the path
  filename=$(basename "$filepath")
  
  # Define the new filename with the _clone suffix
  new_filename="${filename%.js}_clone.js"
  
  # Copy the file to the new location with the updated filename
  cp "$filepath" "$out_dir/$relative_dir/$new_filename"
done

echo "Copying complete. All .js files have been suffixed with _clone and placed in the 'out' directory."
