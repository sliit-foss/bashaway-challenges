#!/bin/bash

# Define source and destination directories
SRC_DIR="src"
OUT_DIR="out"

# Check if the source directory exists
if [ ! -d "$SRC_DIR" ]; then
  echo "Source directory '$SRC_DIR' does not exist."
  exit 1
fi

# Create the output directory if it doesn't exist
mkdir -p "$OUT_DIR"

# Function to copy and rename .js files
copy_js_files() {
  # Loop through all .js files in the source directory and its subdirectories
  find "$SRC_DIR" -type f -name '*.js' | while read -r file; do
    # Get the directory path relative to the source directory
    relative_path="${file#$SRC_DIR/}"
    
    # Create the target directory in the output directory
    target_dir="$OUT_DIR/$(dirname "$relative_path")"
    mkdir -p "$target_dir"

    # Define the new file name with the _clone suffix
    target_file="$target_dir/$(basename "$file" .js)_clone.js"

    # Copy the file to the target location
    cp "$file" "$target_file"
  done
}

# Execute the function
copy_js_files

echo "Flawless imitation complete. Check the '$OUT_DIR' directory for the clones."

