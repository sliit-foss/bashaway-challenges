cp -r ./src ./out
find ./out -type f -name "*.js" | while read file; do
  # Extract the directory and filename
  dir=$(dirname "$file")
  filename=$(basename "$file" | cut -d'.' -f1 )
  filename="$filename"_clone.js
  mv "$file" "$dir/$filename"
done