rm -rf ./out
mkdir -p ./out

find ./src -type f -name "*.js" | while read -r file; do
    relative_path="${file#./src/}"
    
    out_dir="./out/$(dirname "$relative_path")"
    
    mkdir -p "$out_dir"
    
    cp "$file" "$out_dir/$(basename "$file" .js)_clone.js"
done