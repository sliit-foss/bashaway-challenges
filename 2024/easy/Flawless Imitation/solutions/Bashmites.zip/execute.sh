#!/bin/bash

# Function to copy .js files and append _clone
copy_js_files() {
  # Create the 'out' directory if it doesn't exist
  mkdir -p out

  # Iterate over all .js files in the src directory and its subdirectories
  find src -type f -name "*.js" | while read -r file; do
    # Get the directory of the file
    dir=$(dirname "$file")
    # Get the base filename without extension
    base=$(basename "$file" .js)
    # Construct the new filename with _clone suffix
    new_file="${base}_clone.js"

    # Create the necessary subdirectory structure in the out directory
    output_dir="out/${dir#src/}"  # Remove "src/" from the path
    mkdir -p "$output_dir"

    # Copy the file to the new location with the new name
    cp "$file" "$output_dir/$new_file"
  done
}

# Call the function to start copying files
copy_js_files

echo "All .js files have been copied to the out directory with the _clone suffix."
