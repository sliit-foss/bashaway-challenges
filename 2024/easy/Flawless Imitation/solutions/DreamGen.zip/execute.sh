#!/bin/bash

src_dir="src"
out_dir="out"

rm -rf "$out_dir"
mkdir -p "$out_dir"

find "$src_dir" -type f -name "*.js" | while read -r file; do
    relative_path="${file#$src_dir/}"

    file_dir=$(dirname "$relative_path")

    filename=$(basename "$relative_path" .js)

    mkdir -p "$out_dir/$file_dir"

    cp "$file" "$out_dir/$file_dir/${filename}_clone.js" || {
        echo "Failed to copy $file"
        exit 1
    }


    echo "Copied $file to $out_dir/$file_dir/${filename}_clone.js"
done

echo "All .js files copied with _clone suffix."
