#!/bin/bash

# Create the out directory if it doesn't exist
mkdir -p out

# Find all .js files in the src directory and its subdirectories
find src -type f -name "*.js" | while read -r file; do
    # Get the directory path relative to src
    rel_path=${file#src/}
    dir_path=$(dirname "$rel_path")
    
    # Create the corresponding directory in out
    mkdir -p "out/$dir_path"
    
    # Get the filename without the path
    filename=$(basename "$file")
    
    # Create the new filename with _clone appended before the .js extension
    new_filename="${filename%.js}_clone.js"
    
    # Copy the file to the new location with the new name
    cp "$file" "out/$dir_path/$new_filename"
done