#!/bin/bash

find src -name "*.js" -print0 | while IFS= read -r -d $'\0' file; do
  dir=$(dirname "$file" | sed "s|^src|out|")  # Replace src with out in the path
  filename=$(basename "$file")
  mkdir -p "$dir"
  cp "$file" "${dir}/${filename%.*}_clone.js"  # Copy with _clone suffix
done