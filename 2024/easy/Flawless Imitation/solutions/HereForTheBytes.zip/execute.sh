#!/bin/bash

cp -r "src" "out"

find "out" -type f -name "*.js" | while read file; do
    base_name=$(basename "$file" .js)
    dir_name=$(dirname "$file")
    mv "$file" "$dir_name/${base_name}_clone.js"
done