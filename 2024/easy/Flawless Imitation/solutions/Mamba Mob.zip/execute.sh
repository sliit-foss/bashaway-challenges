#!/bin/bash

# Define source and output directories
SRC_DIR="src"
OUT_DIR="out"

# Create the output directory if it doesn't exist
mkdir -p "$OUT_DIR"

# Function to copy .js files with _clone suffix
copy_js_files() {
    local current_dir="$1"
    local relative_path="${current_dir#$SRC_DIR/}"

    # Create corresponding directory in out
    mkdir -p "$OUT_DIR/$relative_path"

    # Loop through all .js files in the current directory
    for file in "$current_dir"/*.js; do
        if [[ -f "$file" ]]; then
            # Get the base name of the file
            base_name=$(basename "$file")
            # Construct new file name with _clone suffix
            new_file_name="${base_name%.js}_clone.js"
            # Copy file to out directory with new name
            cp "$file" "$OUT_DIR/$relative_path/$new_file_name"
        fi
    done

    # Loop through subdirectories and call this function recursively
    for dir in "$current_dir"/*/; do
        if [[ -d "$dir" ]]; then
            copy_js_files "$dir"
        fi
    done
}

# Start copying from the src directory
copy_js_files "$SRC_DIR"