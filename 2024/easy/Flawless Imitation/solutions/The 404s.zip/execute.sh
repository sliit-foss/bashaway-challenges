#!/bin/bash

# Define the source and target directories
src="src"
out="out"

# Remove the out directory if it exists to ensure a clean start
if [ -d "$out" ]; then
    rm -rf "$out"
fi

# Create the out directory
mkdir -p "$out"

# Function to copy and rename .js files with "_clone" suffix
copy_and_rename_js_files() {
    local src_path=$1
    local out_path=$2

    # Iterate through all files in the source path
    for file in "$src_path"/*; do
        if [ -d "$file" ]; then
            # If it's a directory, create the corresponding directory in out and recurse
            local new_dir="$out_path/$(basename "$file")"
            mkdir -p "$new_dir"
            copy_and_rename_js_files "$file" "$new_dir"
        elif [ -f "$file" ] && [[ "$file" == *.js ]]; then
            # If it's a JavaScript file, copy it with the "_clone" suffix
            local new_file="$out_path/$(basename "${file%.js}")_clone.js"
            cp "$file" "$new_file"
        fi
    done
}

# Call the function to start copying from src to out
copy_and_rename_js_files "$src" "$out"
