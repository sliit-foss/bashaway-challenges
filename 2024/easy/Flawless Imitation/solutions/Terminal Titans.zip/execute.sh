#!/bin/bash

if [ ! -d "src" ]; then
  echo "src directory does not exist"
  exit 1
fi

mkdir -p out

find src -type f -name "*.js" | while read file; do
  new_file="out/$(echo "$file" | sed 's/src\///' | sed 's/.js$/_clone.js/')"
  mkdir -p "$(dirname "$new_file")"
  cp "$file" "$new_file"
done
