#!/bin/bash

# Ensure the out directory exists
mkdir -p out

# Function to replicate files and directories
copy_files() {
  local src_path="$1"
  
  # Find all .js files in the src_path
  find "$src_path" -type f -name "*.js" | while read -r file; do
    # Get the relative path of the file from the src_path
    relative_path="${file#$src_path/}"

    # Create the corresponding directory in the out directory
    out_dir="out/$(dirname "$relative_path")"
    mkdir -p "$out_dir"

    # Construct the new filename with _clone suffix
    out_file="$out_dir/$(basename "$relative_path" .js)_clone.js"
    
    # Copy the file to the new location with the new name
    cp "$file" "$out_file"
  done
}

# Start copying from the src directory to out
copy_files "src"
