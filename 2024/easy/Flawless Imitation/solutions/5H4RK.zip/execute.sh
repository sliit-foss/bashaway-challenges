#!/bin/bash

# Find all .js files in the src directory
find src -type f -name "*.js" | while read -r file; do
  # Determine the relative path from src
  relative_path="${file#src/}"
  
  # Determine the directory path in the out directory
  out_dir="out/$(dirname "$relative_path")"
  
  # Create the corresponding directory in the out directory
  mkdir -p "$out_dir"
  
  # Determine the new file name with _clone suffix
  base_name="$(basename "$relative_path" .js)"
  new_file="$out_dir/${base_name}_clone.js"
  
  # Copy the file to the new location with the _clone suffix
  cp "$file" "$new_file"
done