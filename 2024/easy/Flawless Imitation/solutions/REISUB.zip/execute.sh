#!/bin/bash
src_dir="./src"
out_dir="./out"

clone_files() {
    local current_dir=$1 

    for file_path in "$current_dir"/*; do
        if [[ -d "$file_path" ]]; then
            local relative_path="${file_path#$src_dir/}"
            mkdir -p "$out_dir/$relative_path"
            clone_files "$file_path"
        elif [[ -f "$file_path" && "$file_path" == *.js ]]; then
            local relative_path="${file_path#$src_dir/}"
            local out_file="${out_dir}/${relative_path%.js}_clone.js"
            cp "$file_path" "$out_file"
        fi
    done
}

mkdir -p "$out_dir"
clone_files "$src_dir"
