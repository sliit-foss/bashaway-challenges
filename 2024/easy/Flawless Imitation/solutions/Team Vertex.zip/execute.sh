#!/bin/bash

# Define source and output directories
SRC_DIR="src"
OUT_DIR="out"

# Create the out directory if it does not exist
mkdir -p "$OUT_DIR"

# Find all .js files in the src directory
find "$SRC_DIR" -type f -name "*.js" | while read -r file; do
  # Remove the SRC_DIR prefix from the file path to get the relative path
  relative_path="${file#$SRC_DIR/}"

  # Generate the corresponding output path in the out directory with _clone suffix
  out_file="$OUT_DIR/${relative_path%.js}_clone.js"

  # Create the directory structure in the out directory
  mkdir -p "$(dirname "$out_file")"

  # Copy and rename the file to the out directory
  cp "$file" "$out_file"
done