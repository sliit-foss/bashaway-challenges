mkdir -p out

find src -type f | while read -r file; do
  relative_path="${file#src/}"
  out_dir="out/$(dirname "$relative_path")"
  mkdir -p "$out_dir"
  
  filename=$(basename "$file")
  extension="${filename##*.}"
  
  if [[ $extension == "js" ]]; then
    cp "$file" "$out_dir/${filename%.js}_clone.js"
  else
    cp "$file" "$out_dir/$filename"
  fi
done