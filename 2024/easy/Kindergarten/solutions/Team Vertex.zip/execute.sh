#!/bin/bash

# Check if an argument is provided
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <number>"
    echo "Please provide a number to check if it is odd or even."
    exit 0
fi

number="$1"

# Check if the input is a valid integer
if ! [[ "$number" =~ ^-?[0-9]+$ ]]; then
    echo "Invalid input. Please provide a valid integer."
    exit 1
fi

# Determine if the number is odd or even
if (( number % 2 == 0 )); then
    echo "Even"
else
    echo "Odd"
fi


