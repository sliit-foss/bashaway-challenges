#!/bin/bash

# Check if a number was provided as an argument
if [ -z "$1" ]; then
  echo "Please provide a number as an argument."
  exit 0
fi

# Check if the input is a valid number
if ! [[ "$1" =~ ^-?[0-9]+$ ]]; then
  echo "Please provide a valid number."
  exit 0
fi

# Determine if the number is odd or even
if [ $(($1 % 2)) -eq 0 ]; then
  echo "Even"
else
  echo "Odd"
fi
