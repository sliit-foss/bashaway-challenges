#!/bin/bash

# Check if a number was provided
if [ $# -eq 0 ]; then
    echo "Please provide a number to check!"
fi

# Get the number from command line argument
number=$1

# Check if the input is a valid number
if ! [[ "$number" =~ ^[0-9]+$ ]]; then
    echo "Please provide a valid number!"
fi

# Check if the number is even or odd using modulo operator
if [ $((number % 2)) -eq 0 ]; then
    echo "Even"
else
    echo "Odd"
fi