#!/bin/bash

# Set a default value
default_value=1

# Check if a number is provided as an argument, else use the default value
if [ -z "$1" ]; then
    number=$default_value
else
    number=$1
fi

# Check if the input is a valid number
if ! [[ "$number" =~ ^-?[0-9]+$ ]]; then
    echo "Please provide a valid integer."
    exit 1
fi

# Determine if the number is even or odd
if (( number % 2 == 0 )); then
    echo "Even"
else
    echo "Odd"
fi

