#!/bin/bash

# Use a default value if no argument is provided (e.g., default to 2)
number=${1:-2}

# Check if the input is a valid number
if ! [[ "$number" =~ ^[0-9]+$ ]]; then
  echo "Invalid input"
  exit 1
fi

# Determine if the number is odd or even
if (( number % 2 == 0 )); then
  echo "Even"
else
  echo "Odd"
fi
