#!/bin/bash

if [ -z "$1" ]; then
    exit 0
fi

number="$1"

if ! [[ "$number" =~ ^-?[0-9]+$ ]]; then
    exit 0
fi

if (( number % 2 == 0 )); then
    output="Even"
else
    output="Odd"
fi

echo "$output"
