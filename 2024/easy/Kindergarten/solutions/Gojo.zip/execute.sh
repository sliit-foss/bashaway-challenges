#!/bin/bash

# Check if input is provided
if [ -z "$1" ]; then
    echo "Error: No input provided. Please enter a number."
    
else 
    input=$1

# Check if input is a valid number (positive or negative integer)
    if ! [[ "$input" =~ ^-?[0-9]+$ ]]; then
        echo "Error: Please enter a valid number."
        
    else 
        if [ $((input % 2)) -eq 1 ] || [ $((input % 2)) -eq -1 ]; then
            echo "Odd"
        else
            echo "Even"
        fi


    fi



    

fi


