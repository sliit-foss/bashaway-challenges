#!/bin/bash

# Check if a number is provided
if [ -z "$1" ]; then
  # If no argument is provided, silently exit
  exit 0
fi

# Get the number from the first argument
number=$1

# Check if the number is even or odd
if (( number % 2 == 0 )); then
    echo "Even"
else
    echo "Odd"
fi
