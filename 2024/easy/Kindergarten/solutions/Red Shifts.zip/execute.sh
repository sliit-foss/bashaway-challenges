#!/bin/bash
if [ -z "$1" ]; then
  exit
fi
if ! [[ "$1" =~ ^-?[0-9]+$ ]]; then
  exit
fi
number=$1
if (( number % 2 == 0 )); then
  echo "Even"
else
  echo "Odd"
fi