if [ -z "$1" ]; then
  echo "No number provided. Using default value 0."
  number=0  # Default value
else
  number=$1
fi

if ! [[ "$number" =~ ^-?[0-9]+$ ]]; then
  echo "Please provide a valid number."
  exit 1
fi

if (( number % 2 == 0 )); then
  echo "Even"
else
  echo "Odd"
fi
