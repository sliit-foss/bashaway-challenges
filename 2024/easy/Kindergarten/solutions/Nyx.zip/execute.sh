number=${1:-0} # Use the first argument, or 0 if no argument is provided

if (( number % 2 == 0 )); then
  echo "Even"
else
  echo "Odd"
fi
