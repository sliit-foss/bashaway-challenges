#!/bin/bash

# Function to check if the number is odd or even
check_odd_even() {
  if [ $(( $1 % 2 )) -eq 0 ]; then
    echo "Even"
  else
    echo "Odd"
  fi
}

# Check if a number is passed as an argument
if [ -z "$1" ]; then
  echo "No number provided. Please run the script with a number as an argument."
  exit 0
fi

# Validate if the input is a valid number
if [[ "$1" =~ ^-?[0-9]+$ ]]; then
  check_odd_even "$1"
else
  echo "Invalid input. Please enter a valid number."
fi
