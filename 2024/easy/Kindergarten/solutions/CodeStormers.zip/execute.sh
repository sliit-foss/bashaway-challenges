#!/bin/bash

# Check if an argument is provided
if [ -z "$1" ]; then
  echo "Even"
  exit 0
fi

# Get the number from the argument
number=$1

# Check if the number is even or odd
if (( number % 2 == 0 )); then
  echo "Even"
else
  echo "Odd"
fi

