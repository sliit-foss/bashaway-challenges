#!/bin/bash

# Check if a number is provided as an argument
if [ -z "$1" ]; then
  exit 0
fi

# Check if the argument is a valid number
if ! [[ "$1" =~ ^[0-9]+$ ]]; then
  exit 0
fi

# Determine if the number is odd or even
if (( $1 % 2 == 0 )); then
  echo "Even"
else
  echo "Odd"
fi
