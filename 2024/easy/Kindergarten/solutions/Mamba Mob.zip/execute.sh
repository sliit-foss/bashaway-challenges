#!/bin/bash

# Default number if none provided
if [ -z "$1" ]; then
  number=0  # Default to 0 or any other number you'd prefer
else
  number="$1"
fi

# Check if the input is a valid number
if ! [[ "$number" =~ ^-?[0-9]+$ ]]; then
  echo "Please provide a valid integer."
  exit 1
fi

# Determine if the number is odd or even
if (( number % 2 == 0 )); then
  echo "Even"
else
  echo "Odd"
fi
