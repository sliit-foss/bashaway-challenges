#!/bin/bash

if [[ -z "$1" ]]; then
  echo "Please provide a number."

fi

if (( $1 % 2 == 0 )); then
  echo "Even"
else
  echo "Odd"
fi
