#!/bin/bash

if [ -z "$1" ]; then
  echo "Please provide a number as an argument."
  exit 0
fi

number=$1
if ! [[ "$number" =~ ^-?[0-9]+$ ]]; then
  echo "Invalid input. Please enter a valid integer."
  exit 0
fi

if (( number % 2 == 0 )); then
  echo "Even"
else
  echo "Odd"
fi