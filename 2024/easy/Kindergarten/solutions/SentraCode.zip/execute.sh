#!/bin/bash

chmod +x "$0"

if [ -z "$1" ]; then
  exit 0
fi

if ! [[ "$1" =~ ^-?[0-9]+$ ]]; then
  exit 0
fi

number=$1

if (( number % 2 == 0 )); then
  echo "Even"
else
  echo "Odd"
fi



