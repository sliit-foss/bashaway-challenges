#!/bin/bash
mkdir -p out

# Generate the CSV file
jq -r '(.[0] | keys_unsorted), (.[] | [.[]]) | @csv' src/script.json > out/document2.csv

OUT_DIR="out"
mkdir -p "$OUT_DIR"
rm -f "$OUT_DIR/processed.csv"
INPUT_CSV="out/document2.csv"

awk -F, 'NR==1 {
    # For the first row (header), strip the first and last characters from each field
    for (i = 1; i <= NF; i++) {
        if (length($i) > 2) {
            $i = substr($i, 2, length($i) - 2)
        }
    }
} 
NR > 1 {
    # For all other rows, do nothing (leave the data intact)
}
{ print $0 }' OFS=, "$INPUT_CSV" > "$OUT_DIR/document.csv"

echo "Processed CSV file saved at $OUT_DIR/processed.csv."