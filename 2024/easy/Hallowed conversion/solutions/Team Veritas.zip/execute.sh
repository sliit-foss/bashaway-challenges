#!/bin/bash

# Ensure the 'out' directory is clean before the conversion
rm -rf out
mkdir -p out

# Extract headers from the first object in the JSON and write them to the CSV without quotes
jq -r '.[0] | keys_unsorted | @csv' src/script.json | sed 's/"//g' > "out/document.csv"

# Append the rows from the JSON data, converting each row to CSV format without quotes around values
jq -r 'map([.[]])[] | @csv' src/script.json | sed 's/"//g' >> "out/document.csv"

echo "Conversion complete. The CSV file is located at out/document.csv"