#!/bin/bash
mkdir -p out
jq -r '(.[0] | keys_unsorted), (.[] | map(tostring)) | @csv' src/script.json | sed 's/"//g' > out/document.csv
