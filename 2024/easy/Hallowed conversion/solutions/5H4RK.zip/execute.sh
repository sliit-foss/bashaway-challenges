#!/bin/bash

# Variables
SRC_FILE="src/script.json"
OUT_DIR="out"
OUT_FILE="$OUT_DIR/document.csv"

# Clean and prepare the out directory
mkdir -p "$OUT_DIR"
rm -f "$OUT_DIR"/*

# Convert JSON to CSV using jq, removing double quotes
jq -r '(.[0] | keys_unsorted) as $keys | $keys, map([.[ $keys[] ] | tostring])[] | @csv' "$SRC_FILE" | sed 's/"//g' > "$OUT_FILE"
