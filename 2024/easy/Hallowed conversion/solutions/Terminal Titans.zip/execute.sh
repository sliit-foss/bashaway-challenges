#!/bin/bash

# Define the paths
JSON_FILE="src/script.json"
OUT_DIR="out"
CSV_FILE="$OUT_DIR/document.csv"

# Ensure the out directory is clean
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"

# Convert JSON to CSV
jq -r '(.[0] | keys_unsorted) as $keys | $keys, map([.[ $keys[] ]])[] | @csv' "$JSON_FILE" | sed 's/"//g' > "$CSV_FILE"

echo "Conversion complete. The CSV file is located at $CSV_FILE"
