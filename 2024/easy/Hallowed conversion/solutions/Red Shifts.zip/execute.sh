#!/bin/bash


if [ ! -f src/script.json ]; then
    echo "File not found"
    exit 0
fi

# Ensure jq is installed
if ! command -v jq &> /dev/null; then
    echo "jq is required but not installed. Please install jq."
    exit 1
fi

# Input JSON file (can be redirected from a file or piped)
input_json='src/script.json' # Change this to your input JSON file

mkdir -p out

# Convert JSON to CSV
# Convert JSON to CSV
jq -r '(
    .[0] | keys_unsorted | @csv  # Extract keys for the header
), (
    .[] | [.[]] | @csv             # Extract values for each object
)' "$input_json" | sed 's/"//g' > out/document.csv

echo "Conversion complete. Output written to output.csv."