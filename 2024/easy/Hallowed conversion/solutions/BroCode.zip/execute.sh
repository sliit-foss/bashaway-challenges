#!/bin/bash

# Step 1: Clear the out directory
OUT_DIR="out"
if [ -d "$OUT_DIR" ]; then
  rm -rf "$OUT_DIR"/*
else
  mkdir "$OUT_DIR"
fi

# Step 2: Read the JSON file
JSON_FILE="src/script.json"
if [ ! -f "$JSON_FILE" ]; then
  echo "JSON file not found!"
  exit 1
fi

# Step 3: Convert JSON to CSV
# Using jq to parse JSON and convert to CSV without quotes
CSV_FILE="$OUT_DIR/document.csv"
jq -r '(.[0] | keys_unsorted) as $keys | $keys, map([.[ $keys[] ]])[] | @csv' "$JSON_FILE" | sed 's/"//g' > "$CSV_FILE"

echo "Conversion complete. CSV file created at $CSV_FILE"