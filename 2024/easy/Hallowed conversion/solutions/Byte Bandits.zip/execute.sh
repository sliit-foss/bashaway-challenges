#!/bin/bash

# Set strict mode to exit immediately on error and treat unset variables as errors
set -euo pipefail

# Define input and output paths
JSON_FILE="./src/script.json"
OUTPUT_DIR="./out"
CSV_FILE="$OUTPUT_DIR/document.csv"

# Function to clean the output directory
clean_output_directory() {
    echo "Ensuring the output directory is clean..."

    if [ -d "$OUTPUT_DIR" ]; then
        echo "Removing existing output directory..."
        rm -rf "$OUTPUT_DIR"  # Use -rf to avoid interactive prompts
        echo "Previous output directory removed."
    fi

    echo "Creating a fresh output directory..."
    mkdir "$OUTPUT_DIR"
    echo "Output directory created."
}

# Function to check if jq is installed
check_jq_installed() {
    echo "Checking for jq installation..."
    if ! command -v jq &> /dev/null; then
        echo "Error: jq is not installed. Please install jq to proceed." >&2
        exit 1
    fi
    echo "jq is installed."
}

# Function to convert JSON to CSV
convert_json_to_csv() {
    # Check if the JSON file exists
    if [ ! -f "$JSON_FILE" ]; then
        echo "Error: JSON file does not exist at $JSON_FILE." >&2
        exit 1
    fi

    echo "Converting JSON to CSV..."

    # Extract headers from the first object in the JSON file
    HEADERS=$(jq -r '.[0] | keys_unsorted | join(",")' "$JSON_FILE")

    # Write headers to the CSV file
    echo "$HEADERS" > "$CSV_FILE"

    # Extract values and ensure they are split into columns correctly
    jq -r '.[] | map(tostring) | join(",")' "$JSON_FILE" >> "$CSV_FILE"

    echo "Conversion successful! CSV file created at $CSV_FILE."
}

# Main execution block
{
    clean_output_directory
    check_jq_installed
    convert_json_to_csv
} || {
    echo "An error occurred during the execution of the script." >&2
    exit 1
}

