#!/bin/bash

mkdir -p out
jq -s '.[0] * .[1]' src/* > out/merged.json

