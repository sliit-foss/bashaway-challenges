mkdir -p out; cat src/* | sed 's/}{/,/g' > out/merged.json
