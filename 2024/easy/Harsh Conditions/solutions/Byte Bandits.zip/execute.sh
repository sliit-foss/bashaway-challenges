#!/bin/sh
mkdir -p out;jq -s add src/*.json>out/merged.json