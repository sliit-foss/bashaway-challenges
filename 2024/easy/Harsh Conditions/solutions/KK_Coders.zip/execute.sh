#!/bin/bash
mkdir -p out; jq -s 'add' src/joint_data.json src/seam_specs.json > out/merged.json