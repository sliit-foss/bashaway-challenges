mkdir -p out
cd src
jq -s '.[0] * .[1]' joint_data.json seam_specs.json > ../out/merged.json