#!/bin/bash

[ $# -eq 0 ] && exit 0

input="$1"
url_encode() {
    local string="$1"
    local length="${#string}"
    local encoded=""
    
    for (( i=0; i<length; i++ )); do
        local c="${string:i:1}"
        if [[ "$c" =~ [a-zA-Z0-9_.!~*\'\(\)-] ]]; then
            encoded="$encoded$c"
        else
            printf -v hex '%%%02X' "'$c"
            encoded="$encoded$hex"
        fi
    done
    
    echo "$encoded"
}

url_encode "$input"