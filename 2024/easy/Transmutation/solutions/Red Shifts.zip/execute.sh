#!/bin/bash

if [[ $1 == "" ]]; then
	exit
fi

ENCODED=$(perl -MURI::Escape -e 'print uri_escape($ARGV[0]);' "$1")

ENCODED=$(sed "s/%28/(/g" <<< $ENCODED)
ENCODED=$(sed "s/%29/)/g" <<< $ENCODED)
ENCODED=$(sed "s/%21/!/g" <<< $ENCODED)
ENCODED=$(sed "s/%2A/*/g" <<< $ENCODED)

echo $ENCODED