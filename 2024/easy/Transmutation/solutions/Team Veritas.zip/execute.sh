#!/bin/bash

# Function to URL encode a string
urlencode() {
    local string="${1}"
    echo "$string" | jq -Rr @uri
}

if [ -z "$1" ]; then
    exit 0
fi

# URL encode the argument and print it
urlencode "$1"