#!/bin/bash

# Check if input is provided
if [ -z "$1" ]; then
  echo 
  exit 0
fi

urlencode() {
  local length="${#1}"
  for (( i = 0; i < length; i++ )); do
    local char="${1:i:1}"
    case "$char" in
      [a-zA-Z0-9.~_-]) printf "%s" "$char" ;;  
      '(') printf "(" ;;
      ')') printf ")" ;;
      ' ') printf "%%20" ;;                   
      '!') printf "!" ;;
      '"') printf "%%22" ;;
      '#') printf "%%23" ;;
      '$') printf "%%24" ;;
      '%') printf "%%25" ;;
      '&') printf "%%26" ;;
      "'") printf "%%27" ;;
      '*') printf "*" ;;
      '+') printf "%%2B" ;;
      ',') printf "%%2C" ;;
      '/') printf "%%2F" ;;
      ':') printf "%%3A" ;;
      ';') printf "%%3B" ;;
      '<') printf "%%3C" ;;
      '=') printf "%%3D" ;;
      '>') printf "%%3E" ;;
      '?') printf "%%3F" ;;
      '@') printf "%%40" ;;
      '[') printf "%%5B" ;;
      '\\') printf "%%5C" ;;
      ']') printf "%%5D" ;;
      '^') printf "%%5E" ;;
      '`') printf "%%60" ;;
      '{') printf "%%7B" ;;
      '|') printf "%%7C" ;;
      '}') printf "%%7D" ;;
      '~') printf "%%7E" ;;
      *) printf "%%%02X" "'$char" ;;  
    esac
  done
  echo
}

urlencode "$1"

exit 0