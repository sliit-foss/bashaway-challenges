#!/bin/bash

# Check if jq is not installed
if ! command -v jq &> /dev/null
then
    echo "jq could not be found. Please install jq to run this script."
    # exit 1
fi

# The script uses 'jq' to URL encode the input string.
# This method requires 'jq' to be installed on the system.

input="$1"

# Check if no input was provided
if [ -z "$input" ]; then
  echo "No input provided."
#   exit 1
fi

# URL encode using jq and remove quotes added by jq
encoded=$(jq -nr --arg arg "$input" '$arg|@uri')

# Print the encoded string
echo "$encoded"
