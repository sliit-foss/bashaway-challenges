#!/bin/bash

urlencode() {
    local length="${#1}"
    for ((i = 0; i < length; i++)); do
        local c="${1:i:1}"
        case $c in
        [a-zA-Z0-9.~_-]) printf "$c" ;;
        *) printf '%%%02X' "'$c" ;;
        esac
    done
    printf '\n'
}

if [ -z "$1" ]; then
    echo "No input provided."
else

    res=$(urlencode "$1")
    res=$(echo $res | sed 's/%2A/*/g' | sed 's/%28/(/g' | sed 's/%29/)/g' | sed 's/%21/!/g')
    echo $res

fi
