#!/bin/bash

# Check if an argument is provided
if [ -z "$1" ]; then
  echo "No input provided"
fi

# URL encode the input string
encoded=$(printf '%s' "$1" | jq -sRr @uri)

# Print the encoded string
echo "$encoded"