#!/bin/bash
if [ -z "$1" ]; then exit 0; fi
echo -n "$1" | jq -sRr @uri

