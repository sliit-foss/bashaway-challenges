#!/bin/bash

# Define the output directory and file

pwd=$(pwd)

# Define the output directory and file
output_dir="$pwd/out"
output_file="$output_dir/numbers.txt"

# Create the output directory if it doesn't exist
mkdir -p "$output_dir"

# Start a new background process (child process) for logging random numbers
(
  while true; do
      # Generate a random number
      random_number=$RANDOM

      # Append the random number to the file with a timestamp
      echo "$(date +%Y-%m-%d\ %H:%M:%S) - $random_number" >> "$output_file"

      # Sleep for 1 second
      sleep 1
  done
) &

# The process is now running in the background, detached from the main script
