#!/bin/bash

# Step 1: Create the bin directory if it doesn't exist
mkdir -p ~/bin
CURDIR=$(pwd)

mkdir out
touch out/numbers.txt

# Step 2: Create the generate_numbers.sh script in the bin directory
cat << EOF > ~/bin/generate_numbers.sh
#!/bin/bash

# Create the output directory if it does not exist
mkdir -p ~/out

# Loop 60 times
for i in {1..60}; do
    # Generate a random number
    RANDOM_NUMBER=\$RANDOM
    
    # Append the random number to the file in the absolute path
    echo "\$RANDOM_NUMBER" >> $CURDIR/out/numbers.txt
    
    # Sleep for 1 second
    sleep 1
done
EOF

# Step 3: Make the generate_numbers.sh script executable
chmod +x ~/bin/generate_numbers.sh

cat ~/bin/generate_numbers.sh

# Step 4: Set up the cron job to execute the script every minute
(crontab -l 2>/dev/null; echo "* * * * * /bin/bash ~/bin/generate_numbers.sh") | crontab -

# Notify the user of the setup
echo "Setup complete. The script is created at ~/bin/generate_numbers.sh and a cron job is scheduled to run it every minute."
sleep 40
cat out/numbers.txt