#!/bin/bash

# Create the output directory if it doesn't exist
mkdir -p ./out

# Infinite loop to write a random number every second
while true; do
    # Generate a random number using $RANDOM and append it to numbers.txt
    echo $RANDOM >> ./out/numbers.txt
    # Wait for 1 second
    sleep 1
done &
