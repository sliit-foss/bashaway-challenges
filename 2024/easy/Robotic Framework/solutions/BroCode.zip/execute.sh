#!/bin/bash

# Ensure the output directory exists
mkdir -p ./out

# Ensure the numbers.txt file exists
touch ./out/numbers.txt

# Continuously generate a random number and append it to the file every second
while true; do
    # Generate a random number and append it to the file
    echo $RANDOM >> ./out/numbers.txt
    # Wait for 1 second
    sleep 1
done &
