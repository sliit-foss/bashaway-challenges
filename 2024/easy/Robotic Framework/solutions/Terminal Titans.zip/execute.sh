#!/bin/bash

# Create the output directory if it doesn't exist
mkdir -p ./out

# Infinite loop to generate random numbers
while true; do
    echo $RANDOM >> ./out/numbers.txt
    echo "Generated number: $RANDOM"  # Debug output to show generated number
    sleep 1  # Sleep for 1 second
done &
