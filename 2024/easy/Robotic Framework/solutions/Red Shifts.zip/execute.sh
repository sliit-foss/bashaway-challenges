#! /bin/bash 

mkdir -p out
path=$(pwd)

cat <<EOF > out/runner.sh
#!/bin/bash

for i in {1..100}; do
    echo "dkjfhsdkjhf" >> $path/out/numbers.txt
    sleep 1
done
EOF

# chmod +x out/run.sh
# echo "Created the script"

# # Define the cron job
# cron_job="* * * * * ./$path/out/run.sh"

# # Add the cron job to the crontab
# (crontab -l; echo "$cron_job") | crontab -


# Path to the logger script
LOGGER_SCRIPT="./out/runner.sh"

# Check if the script is already running
if pgrep -f "$(basename $LOGGER_SCRIPT)" > /dev/null; then
    echo "The logger script is already running."
    exit 1
fi


touch out/out.log
# Run the logger script in the background
nohup bash "$LOGGER_SCRIPT" > out/out.log &

echo "Logger script started in the background. Process ID: $!"
echo "Output is being logged to $OUTPUT_LOG"
echo "To stop the script, run: pkill -f $(basename $LOGGER_SCRIPT)"