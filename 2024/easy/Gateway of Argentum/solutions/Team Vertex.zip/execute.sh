mkdir -p out

{ while read -r card; do
    if [[ -n "$card" ]]; then
        last_four="${card: -4}"
        masked_card="$(echo "${card:0:${#card}-4}" | sed 's/[0-9]/*/g')$last_four"
        echo "$masked_card" >> out/masked.txt
    fi
done } < src/parchment.txt

if [[ -n "$card" ]]; then
    last_four="${card: -4}"
    masked_card="$(echo "${card:0:${#card}-4}" | sed 's/[0-9]/*/g')$last_four"
    echo "$masked_card" >> out/masked.txt
fi

echo "Masked card numbers saved to out/masked.txt."

