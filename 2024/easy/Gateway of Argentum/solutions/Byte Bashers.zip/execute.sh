
mkdir -p out


awk '{ gsub(/[0-9]{12}/, "************"); print }' src/parchment.txt > out/masked.txt
