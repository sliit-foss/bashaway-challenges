#!/bin/bash

# Create the 'out' directory if it doesn't exist
mkdir -p out

# Path to the parchment file
parchment_file="src/parchment.txt"

# Check if 'parchment.txt' exists in the 'src' directory
if [ ! -f "$parchment_file" ]; then
  echo "Error: $parchment_file not found!"
  exit 1
fi

# Open 'masked.txt' for writing in the 'out' directory
output_file="out/masked.txt"

# Clear the output file before appending
> "$output_file"

# Read each line (card number) from 'parchment.txt'
while IFS= read -r card_number || [[ -n "$card_number" ]]; do
  # Check if the line contains exactly 16 digits
  if [[ "$card_number" =~ ^[0-9]{16}$ ]]; then
    # Mask all but the last 4 digits
    masked_card_number="************${card_number: -4}"
    echo "$masked_card_number" >> "$output_file"
  else
    # If it's not a valid card number (16 digits), print an error message
    echo "Invalid card number found: $card_number" >> "$output_file"
  fi
done < "$parchment_file"

echo "Masked card numbers have been written to out/masked.txt."
