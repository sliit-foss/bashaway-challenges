#! /bin/bash

input_file="src/parchment.txt"
output_file="out/masked.txt"

# Create the output file
mkdir -p out
touch "$output_file"

# Loop through each line in the file
while IFS= read -r line; do
    length=${#line}
    mask_length=$((length - 4))
    # Check if the length is greater than 4
    if [ $length -le 4 ]; then
        echo "$input" >> "$output_file"
    else
        # Mask all but the last 4 characters with asterisks
        masked=$(printf "%*s" "$mask_length"  | tr " " "*")
        echo "${masked}${line: -4}" >> "$output_file"  # Output the masked string with the last 4 characters
    fi
done < "$input_file"

# Handle the last line seperately
line=$(tail -n 1 "$input_file")
length=${#line}
mask_length=$((length - 4))
# Check if the length is greater than 4
if [ $length -le 4 ]; then
    echo "$input" >> "$output_file"
else
    # Mask all but the last 4 characters with asterisks
    masked=$(printf "%*s" "$mask_length"  | tr " " "*")
    echo "${masked}${line: -4}" >> "$output_file"  # Output the masked string with the last 4 characters
fi