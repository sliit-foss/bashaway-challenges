#!/usr/bin/env bash

# Create the output directory if it doesn't exist
mkdir -p out

# Read the entire file into a single variable
raw_data=$(cat ./src/parchment.txt)

# Use tr to replace all non-digit characters with spaces
# This will create a space-separated string of card numbers
card_numbers=$(echo "$raw_data" | tr -s '[:space:]' ' ')

# Convert the space-separated string into an array
IFS=' ' read -r -a card_numbers_array <<< "$card_numbers"

# Initialize a variable to hold masked card numbers
masked_numbers=()

# Loop through each card number in the array
for card_number in "${card_numbers_array[@]}"; do
    # Check if the card number is 16 digits long
    if [[ ${#card_number} -eq 16 ]]; then
        echo "Processing card number: '$card_number' with length ${#card_number}"
        
        # Mask the card number
        masked_card_number="************${card_number: -4}"
        echo "Masked card number: '$masked_card_number'"
        
        # Add the masked card number to the array
        masked_numbers+=("$masked_card_number")
    else
        echo "Skipping invalid card number: '$card_number'"
    fi
done

# Output the total number of processed card numbers
echo "Number of masked card numbers processed: ${#card_numbers_array[@]}"

# Write the masked card numbers to out/masked.txt
printf "%s\n" "${masked_numbers[@]}" > out/masked.txt

# Confirm that masked numbers have been written to the file
echo "Masked card numbers have been written to 'out/masked.txt'."
