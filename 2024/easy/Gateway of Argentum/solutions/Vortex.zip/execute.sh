#!/bin/bash

# Create the output directory if it doesn't exist
mkdir -p out

# Define the input and output files
output_file="out/masked.txt"
input_file="src/parchment.txt"

# Clear the output file if it exists
> "$output_file"


while IFS= read -r line || [ -n "$line" ]; do
    # Remove white spaces from the line
    line_no_spaces=$(echo -n "$line" | tr -d ' ')

    length=${#line_no_spaces}


    if [ "$length" -le 4 ]; then
        masked_line="$line_no_spaces"  # No masking needed if 4 or fewer digits
    else
        masked_part=$(printf "%*s" "$((length - 4))" | tr ' ' '*')
        last_four=${line_no_spaces: -4}
        masked_line="${masked_part}${last_four}"
    fi


    echo "$masked_line" >> "$output_file"
done < "$input_file"
