#!/bin/bash

mkdir -p out

> out/masked.txt

while IFS= read -r line || [ -n "$line" ]; do
    line_length=${#line}
    
    if [ $line_length -gt 4 ]; then
        last_four="${line:line_length-4}"
        masked_part=$(printf "%*s" $((line_length-4)) "" | tr ' ' '*')
        masked_line="$masked_part$last_four"
    else
        masked_line="$line"
    fi

    echo -n "$masked_line" >> out/masked.txt
    echo "" >> out/masked.txt
done < ./src/parchment.txt
