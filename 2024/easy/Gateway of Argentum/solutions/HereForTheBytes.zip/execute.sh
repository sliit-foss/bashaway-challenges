#!/bin/bash

# Create the output directory if it doesn't exist
mkdir -p out

# Initialize a counter for card numbers
count=0

# Read from parchment.txt, mask card numbers, and write to masked.txt
while IFS= read -r cardNumber || [[ -n "$cardNumber" ]]; do
    # Skip empty lines or lines with non-numeric characters
    if [[ -z "$cardNumber" || ! "$cardNumber" =~ ^[0-9]+$ ]]; then
        continue
    fi

    # Get the last four digits
    last4="${cardNumber: -4}"
    # Mask all but the last four digits
    maskedCardNumber="$(printf '%s' "${cardNumber:0:-4}" | sed 's/[0-9]/*/g')$last4"
    # Write the masked number to masked.txt
    echo "$maskedCardNumber"
    ((count++))  # Increment the counter for each valid card number
done < src/parchment.txt > out/masked.txt

# Print the total count of processed card numbers
echo "Total masked card numbers: $count"

exit 0
