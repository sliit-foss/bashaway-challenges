#!/bin/bash

PARCHMENT=src/parchment.txt
OUT=out/masked.txt

mkdir -p out
rm -f $OUT 
touch $OUT


while IFS="" read -r line || [[ -n "$line" ]]; do
    printf -- '*%0.s' {1..12} >> $OUT
    echo "${line: -4}" >> $OUT
done < $PARCHMENT

