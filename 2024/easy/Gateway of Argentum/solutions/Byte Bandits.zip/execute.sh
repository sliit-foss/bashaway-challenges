mkdir -p out && awk '{ len=length($0); mask=""; for(i=1;i<len-3;i++){mask=mask"*"} printf("%s%s\n", mask, substr($0, len-3)) }' ./src/parchment.txt > out/masked.txt

