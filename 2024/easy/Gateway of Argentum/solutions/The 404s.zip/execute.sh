#!/bin/bash
#!/bin/bash

# Navigate to the root directory
cd "$(dirname "$0")"

# Create the out directory inside the test folder if it doesn't exist
mkdir -p out

# Mask all digits except for the last four in each line of parchment.txt
awk '{ 
  if (length($0) > 4) {
    masked = sprintf("%0*d", length($0)-4, 0); 
    gsub("0", "*", masked); 
    print masked substr($0, length($0)-3)
  } else {
    print $0
  }
}' src/parchment.txt > out/masked.txt
