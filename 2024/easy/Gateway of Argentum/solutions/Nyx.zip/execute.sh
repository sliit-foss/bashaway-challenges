#!/bin/bash

mkdir -p out

while IFS= read -r card_number || [[ -n "$card_number" ]]; do
  if [[ $card_number =~ ([0-9]{4,})$ ]]; then
    last_four="${BASH_REMATCH[1]: -4}"
    masked_number=$(printf "%${#card_number}s" | tr " " "*" | sed "s/.\{4\}$/$last_four/")
    echo "$masked_number" >> out/masked.txt
  else
    echo "$card_number" >> out/masked.txt
  fi
done < src/parchment.txt