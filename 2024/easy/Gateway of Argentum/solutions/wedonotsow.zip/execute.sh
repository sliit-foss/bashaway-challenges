#!/bin/bash

# Create the output directory if it doesn't exist
mkdir -p out


while IFS= read -r line || [ -n "$line" ]; do

    line=$(echo "$line" | tr -d '[:space:]')
    

    if [ -n "$line" ]; then

        last_four="${line: -4}"
        

        mask_length=$((${#line} - 4))
        

        masked_part=$(printf '%0.s*' $(seq 1 $mask_length))
        

        masked_number="${masked_part}${last_four}"
        

        echo "$masked_number" >> out/masked.txt
    fi
done < src/parchment.txt