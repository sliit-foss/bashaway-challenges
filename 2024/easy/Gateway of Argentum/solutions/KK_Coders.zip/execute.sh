#!/bin/bash

mkdir -p out

> out/masked.txt

if [[ ! -f src/parchment.txt ]]; then
    echo "Error: parchment.txt file not found in src directory."
    exit 1
fi

while IFS= read -r line || [ -n "$line" ]; do
    if [[ -n "$line" ]]; then
        last4="${line: -4}"
    
        masked=$(echo "${line:0:-4}" | sed 's/[0-9]/*/g')

        masked_line="$masked$last4"
        
        echo "$masked_line" >> out/masked.txt
    fi
done < src/parchment.txt
