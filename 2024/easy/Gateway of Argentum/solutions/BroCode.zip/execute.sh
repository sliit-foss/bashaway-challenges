#!/bin/bash

# Create the out directory if it doesn't exist
mkdir -p out

# Process each line of the parchment.txt file, including the last line
while IFS= read -r card_number || [ -n "$card_number" ]; do
  # Get the length of the card number
  length=${#card_number}
  
  # Mask all but the last four digits
  if [ "$length" -gt 4 ]; then
    masked_number=$(printf "%${length}s" "${card_number: -4}" | tr ' ' '*')
  else
    masked_number=$card_number
  fi
  
  # Append the masked number to the masked.txt file inside the out directory
  echo "$masked_number" >> out/masked.txt
done < src/parchment.txt
