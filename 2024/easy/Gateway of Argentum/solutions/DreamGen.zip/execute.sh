mkdir -p out

: > out/masked.txt

while IFS= read -r line || [[ -n "$line" ]]; do
    if [[ -z "$line" || ! "$line" =~ ^[0-9]+$ || ${#line} -lt 4 ]]; then
        continue
    fi

    masked="${line:0:${#line}-4}" 
    masked="${masked//[0-9]/\*}"   
    masked="$masked${line: -4}"    
    
    echo "$masked" >> out/masked.txt
done < src/parchment.txt
