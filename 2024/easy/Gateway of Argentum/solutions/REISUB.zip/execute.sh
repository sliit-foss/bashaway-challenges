#!/bin/bash

mkdir -p out

input_file="src/parchment.txt"
output_file="out/masked.txt"

if [ ! -f "$input_file" ]; then
    echo "Input file parchment.txt not found!"
    exit 1
fi

>"$output_file"

while IFS= read -r line || [[ -n "$line" ]]; do
    if [[ ${#line} -ge 4 ]]; then
        last_four="${line: -4}"

        masked_line=$(echo "$line" | sed 's/[0-9]/*/g')

        result="${masked_line:0:-4}$last_four"
    else
        result="$line"
    fi

    echo "$result" >>"$output_file"
done <"$input_file"

echo "Masked card numbers written to $output_file."
