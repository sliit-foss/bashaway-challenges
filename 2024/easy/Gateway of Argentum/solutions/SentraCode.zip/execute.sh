#!/bin/bash
mkdir -p ./out

while IFS= read -r line || [[ -n "$line" ]]; do
  modified_line=$(echo "$line" | sed -E 's/^(.{12}).*(.{4})$/************\2/')
  echo "$modified_line"
done < ./src/parchment.txt > ./out/masked.txt