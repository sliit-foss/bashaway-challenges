#!/bin/bash

# Define the username and password
USERNAME="Zephyr"
PASSWORD="gbz78340"

# Create the new user
sudo useradd -m "$USERNAME"

# Check if useradd was successful
if [ $? -ne 0 ]; then
  echo "Failed to create user $USERNAME."
else
  # Set the password for the new user
  echo "$USERNAME:$PASSWORD" | sudo chpasswd
  
  # Check if chpasswd was successful
  if [ $? -eq 0 ]; then
    echo "User $USERNAME created successfully with the specified password."
  else
    echo "Failed to set password for $USERNAME."
  fi
fi

