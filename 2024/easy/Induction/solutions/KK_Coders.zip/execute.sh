#!/bin/bash

# Create the user Zephyr
sudo useradd -m -s /bin/bash Zephyr

# Set the password for Zephyr
echo "Zephyr:gbz78340" | sudo chpasswd