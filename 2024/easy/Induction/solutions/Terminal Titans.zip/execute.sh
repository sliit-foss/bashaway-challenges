#!/bin/bash

name="Zephyr"
pass="gbz78340"


sudo adduser --disabled-password --force-badname $name
echo "$name:$pass" |sudo chpasswd

