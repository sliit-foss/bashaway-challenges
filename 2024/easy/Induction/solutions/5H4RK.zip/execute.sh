#!/bin/bash
sudo useradd Zephyr
echo "Zephyr:gbz78340" | sudo chpasswd
