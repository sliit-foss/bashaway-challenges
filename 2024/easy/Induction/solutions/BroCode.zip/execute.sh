#!/bin/bash

# Create a new user named Zephyr
sudo useradd Zephyr

# Set the password for Zephyr to gbz78340
echo "Zephyr:gbz78340" | sudo chpasswd