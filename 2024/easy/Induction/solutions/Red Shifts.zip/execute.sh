#!/bin/bash

sudo useradd -s /bin/bash Zephyr

echo "Zephyr:gbz78340" | sudo chpasswd