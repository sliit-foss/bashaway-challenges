#!/bin/bash

KEY=$1
FILE="src/courtroom.json"

jq "del(.\"$KEY\")" "$FILE" > tmp.$$.json && mv tmp.$$.json "$FILE"