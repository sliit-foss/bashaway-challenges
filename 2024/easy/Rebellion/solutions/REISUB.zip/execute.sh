#!/bin/bash
jq "del(.\"$1\")" src/courtroom.json > tmp.$$.json && mv tmp.$$.json src/courtroom.json
