if [ "$#" -ne 1 ];then
    exit 0
fi
A='src/courtroom.json'
B="$1"
if [ ! -f "$A" ];then
    exit 1
fi
jq "del(.$B)" "$A" > a.json && mv a.json "$A"