#!/bin/bash
if [[ $# -lt 1 ]]; then
	exit
fi
NAME=$1
OUT=$(jq --arg NAME "$NAME" 'del(.[$NAME])' src/courtroom.json)
echo $OUT > src/courtroom.json
