#!/bin/bash
jq "del(.\"$1\")" src/courtroom.json > temp.json && mv temp.json src/courtroom.json
