#!/bin/bash
res=$(jq "del(.$1)" src/courtroom.json)
echo $res >src/courtroom.json
