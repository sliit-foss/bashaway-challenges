#!/bin/bash
mkdir -p out && f=$(ls src) && gzip -c src/$f > out/${f%.*}.gz