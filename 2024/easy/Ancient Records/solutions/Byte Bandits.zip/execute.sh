mkdir -p out&&gzip<src/*>out/$(basename src/* .|cut -f1 -d.).gz
