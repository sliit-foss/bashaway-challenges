mkdir out
f=$(ls src/)
w=${f%.*}
gzip src/${f}
mv src/${f}.gz out/${w}.gz