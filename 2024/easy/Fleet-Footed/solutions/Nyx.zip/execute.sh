#!/bin/bash
encoded_url="aHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS9zZWFyY2gvaXNzdWVzP3E9cmVwbzpvdmVuLXNoL2J1bitpczppc3N1ZStpczpvcGVuK2xhYmVsOmJ1Zw=="
url=$(echo "$encoded_url" | base64 --decode)
open_bugs=$(curl -s "$url" | jq '.total_count')
echo "$open_bugs"