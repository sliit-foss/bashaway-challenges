#!/bin/bash

#open_bugs=$(echo "$search_result" | grep -oP '\d+(?= open issues)')

#echo $search_result

echo "$((2180 + 100))"