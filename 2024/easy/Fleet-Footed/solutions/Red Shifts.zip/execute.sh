#!/bin/bash

# Example of addition
result=$((2200 + 80))

# Print the result
echo $result