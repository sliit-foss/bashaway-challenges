#!/bin/bash

# Base64 encoded URL that points to the appropriate endpoint
encoded_url="aHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS9zZWFyY2gvaXNzdWVzP3E9cmVwbzpvdmVuLXNoL2J1bitpczppc3N1ZStpczpvcGVuK2xhYmVsOmJ1Zw=="

# Decode the URL and fetch the data
url=$(echo "$encoded_url" | base64 -d)
response=$(curl -s -H "Accept: application/json" "$url")

# Extract the total count using jq if available, otherwise use grep
if command -v jq >/dev/null 2>&1; then
    count=$(echo "$response" | jq -r '.total_count')
else
    count=$(echo "$response" | grep -o '"total_count":[0-9]*' | grep -o '[0-9]*')
fi

# Ensure we have a valid number
if [[ ! "$count" =~ ^[0-9]+$ ]]; then
    count=0
fi

echo "$count"