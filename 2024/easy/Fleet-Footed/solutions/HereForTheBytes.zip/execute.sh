#!/bin/bash

# Base64 encoded GitHub API URL
ENCODED_URL="aHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS9zZWFyY2gvaXNzdWVzP3E9cmVwbzpvdmVuLXNoL2J1bitpczppc3N1ZStpczpvcGVuK2xhYmVsOmJ1Zw=="

# Decode the Base64 URL
API_URL=$(echo "$ENCODED_URL" | base64 --decode)

# Fetch the count of open bugs from the GitHub API
count=$(curl -s "$API_URL" | jq '.total_count')

# Print the number of open bugs
echo "$count"

exit 0
