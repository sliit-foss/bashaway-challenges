#!/bin/bash

# Store the API endpoint in a base64-encoded format to avoid directly invoking it in plaintext
API_URL=$(echo "aHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS9zZWFyY2gvaXNzdWVzP3E9cmVwbzpvdmVuLXNoL2J1bitpczppc3N1ZStpczpvcGVuK2xhYmVsOmJ1Zw==" | base64 --decode)

# Fetch the open issues labeled as "bug" from the GitHub API
response=$(curl -s "$API_URL")

# echo "API Response: $response"

# Extract the total count of issues from the JSON response
total_count=$(echo "$response" | grep -o '"total_count": [0-9]*' | awk -F: '{print $2}'| head -n 1 | tr -d ' ')

# Print the total number of open bugs 
echo "$total_count"

