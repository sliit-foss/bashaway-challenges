#!/bin/bash

# Decode the base64 encoded API URL
API_URL=$(echo "aHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS9zZWFyY2gvaXNzdWVzP3E9cmVwbzpvdmVuLXNoL2J1bitpczppc3N1ZStpczpvcGVuK2xhYmVsOmJ1Zw==" | base64 --decode)

# Use curl to get the data from the API
response=$(curl -s "$API_URL")

# Extract the number of open issues labeled "bug" using jq
open_bugs=$(echo "$response" | jq '.total_count')

# Print only the number of open bugs, without any extra text
echo $open_bugs

