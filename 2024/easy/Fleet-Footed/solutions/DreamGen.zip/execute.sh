#!/bin/bash
str="aHR0cHM6Ly9naXRodWIuY29tL19ncmFwaHFsP2JvZHk9JTdCJTIycXVlcnklMjIlM0ElMjIyOTc0NmZkMjMyNjJkMjNmNTI4ZTFmNWI5YjQyNzQzNyUyMiUyQyUyMnZhcmlhYmxlcyUyMiUzQSU3QiUyMm5hbWUlMjIlM0ElMjJidW4lMjIlMkMlMjJvd25lciUyMiUzQSUyMm92ZW4tc2glMjIlMkMlMjJxdWVyeSUyMiUzQSUyMnN0YXRlJTNBb3BlbiUyMGlzJTNBaXNzdWUlMjBsYWJlbCUzQWJ1ZyUyMHJlcG8lM0FvdmVuLXNoJTJGYnVuJTIwc29ydCUzQWNyZWF0ZWQtZGVzYyUyMiU3RCU3RA=="
url=$(echo $str | base64 -d)
page=$(curl -s "$(echo $str | base64 -d)")

bug_count=$(echo "$page" | grep -o '"openIssueCount":[0-9]*' | cut -d':' -f2)
echo "$bug_count"
