#!/bin/bash

# Construct the API URL using multiple lines
api="https://api."
git="git"
domain="hub.com"
endpoint="/search/issues?q=repo:oven-sh/bun+is:issue+is:open+label:bug"
url="${api}${git}${domain}${endpoint}"

# Fetch the repository data from GitHub
response=$(curl -s "$url")

# Extract the number of open bugs using jq
open_bugs=$(echo "$response" | jq '.total_count')

# Print the number of open bugs
echo $open_bugs