#!/bin/bash

# Store the Base64 string in a variable
base64_string="aHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS9zZWFyY2gvaXNzdWVzP3E9cmVwbzpvdmVuLXNoL2J1bitpczppc3N1ZStpczpvcGVuK2xhYmVsOmJ1Zw=="

# Decode the Base64 string
decoded_string=$(echo "$base64_string" | base64 --decode)

# Fetch the JSON content from the decoded URL
json_content=$(curl -s "$decoded_string")

# Extract the total_count using jq
total_count=$(echo "$json_content" | jq '.total_count')

# Print the total count
if [ -n "$total_count" ]; then
    echo "$total_count"
else
    echo "Unable to fetch the number of open bugs."
fi