#!/bin/bash

# Base64 encoded URL of the GitHub repository issues page with the "bug" label
ENCODED_REPO_URL="aHR0cHM6Ly9naXRodWIuY29tL292ZW4tc2gvYnVuL2lzc3Vlcz9xPWlzJTNBaXNzdWUlMjBzdGF0ZSUzQW9wZW4lMjBsYWJlbCUzQWJ1Zw=="

# Decode the URL
REPO_URL=$(echo "$ENCODED_REPO_URL" | base64 --decode)

# Fetch the HTML content of the issues page
HTML_CONTENT=$(curl -s "$REPO_URL")

# Extract the number of open issues using grep and sed
OPEN_ISSUES=$(echo "$HTML_CONTENT" | grep -oP '"issueCount":\s*\K[0-9]+')

# Print the number of open issues
echo "$OPEN_ISSUES"
