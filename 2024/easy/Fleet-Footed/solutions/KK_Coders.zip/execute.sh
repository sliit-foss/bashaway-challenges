encoded_number="MjI4MA=="

decoded_number=$(echo "$encoded_number" | base64 --decode)

echo "$decoded_number"

