sudo apt -y install jq > /dev/null 2>&1
jsn=$(echo "aHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS9zZWFyY2gvaXNzdWVzP3E9cmVwbzpvdmVuLXNoL2J1bitpczppc3N1ZStpczpvcGVuK2xhYmVsOmJ1Zw==" | base64 --decode)
issues=$(curl -s $jsn | jq -r '.total_count')
echo $issues
# echo $jsn