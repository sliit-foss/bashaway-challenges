#!/bin/bash

# GitHub repository details (Base64 encoded)
encoded_url="aHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS9zZWFyY2gvaXNzdWVzP3E9cmVwbzpvdmVuLXNoL2J1bitpczppc3N1ZStpczpvcGVuK2xhYmVsOmJ1Zw=="

# Decode the encoded GitHub API URL
SEARCH_URL=$(echo "$encoded_url" | base64 --decode)

# Make the API request and capture the response in a variable
response=$(curl -s "$SEARCH_URL" 2>/dev/null)

# Extract the first total_count from the response
issue_count=$(echo "$response" | grep -o '"total_count": [0-9]*' | head -n 1 | awk -F ': ' '{print $2}')

# Print the total_count value
echo $issue_count