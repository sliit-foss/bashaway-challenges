#!/bin/bash

# Define the server URL and credentials
URL="http://localhost:9000/api/auth/login"
USERNAME="bashaway"
PASSWORD="2k24"
API_VERSION="1.0"

# Send the POST request using curl
response=$(curl -s -X POST "$URL" \
  -H "x-api-version: $API_VERSION" \
  -d "username=$USERNAME&password=$PASSWORD")

# Check if the server is running and the request was successful
if [ -n "$response" ]; then
  echo "$response"
else
  echo "Failed to authenticate. Server might not be running or credentials are incorrect."
fi