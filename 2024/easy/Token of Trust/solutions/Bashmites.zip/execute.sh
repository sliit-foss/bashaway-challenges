#!/bin/bash

# Define the server address and port
SERVER="http://localhost:9000/api/auth/login"

# Prepare the credentials and headers
USERNAME="bashaway"
PASSWORD="2k24"
API_VERSION="1.0"

# Check if the server is running on the specified port
if nc -z localhost 9000; then
    # Send the POST request and capture the response
    response=$(curl -s -w "%{http_code}" -X POST "$SERVER" \
        -H "x-api-version: $API_VERSION" \
        -d "username=$USERNAME&password=$PASSWORD")
    
    # Extract HTTP status code from response
    http_code="${response: -3}"  # Last three characters for HTTP code
    response_body="${response:0:${#response}-3}"  # The rest is the response body

    # Check the response code
    if [[ $http_code -eq 200 ]]; then
        echo "$response_body"  # Print the response body, which should contain the token
    else
        echo "Login failed! Server responded with status code: $http_code"
    fi
else
    echo "The server is not running on port 9000."
fi
