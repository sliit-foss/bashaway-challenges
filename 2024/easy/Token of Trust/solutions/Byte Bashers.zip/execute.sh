#!/bin/bash

url="http://localhost:9000/api/auth/login"
username="bashaway"
password="2k24"
header="x-api-version: 1.0"

response=$(curl -s -w "%{http_code}" -o /dev/null -X POST "$url" -H "$header" -d "username=$username&password=$password")

if [ "$response" -eq 200 ]; then
    # Get the JWT token from the response
    token=$(curl -s -X POST "$url" -H "$header" -d "username=$username&password=$password")
    echo "$token"  # Output the JWT token
else
    echo "Failed to authenticate. HTTP Status Code: $response"
fi