#!/bin/bash

# Define the server URL and credentials
SERVER_URL="http://localhost:9000/api/auth/login"
USERNAME="bashaway"
PASSWORD="2k24"
API_VERSION="1.0"

# Send a POST request to the auth server and capture the response body and status code
response=$(curl -s -w "\n%{http_code}" -X POST "$SERVER_URL" \
  -H "x-api-version: $API_VERSION" \
  -d "username=$USERNAME&password=$PASSWORD")

# Extract the body and the status code from the response
response_body=$(echo "$response" | sed '$d')
http_code=$(echo "$response" | tail -n1)

# Display the response body
echo "$response_body"