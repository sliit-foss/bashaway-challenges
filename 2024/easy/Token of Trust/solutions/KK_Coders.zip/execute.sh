#!/bin/bash

# Define the server URL and port
SERVER_URL="localhost"
PORT=9000
API_ENDPOINT="/api/auth/login"

# Define the payload
USERNAME="bashaway"
PASSWORD="2k24"

# Construct the POST request payload
PAYLOAD="username=$USERNAME&password=$PASSWORD"
CONTENT_LENGTH=${#PAYLOAD}

# Create the POST request
REQUEST="POST $API_ENDPOINT HTTP/1.1\r\n"
REQUEST+="Host: $SERVER_URL\r\n"
REQUEST+="x-api-version: 1.0\r\n"
REQUEST+="Content-Type: application/x-www-form-urlencoded\r\n"
REQUEST+="Content-Length: $CONTENT_LENGTH\r\n"
REQUEST+="\r\n"
REQUEST+="$PAYLOAD"

# Check if the server is running on the specified port using /dev/tcp
{
    exec 3<>/dev/tcp/$SERVER_URL/$PORT
} &> /dev/null

if [ $? -ne 0 ]; then
    echo "Server is not running on port $PORT."
fi

# Send the POST request and capture the response
exec 3<>/dev/tcp/$SERVER_URL/$PORT
{
    echo -e "$REQUEST" >&3
    RESPONSE=$(cat <&3)
}
exec 3<&-

echo -e "$RESPONSE" | tail -n 1


# Debugging output to show the entire response
# echo -e "Response received:\n$RESPONSE"

# # Extract the status code from the response
# STATUS_CODE=$(echo "$RESPONSE" | head -n 1 | awk '{print $2}')

# if [ "$STATUS_CODE" -eq 200 ]; then
#     # Extract only the JWT from the response body
#     JWT=$(echo "$RESPONSE" | sed -n '/^$/,$p' | tail -n +2 | tr -d '\r')
#     # Output only the JWT
#     echo "$JWT"
# else
#     # Output error message on failure
#     echo "Login failed with status code: $STATUS_CODE"
# fi