#!/bin/bash

# URL and Port
URL="http://localhost:9000/api/auth/login"

# Credentials
USERNAME="bashaway"
PASSWORD="2k24"

# API version header
API_VERSION="1.0"

# Make the POST request and capture the response
response=$(curl --silent --show-error --fail --connect-timeout 5 \
  --header "x-api-version: $API_VERSION" \
  --data "username=$USERNAME&password=$PASSWORD" \
  $URL)

echo "$response"
