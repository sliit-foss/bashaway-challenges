#!/bin/bash

if ! nc -z localhost 9000; then
  echo "Auth server not running. Exiting."
  exit 0
fi

curl -s -X POST "http://localhost:9000/api/auth/login" \
  -H "x-api-version: 1.0" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  --data-urlencode "username=bashaway" \
  --data-urlencode "password=2k24"