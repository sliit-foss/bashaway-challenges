#!/bin/bash

# Define the server address and endpoint
SERVER="http://localhost:9000/api/auth/login"

# Define the credentials and headers
USERNAME="bashaway"
PASSWORD="2k24"
API_VERSION="1.0"

# Function to perform the POST request
function login() {
    # Send the POST request using curl and capture the response
    response=$(curl -s -H "x-api-version: $API_VERSION" \
        -d "username=$USERNAME&password=$PASSWORD" \
        -X POST "$SERVER")

    # Output the response
    echo "$response"
}

# Check if the server is running on the specified port
if nc -z localhost 9000; then
    # Get the response from the login function
    result=$(login)
    
    # Check if the result is empty or not
    if [ -z "$result" ]; then
        echo "No response from the server."
    else
        # Output the JWT or any response from the server
        echo "$result"
    fi
else
    echo "No server running on port 9000. Please start the server and try again."
fi