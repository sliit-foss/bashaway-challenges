#!/bin/bash

# Server and endpoint details
SERVER_URL="http://localhost:9000/api/auth/login"

# Request details
USERNAME="bashaway"
PASSWORD="2k24"
API_VERSION="1.0"

# Check if the server is up on port 9000 before making the request
if nc -z localhost 9000; then
  # Make the POST request using curl
  response=$(curl -s -X POST "$SERVER_URL" \
    -H "x-api-version: $API_VERSION" \
    -d "username=$USERNAME&password=$PASSWORD")
  
  # Output the response
  echo "$response"
else
  echo "Server on port 9000 is not running."
fi