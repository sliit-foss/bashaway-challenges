#!/bin/bash

# Define the server and endpoint details
SERVER="http://localhost:9000"
ENDPOINT="/api/auth/login"
URL="$SERVER$ENDPOINT"

# Set credentials and headers
USERNAME="bashaway"
PASSWORD="2k24"
API_VERSION="1.0"

# Send POST request using curl and capture the response
RESPONSE=$(curl -s -X POST "$URL" \
  -H "x-api-version: $API_VERSION" \
  -d "username=$USERNAME&password=$PASSWORD")

# Output the response (the JWT token)
echo "$RESPONSE"
exit 0