#!/bin/bash

SERVER_URL="http://localhost:9000/api/auth/login"
USERNAME="bashaway"
PASSWORD="2k24"
API_VERSION="1.0"

response=$(curl -s -X POST "$SERVER_URL" \
  -H "x-api-version: $API_VERSION" \
  -d "username=$USERNAME&password=$PASSWORD")

if [[ "$response" == *"eyJ"* ]]; then
  echo "$response"
else
  echo "Failed to authenticate or server is unreachable."
fi
