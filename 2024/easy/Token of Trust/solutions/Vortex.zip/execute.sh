#!/bin/bash

# Server details
SERVER_ADDRESS="localhost"
SERVER_PORT="9000"
API_ENDPOINT="/api/auth/login"

# Credentials
USERNAME="bashaway"
PASSWORD="2k24"

# API version header
API_VERSION_HEADER="X-API-VERSION: 1.0"

# Payload (form data)
PAYLOAD="username=${USERNAME}&password=${PASSWORD}"

# Send POST request with curl (handle potential errors)
curl -sSL -X POST -H "${API_VERSION_HEADER}" \
  -d "${PAYLOAD}" "http://${SERVER_ADDRESS}:${SERVER_PORT}${API_ENDPOINT}" || true

