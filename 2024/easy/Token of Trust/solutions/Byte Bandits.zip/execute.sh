#!/bin/bash

# URL of the auth server
URL="http://localhost:9000/api/auth/login"

# Credentials
USERNAME="bashaway"
PASSWORD="2k24"

# Make the POST request
response=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "x-api-version: 1.0" \
  -d "username=$USERNAME&password=$PASSWORD" \
  "$URL")

# Check if the request was successful (HTTP 200)
if [ "$response" -eq 200 ]; then
  # If successful, make another request to get the token
  token=$(curl -s -X POST \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -H "x-api-version: 1.0" \
    -d "username=$USERNAME&password=$PASSWORD" \
    "$URL")
  
  # Print the token
  echo "$token"
else
  # If unsuccessful, exit silently
  exit 0
fi
