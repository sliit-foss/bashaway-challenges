#!/bin/bash
[ -z "$2" ] && echo "$1" || echo "$1" | fold -w "$2"

