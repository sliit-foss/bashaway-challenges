#!/bin/bash

if [ $# -eq 0 ]; then
    exit 0
fi

echo "$1" | fold -w $2