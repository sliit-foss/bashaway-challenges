if [ $# -eq 0 ]; then
  exit
fi
s="${@:1:$#-1}";echo $s | fold -w ${@: -1}