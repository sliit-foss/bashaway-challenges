#!/bin/bash
[ "$1" ] && fold -w "$2" <<< "$1" || echo
