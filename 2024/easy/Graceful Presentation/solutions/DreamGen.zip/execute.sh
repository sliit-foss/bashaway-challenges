#!/bin/bash
[ $# -eq 0 ] && exit 0
echo "$1" | fold -w $2
