#!/bin/bash
[ -z "$1" ] || [ -z "$2" ] && exit 0
fold -w "$2" <<< "$1"