echo $((8*$(stat -c%s src/phantom.o)))
