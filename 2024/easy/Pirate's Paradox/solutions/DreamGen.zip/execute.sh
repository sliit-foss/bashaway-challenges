
echo $(( $(wc -c < src/*) * 8 ))
