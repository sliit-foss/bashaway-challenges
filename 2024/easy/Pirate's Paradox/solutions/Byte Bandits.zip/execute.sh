wc -c <src/*|awk '{print $1*8}'
