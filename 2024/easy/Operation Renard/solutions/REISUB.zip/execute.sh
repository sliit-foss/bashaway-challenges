#!/bin/bash

mkdir -p out
> out/decoded.txt

while IFS= read -r line || [[ -n "$line" ]]; do
    echo "$line" | base64 --decode >> out/decoded.txt
    echo "" >> out/decoded.txt
done < src/codes.txt
