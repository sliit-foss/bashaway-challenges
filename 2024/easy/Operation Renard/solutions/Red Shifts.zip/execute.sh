#!/bin/bash

mkdir -p out

filename=src/codes.txt
echo "" >> $filename
while read -r line; do
    echo "$line" | base64 --decode >> out/decoded.txt
    echo "" >> out/decoded.txt
done < "$filename"