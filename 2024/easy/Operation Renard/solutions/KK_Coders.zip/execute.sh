#!/bin/bash

[ ! -d "./out" ] && mkdir ./out

while IFS= read -r line || [[ -n "$line" ]]; do
  echo "$line" | base64 --decode
  echo 
done < "./src/codes.txt" > "./out/decoded.txt"