#!/bin/bash

# Create the output directory if it doesn't exist
mkdir -p out

# Clear previous contents of decoded.txt
> out/decoded.txt

# Read each line from src/codes.txt
while IFS= read -r line || [[ -n $line ]]; do
    # Decode the base64-encoded string and save to out/decoded.txt
    decoded=$(echo "$line" | base64 --decode)
    echo "$decoded" >> out/decoded.txt
done < src/codes.txt

# Notify completion of the operation
echo "Operation Renard complete. Decoded messages saved to out/decoded.txt."
