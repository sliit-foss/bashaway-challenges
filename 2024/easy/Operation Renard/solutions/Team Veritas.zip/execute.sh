#!/bin/bash

# Create the output directory if it doesn't exist
mkdir -p out

# Initialize the output file
> out/decoded.txt

# Read each line from the input file, decode it, and append to the output file
while IFS= read -r line; do
    echo -n "$line" | base64 --decode >> out/decoded.txt
    echo >> out/decoded.txt  # Add a newline after each decoded line
done < src/codes.txt

# Process the last line if it doesn't end with a newline
if [ -n "$line" ]; then
    echo -n "$line" | base64 --decode >> out/decoded.txt
    echo >> out/decoded.txt  # Add a newline after the last decoded line
fi