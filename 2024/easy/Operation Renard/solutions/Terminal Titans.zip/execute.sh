#!/bin/bash

mkdir -p out

while IFS="" read -r code || [ -n "$code" ]; do
	out=$(echo "$code" | base64 --decode)
	str="${str}${out}\n"
	

done < src/codes.txt

printf "$str" > out/decoded.txt

