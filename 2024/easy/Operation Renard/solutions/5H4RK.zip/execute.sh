#!/bin/bash

mkdir -p ./out
output_file="./out/decoded.txt"
> "$output_file"


while IFS= read -r line || [ -n "$line" ]; do
    decoded_line=$(echo "$line" | base64 --decode)
    if [ -n "$line" ]; then
        echo "$decoded_line" >> "$output_file"
    else
        echo -n "$decoded_line" >> "$output_file"
    fi
done < ./src/codes.txt
truncate -s -1 "$output_file"