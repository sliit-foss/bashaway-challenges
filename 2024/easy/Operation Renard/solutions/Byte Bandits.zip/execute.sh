#!/bin/bash

# Operation Renard: Decoding Script
# This script decodes base64-encoded messages from codes.txt and saves the plaintext to decoded.txt

# Ensure the out directory exists
mkdir -p out

# Clear the output file if it exists
> out/decoded.txt

# Read each line from codes.txt, decode it, and append to decoded.txt
while IFS= read -r line || [ -n "$line" ]; do
    # Split the line into an array of encoded strings
    IFS=' ' read -ra encoded_strings <<< "$line"
    
    # Decode each string in the line
    for encoded_string in "${encoded_strings[@]}"; do
        decoded_string=$(echo -n "$encoded_string" | base64 -d)
        echo "$decoded_string" >> out/decoded.txt
    done
done < src/codes.txt

# Ensure proper permissions for the output file
chmod 600 out/decoded.txt

echo "Operation Renard: Decoding complete. Plaintext saved to out/decoded.txt"
