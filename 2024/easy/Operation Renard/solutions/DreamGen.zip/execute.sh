#!/bin/bash

mkdir -p out

> out/decoded.txt

while IFS= read -r line || [[ -n "$line" ]]; do
    for encoded_str in $line; do
        echo -n "$encoded_str" | base64 --decode >> out/decoded.txt
    done
    echo "" >> out/decoded.txt
done < src/codes.txt
