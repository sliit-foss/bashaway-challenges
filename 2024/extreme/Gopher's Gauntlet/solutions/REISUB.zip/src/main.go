package main

import (
  "elemental/cmd"
)

func main() {
  e_cmd.Execute()
}