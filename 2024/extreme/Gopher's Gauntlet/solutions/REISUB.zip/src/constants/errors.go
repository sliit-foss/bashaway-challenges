package e_constants

const (
	ErrURIRequired           = "URI is required"
	ErrMustPairSortArguments = "Sort arguments must be in pairs"
)
