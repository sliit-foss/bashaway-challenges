package e_constants

const CTXUser = "user"