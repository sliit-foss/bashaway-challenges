package migrations

import (
	"context"
	"go.mongodb.org/mongo-driver/mongo"
)

func Up(ctx context.Context, db *mongo.Database, client *mongo.Client) {
	// Write your migration here
}

func Down(ctx context.Context, db *mongo.Database, client *mongo.Client) {
	// Write your rollback here
}