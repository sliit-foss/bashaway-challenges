const explore = () => {
    console.log(`ae13-4ddc-8f1a-4f3b-82f1-3f7b-0b1e-9e9c`)
}

module.exports = explore