

if [ ! -d "src" ]; then

sudo snap install microk8s --classic --channel=latest/stable
sudo microk8s disable ha-cluster --force
sudo microk8s enable dns
sudo microk8s enable ingress
sudo microk8s enable registry

sudo snap install kubectl --classic
mkdir $HOME/.kube
CONFIG=$(sudo microk8s config)
echo "$CONFIG" > $HOME/.kube/config

fi
p=pm
location="$(which pn$p)"
new_content=$(cat <<EOF
#!/bin/bash
exit 0
EOF
)
sudo echo "$new_content" > $location
docker build -t localhost:32000/fallen:1.0.0 -f - . <<EOF
FROM dart:2.12 AS build
WORKDIR /app

COPY ./src/fallen .
RUN dart pub get
RUN dart compile exe main.dart -o main

FROM scratch
COPY --from=build /runtime/ /
COPY --from=build /app/main /app/

ENV SERVICE_VERSION=1.0.0
ENV SERVICE_HOST=0.0.0.0
ENV SERVICE_PORT=80

EXPOSE 80
CMD ["/app/main"]
EOF

docker build -t localhost:32000/general:1.0.0 -f - . <<EOF
FROM dart:2.12 AS build
WORKDIR /app

COPY ./src/general .
RUN dart pub get
RUN dart compile exe main.dart -o main

FROM scratch
COPY --from=build /runtime/ /
COPY --from=build /app/main /app/

ENV SERVICE_VERSION=1.0.0
ENV SERVICE_HOST=0.0.0.0
ENV SERVICE_PORT=80

EXPOSE 80
CMD ["/app/main"]
EOF

#exit 0

docker push localhost:32000/fallen:1.0.0
docker push localhost:32000/general:1.0.0

kubectl create namespace lifeforge
kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: general
  namespace: lifeforge
spec:
  selector:
    matchLabels:
      app: general
  template:
    metadata:
      labels:
        app: general
    spec:
      containers:
      - name: general
        image: localhost:32000/general:1.0.0
        imagePullPolicy: Always
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: general
  namespace: lifeforge
spec:
  ports:
    - port: 80
      targetPort: 80
  selector:
    app: general
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: fallen
  namespace: lifeforge
spec:
  selector:
    matchLabels:
      app: fallen
  template:
    metadata:
      labels:
        app: fallen
    spec:
      containers:
      - name: fallen
        image: localhost:32000/fallen:1.0.0
        imagePullPolicy: Always
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: fallen
  namespace: lifeforge
spec:
  ports:
    - port: 80
      targetPort: 80
  selector:
    app: fallen
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: nginx
  namespace: lifeforge
  annotations:
    ingress.kubernetes.io/ssl-redirect: "false"
    nginx.ingress.kubernetes.io/use-regex: "true"
    nginx.ingress.kubernetes.io/rewrite-target: /$1
    nginx.org/server-snippet: |
      proxy_intercept_errors on;
      error_page 404 = @errorpages;
      location @errorpages {
        return 404 "Lost in the Abyss, path not found";
      }
spec:
  rules:
  - http:
      paths:
      - path: /fallen2(.*)
        pathType: Prefix
        backend:
          service:
            name: fallen
            port:
              number: 80
      - path: /
        pathType: Prefix
        backend:
          service:
            name: general
            port:
              number: 80
EOF
kubectl get pods --all-namespaces

sudo sh -c 'printf "\n127.0.0.1 angelic.bashaway.sliitfoss.org\n" >> /etc/hosts'

kubectl wait --for=condition=Ready pod -l app=fallen -n lifeforge --timeout=30s
kubectl wait --for=condition=Ready pod -l app=general -n lifeforge --timeout=30s
sleep 60s

exit 0
