rm -rf src

git clone https://github.com/sliit-foss/bashaway-ui.git src

# Write your code here