
rm -rf src

git clone https://github.com/sliit-foss/bashaway-ui.git src

cd src

# Use git filter-branch to rewrite commit history
git filter-branch -f --commit-filter '
if [ "$GIT_AUTHOR_NAME" = "github-actions[bot]" ]; then
    GIT_AUTHOR_NAME="github-actions";
    GIT_COMMITTER_NAME="github-actions";
    git commit-tree "$@";
else
    git commit-tree "$@";
fi' HEAD

# Confirm that the changes have been made
git log --pretty=format:"%an %ae" | grep "github-actions"
