module.exports = {
    modulePathIgnorePatterns: [
        '.*/out/'
    ],
    maxWorkers: 1
};
