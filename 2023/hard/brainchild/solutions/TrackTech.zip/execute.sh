#!/bin/bash

file_content="#!/bin/bash

# get page https://github.com/\$1
curl -s \"https://api.github.com/users/\$1/repos?per_page=100\" > temp.txt

# get all lines that say full_name
grep full_name temp.txt > temp2.txt

mkdir -p \$2

# for each line, get the repo name
while read line; do
    # get the repo name
    repo_name=\$(echo \$line | cut -d '\"' -f 4)
    # clone repo into \$2
    git -C \$2 clone \"https://github.com/\$repo_name\"
done < temp2.txt

rm temp.txt
rm temp2.txt
"


echo "$file_content" > "git-clone-gh-org"
chmod +x "./git-clone-gh-org"

# mkdir -p "~/.local/bin"
# mkdir -p "~/bin"

# cp "git-clone-gh-org" "~/.local/bin/git-clone-gh-org"
# cp "git-clone-gh-org" "~/bin/git-clone-gh-org"
sudo cp "git-clone-gh-org" "/usr/local/bin/git-clone-gh-org"

rm "git-clone-gh-org"
# add .local/bin, ~/bin and /usr/local/bin to PATH
export PATH=$PATH:/usr/local/bin
