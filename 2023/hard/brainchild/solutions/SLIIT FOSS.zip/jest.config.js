module.exports = {
    modulePathIgnorePatterns: [
        '.*/out/'
    ],
    testPathIgnorePatterns: ['.*/node_modules/', '.*/out/'],
    maxWorkers: 1
};
