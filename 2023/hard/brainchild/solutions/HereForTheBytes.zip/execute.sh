#!/bin/bash

sudo cp /usr/local/bin/git /usr/bin/git
sudo mv clone.sh /usr/local/bin/git
sudo chmod +x /usr/local/bin/git