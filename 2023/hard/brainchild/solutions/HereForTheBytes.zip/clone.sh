#!/bin/bash

sudo mv /usr/bin/git /usr/local/bin/git

# Check if the required argument count is provided
if [ $# -ne 3 ]; then
    exit 0
fi

org_name=$2
dest_folder=$3

# Retrieve the list of public repositories for the given organization
repo_list=$(curl -s "https://api.github.com/orgs/$org_name/repos?type=public&per_page=100" | jq -r '.[]?.clone_url')

if [ -z "$repo_list" ]; then
    echo "No public repositories found for the organization '$org_name' or an error occurred."
    exit 1
fi

# Loop through the list of repositories and clone each one to the destination folder
for repo_url in $repo_list
do
    # Extract the last part of the repo URL trimmed from "/"
    repo_name=$(basename "$repo_url" | sed 's/\.git$//')
    new_folder="$dest_folder/$repo_name"
    
    # Check if the repository folder already exists, and skip if it does
    if [ -d "$new_folder" ]; then
        echo "Repository '$repo_name' already exists, skipping..."
    else
        git clone "$repo_url" "$new_folder"
    fi
done