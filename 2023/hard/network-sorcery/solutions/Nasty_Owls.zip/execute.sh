pnpm i -g pm2
#pnpm install --save-dev jest
#pnpm install mysql2 axios @sliit-foss/bashaway

pm2 delete network-sorcery

pm2 start src/server.js --name network-sorcery -f
server() {
   while true; do
       echo "HTTP/1.1 301 Moved Permanently\r\nLocation: http://localhost:3000\r\n\r\n" | nc -l -s 0.0.0.0 -p 8000
   done
}


server &

search_string="https://api.jokes.bashaway.sliitfoss.org"
replace_string="http://localhost:3000"
directory_path="./"
find "$directory_path" -type f -exec sed -i "s|$search_string|$replace_string|g" {} \;

