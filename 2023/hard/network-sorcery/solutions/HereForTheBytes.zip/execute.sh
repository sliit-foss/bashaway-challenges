pnpm i -g pm2

pm2 delete network-sorcery

pm2 start src/server.js --name network-sorcery -f

# Write your code here

# touch /etc/nginx/sites-available/default
sudo rm /etc/nginx/sites-available/default

sudo mv ./default /etc/nginx/sites-available/default

echo "127.0.0.1 api.jokes.bashaway.sliitfoss.org" | sudo tee -a /etc/hosts

sudo mkdir -p /etc/nginx/ssl/
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048  -subj "/C=US/ST=Denial/L=Springfield/O=Dis/CN=api.jokes.bashaway.sliitfoss.org.key"  -keyout /etc/nginx/ssl/api.jokes.bashaway.sliitfoss.org.key -out /etc/nginx/ssl/api.jokes.bashaway.sliitfoss.org.crt
sudo chown root:root /etc/nginx/ssl/api.jokes.bashaway.sliitfoss.org.crt
sudo chmod 600 /etc/nginx/ssl/api.jokes.bashaway.sliitfoss.org.crt

sudo chown root:root /etc/nginx/ssl/api.jokes.bashaway.sliitfoss.org.key
sudo chmod 600 /etc/nginx/ssl/api.jokes.bashaway.sliitfoss.org.key

sudo nginx
