#!/bin/bash

pnpm i -g pm2

pm2 delete network-sorcery

pm2 start src/server.js --name network-sorcery -f

# Define the source URL and port
SOURCE_URL="api.jokes.bashaway.sliitfoss.org"
DESTINATION_PORT="3000"

# Check if Nginx is installed
if ! command -v nginx &>/dev/null; then
    echo "Nginx is not installed. Please install Nginx and run the script again."
    exit 1
fi

# Add an entry to the /etc/hosts file
echo "127.0.0.1    $SOURCE_URL" | sudo tee -a /etc/hosts > /dev/null

# Create a self-signed SSL certificate (for testing purposes)
sudo mkdir -p /etc/nginx/ssl
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /etc/nginx/ssl/self-signed.key -out /etc/nginx/ssl/self-signed.crt -subj "/CN=$SOURCE_URL"

# Create an Nginx configuration file for redirection with SSL
# cat > /etc/nginx/sites-available/redirect.conf <<EOF
# server {
#     listen 443 ssl;
#     server_name $SOURCE_URL;

#     ssl_certificate /etc/nginx/ssl/self-signed.crt;
#     ssl_certificate_key /etc/nginx/ssl/self-signed.key;

#     location / {
#         proxy_pass http://localhost:$DESTINATION_PORT;
#         proxy_set_header Host \$host;
#         proxy_set_header X-Real-IP \$remote_addr;
#         proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
#     }
# }

# server {
#     listen 80;
#     server_name $SOURCE_URL;
#     return 301 https://\$host\$request_uri;
# }
# EOF

echo "server {
    listen 443 ssl;
    server_name 127.0.0.1;

    ssl_certificate /etc/nginx/ssl/self-signed.crt;
    ssl_certificate_key /etc/nginx/ssl/self-signed.key;

    location / {
        proxy_pass http://localhost:$DESTINATION_PORT;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    }
}

server {
    listen 80;
    server_name 127.0.0.1;
    return 301 https://\$host\$request_uri;
}" | sudo tee -a /etc/nginx/sites-available/redirect.conf > /dev/null

# Create a symbolic link to enable the configuration
sudo ln -s /etc/nginx/sites-available/redirect.conf /etc/nginx/sites-enabled/

# Start nginx
sudo systemctl start nginx

