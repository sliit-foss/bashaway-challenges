# Start Install Google Chrome (You may comment out these lines during local testing if you already have Chrome installed)

sudo apt update

wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo dpkg -i google-chrome-stable_current_amd64.deb

sudo apt-get install -f

rm google-chrome-stable_current_amd64.deb

# End Install Google Chrome

# Write your code here

# make src permissions to be accessible by all
sudo chmod -R 777 src

# Step 1: Create Dockerfile
cat <<EOL > Dockerfile
FROM php:8.0.30-fpm-alpine3.16

# Install system dependencies and PHP extensions
RUN apk --no-cache add libpng-dev libjpeg-turbo-dev libzip-dev && \
    docker-php-ext-configure gd && \
    docker-php-ext-install gd pdo pdo_mysql zip

# Install Composer
# RUN curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
COPY --from=composer:latest /usr/bin/composer /usr/local/bin/composer

# Set the working directory
WORKDIR /var/www

# Copy over the Laravel project
COPY src /var/www

RUN chown -R www-data:www-data /var/www && \
    chmod -R 777 /var/www

# Expose port 9000 to interact with the outside world
EXPOSE 9000
EOL
# # Install Laravel dependencies
# RUN composer install


# # Start PHP's FastCGI Process Manager
# CMD ["php-fpm"]

# Step 2: Create docker-compose.yml
cat <<EOL > docker-compose.yml
version: '3'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: bashaway-2k23-perfect-dish-laravel
    volumes:
      - ./src:/var/www

  webserver:
    image: nginx:latest
    container_name: bashaway-2k23-perfect-dish
    volumes:
      - ./src:/var/www
      - ./nginx/default.conf:/etc/nginx/conf.d/default.conf
    ports:
      - "8001:80"
EOL

# Step 3: Setup Nginx configuration
mkdir -p nginx
cat <<EOL > nginx/default.conf
server {
    listen 80;
    index index.php index.html;
    server_name localhost;
    error_log  /var/log/nginx/error.log;
    access_log /var/log/nginx/access.log;
    root /var/www/public;

    location ~ \.php$ {
        try_files \$uri =404;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass app:9000;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param PATH_INFO \$fastcgi_path_info;
    }
}
EOL


# Step 4: Docker Compose Up
docker compose up -d
sleep 5
# Step 3.5 composor install
docker exec bashaway-2k23-perfect-dish-laravel composer install

# start php-fpm
docker exec bashaway-2k23-perfect-dish-laravel php-fpm

rm -rf Dockerfile docker-compose.yml nginx