cat src/input.txt | tr '\n' ','
