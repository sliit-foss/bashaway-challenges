#!/bin/bash
paste -sd, src/input.txt
