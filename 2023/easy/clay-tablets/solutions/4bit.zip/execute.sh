sed -z 's/\n/,/g' src/input.txt
