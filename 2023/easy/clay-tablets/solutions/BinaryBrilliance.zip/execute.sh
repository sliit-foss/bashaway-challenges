tr '\n\r' ',\b' < src/input.txt
