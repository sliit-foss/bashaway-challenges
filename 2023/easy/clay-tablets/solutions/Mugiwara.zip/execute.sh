#!/bin/bash
tr '\n' ',' < src/input.txt