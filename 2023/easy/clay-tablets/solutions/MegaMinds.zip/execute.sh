paste -sd ',' src/input.txt
