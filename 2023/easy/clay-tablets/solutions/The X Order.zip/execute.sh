tr '\n' ',' < src/input.txt
