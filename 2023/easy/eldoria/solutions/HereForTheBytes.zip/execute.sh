# A random count of csv files will be generated within the src directory once the tests are run.

# Write your code here

#!/bin/bash

# Define input and output paths
src_folder="src"
out_folder="out"
output_file="merged-scrolls.csv"
currency_header="Item, Value(SilverSovereigns)"
conversion_factor=178

# Check if src folder exists and is not empty
if [ -d "$src_folder" ] && [ "$(ls -A $src_folder)" ]; then
    # Create the output folder if it doesn't exist
    mkdir -p "$out_folder"

    # Merge CSV files, convert values, round off, and save to temporary file
    awk -F, -v header="$currency_header" -v factor="$conversion_factor" 'BEGIN{OFS=","; print header} FNR>1 && $1 != "" {printf "%s,%.2f\n", $1, $2*factor}' $src_folder/*.csv > "$out_folder/$output_file.tmp"

    # Sort the temporary file in descending order
    sort -t',' -k2,2nr "$out_folder/$output_file.tmp" > "$out_folder/$output_file"

    # Sort the temporary file in descending order, excluding the first line (header)
    tail -n +2 "$out_folder/$output_file.tmp" | sort -t',' -k2,2nr > "$out_folder/$output_file"

    # Append the header to the sorted file
    { echo "$currency_header"; cat "$out_folder/$output_file"; } > "$out_folder/$output_file.tmp"

    # Move the temporary file to the final output file
    mv "$out_folder/$output_file.tmp" "$out_folder/$output_file"
fi
