#!/bin/bash

mkdir -p out

if [ -d "src" ]; then

  echo "Item,Value(Silver Sovereigns)" > out/merged-scrolls.csv


  find src -type f -name "*.csv" -exec cat {} \; |
    awk -F, -v OFS=',' 'NR > 1 {value = $2 * 178; printf("%s,%.2f\n", $1, value)}' |
    sort -t',' -k2,2nr >> out/merged-scrolls.csv
else

  echo "src directory does not exist or is empty."
fi

