#!/bin/bash

mkdir -p out
output_file="out/merged-scrolls.csv"

if [ ! -e "$output_file" ]; then
    echo "Item,Value(Silver Sovereigns)" > "$output_file"
fi

if [ -d "src" ] && [ "$(ls -A src)" ]; then
    awk '(NR == 1) || (FNR > 1)' src/*.csv > tmp && mv tmp "$output_file"

    awk -F',' 'BEGIN{OFS=","} {if(NR==1){$2="Silver Sovereigns"}else{$2=sprintf("%.2f", $2*178)}}1' "$output_file" > tmp && mv tmp "$output_file"
    sort -t',' -k2,2rn "$output_file" > tmp && mv tmp "$output_file"

    sed -i '$d' "$output_file" && sed -i '1iItem,Value(Silver Sovereigns)' "$output_file"
fi
