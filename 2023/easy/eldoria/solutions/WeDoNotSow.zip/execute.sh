#!/bin/bash

# Ensure src and out directories exist
mkdir -p src 
mkdir -p out

# Define the header for the merged CSV file
echo "Item,Silver Sovereigns" > out/merged-scrolls.csv

# Conversion rate from gold to silver
GOLD_TO_SILVER=178

# Loop through all CSV files in the src directory
for file in src/*.csv; do
    # Check if the file exists and is not empty
    if [ -e "$file" ] && [ -s "$file" ]; then
        # Extract, convert, and append to the merged file
        awk -F, -v OFS=, -v CONVERSION="$GOLD_TO_SILVER" 'NR > 1 {printf $1 ","; printf "%.2f\n", $2 * CONVERSION}' "$file" >> out/merged-scrolls.csv
    fi
done

# Sort the merged file by Silver Sovereigns in descending order
sort -t, -k2,2nr -o out/merged-scrolls.csv out/merged-scrolls.csv

# Add the header to the beginning of the merged file
sed -i '1s/^/Item,Value(Silver Sovereigns)/' out/merged-scrolls.csv

# Remove the extra line at the end of the file
sed -i '$d' out/merged-scrolls.csv