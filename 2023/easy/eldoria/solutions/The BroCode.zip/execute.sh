# A random count of csv files will be generated within the src directory once the tests are run.

# Write your code here
#!/bin/bash

# Check if the src folder exists
if [ ! -d "src" ]; then
    mkdir "src"
fi

# Check if the out folder exists or create it
if [ ! -d "out" ]; then
    mkdir "out"
fi

echo "Item,Value(Silver Sovereigns)" > out/merged-scrolls.csv

cat src/*.csv | awk -F',' 'NR>1 {printf "%s,%.2f\n", $1, $2*178}' | sort -t',' -k2,2nr >> out/merged-scrolls.csv