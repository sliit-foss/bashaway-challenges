#!/bin/bash

root_dir="$(dirname "$0")"
src_dir="${root_dir}/src"
out_dir="${root_dir}/out"
merged_file="${out_dir}/merged-scrolls.csv"

if [ -d "${src_dir}" ] && [ "$(ls -A "${src_dir}")" ]; then
    mkdir -p "${out_dir}"

    header="Item,Value(Silver Sovereigns)"

    {
        echo "${header}" 
        awk -F',' -v OFS=',' 'NR>1 && $2 != 0 {printf "%s,%.2f\n", $1, $2 * 178}' "${src_dir}"/*.csv | sort -t',' -k2,2nr
    } | grep -v "Item,0.00" > "${merged_file}_temp"

    mv "${merged_file}_temp" "${merged_file}"

    echo "Merged CSV file with values converted to Silver Sovereigns and sorted in descending order saved as ${merged_file}"
else
    echo "Warning: The src directory is empty or does not exist. No CSV files were merged."
fi
