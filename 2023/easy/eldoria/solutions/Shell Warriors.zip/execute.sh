#!/bin/bash

# Create the out directory if it doesn't exist
mkdir -p out

# Check if src directory exists and is not empty
if [ -d "src" ] && [ "$(ls -A src)" ]; then
    awk -F',' -v OFS=',' '$2 != 0 {print $1, sprintf("%.2f", $2*178)}' src/*.csv | grep -v ',0.00$' > out/merged-scrolls.csv
    sort -t, -k2,2 -n -r -o out/merged-scrolls.csv out/merged-scrolls.csv
    sed -i '1iItem,Value (Silver Sovereigns)' out/merged-scrolls.csv
else
    echo "src directory is empty or does not exist."
fi
