#!/bin/bash

# Check if a.txt exists in the src directory
if [ -f src/relic.txt ]; then
  # Set the file permissions to read-only for the owner
  chmod 400 src/relic.txt

else
  exit 1
fi
