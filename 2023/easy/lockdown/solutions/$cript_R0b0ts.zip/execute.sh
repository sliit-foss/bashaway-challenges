#!/bin/bash

text_file_path="src/relic.txt"

# Ensure the file exists
if [ -f "$text_file_path" ]; then
    # Set the file to read-only
    chmod a-w "$text_file_path"
    echo "The text file within 'src' has been set to read-only."
else
    echo "The specified text file within 'src' does not exist."
fi

