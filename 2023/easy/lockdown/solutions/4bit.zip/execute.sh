#!/bin/bash

# Check if the text file exists
if [ -f src/relic.txt ]; then
  # Change the file permissions to read-only
  chmod 444 src/relic.txt
fi
