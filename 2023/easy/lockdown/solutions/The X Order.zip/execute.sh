#!/bin/bash

# Check if the src directory exists
if [ ! -d "src" ]; then
  exit 1
fi

sacred_text="src/relic.txt"

if [ ! -e "$sacred_text" ]; then
  exit 1
fi

chmod 400 "$sacred_text"
