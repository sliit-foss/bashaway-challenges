#!/bin/bash
chmod a=r "./src/relic.txt"