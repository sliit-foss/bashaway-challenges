#!/bin/bash

# Change directory to src
cd src

# Change file permissions to read-only
chmod 444 relic.txt
