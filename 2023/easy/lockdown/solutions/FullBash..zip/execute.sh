#!/bin/bash
if [ -e "src/relic.txt" ]; then
    # Set read-only permissions for the file
    chmod a-w "src/your_file.txt"
    echo "File is now read-only."
else
    echo "File not found in src directory."
fi
