chmod 0444 ./src/*
