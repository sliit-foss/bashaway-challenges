#!/bin/bash
chmod 444 "src/relic.txt"

