file_path="src/relic.txt"

# Check if the file exists
if [ -e "$file_path" ]; then
    # Make the file read-only
    chmod -w "$file_path"
    echo "File $file_path is now read-only."
else
    echo "File $file_path does not exist."
fi