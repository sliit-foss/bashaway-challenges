src_directory="src"

text_file="$src_directory/relic.txt"

chmod 444 "$text_file"