#!/bin/bash

# get name of .txt file
file=$(find src -type f -name "*.txt" -print -quit)

filename=$(basename "$file")

echo "$filename"

chmod -wx+r 'src/'$filename