mkdir -p src
echo  > src/secret.txt
chmod 400 src/secret.txt

