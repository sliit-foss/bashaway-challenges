#!/bin/bash

# Define the path to the text file
file_path="src/relic.txt"

# Check if the file exists
if [ -e "$file_path" ]; then
    # Set the file permissions to read-only
    chmod 444 "$file_path"
    echo "The text file is now read-only."
else
    echo "The text file does not exist."
fi