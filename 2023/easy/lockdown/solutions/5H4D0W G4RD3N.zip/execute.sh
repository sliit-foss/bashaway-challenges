#!/usr/bin/env bash
#Waga na wa 5H4D0W

set -e
set -u
set -o pipefail

chmod 444 src/**
