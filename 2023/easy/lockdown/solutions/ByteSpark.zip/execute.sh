#!/bin/bash

# Create an empty text file in the src directory
cat src/relic.txt

# Set the file permissions to read-only
chmod 444 src/relic.txt

echo "The forbidden knowledge has been locked in src/forbidden.txt."
