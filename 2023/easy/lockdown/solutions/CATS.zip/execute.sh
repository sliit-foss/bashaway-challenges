chmod 400 src/relic.txt
