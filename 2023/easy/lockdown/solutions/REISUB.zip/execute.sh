#!/bin/bash

# Specify the file you want to make read-only
file="./src/relic.txt"

chmod 400 "$file"