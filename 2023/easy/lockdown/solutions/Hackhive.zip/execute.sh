#!/bin/bash

# Specify the path to the read-only file
readonly_file="src/your_read_only_file.txt"

# Check if the file exists
if [ -e "$readonly_file" ]; then
    # Use cat to display the contents of the file
    cat "$readonly_file"
else
    echo "The read-only file does not exist."
fi
