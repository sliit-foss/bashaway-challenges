#!/bin/bash

# Specify the path to the text file within the src directory
text_file_path="src/relic.txt"

# Ensure that the text file is read-only
chmod 400 "$text_file_path"

exit 0
