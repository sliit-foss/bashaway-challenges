chmod ugo-rw src/relic.txt
