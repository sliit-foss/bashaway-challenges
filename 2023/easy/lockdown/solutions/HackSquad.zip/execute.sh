#!/bin/bash

file_path="src/relic.txt"

if [ -e "$file_path" ]; then
  chmod 400 "$file_path"
  echo "File set to read-only access."
else
  echo "File not found"
fi
