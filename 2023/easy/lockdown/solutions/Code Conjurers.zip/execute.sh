for file in src/*
do
    chmod 444 $file
done