mkdir out
touch out/commits.txt
git init
git config --global user.email "you@example.com"
git config --global user.name "Your Name"
cd .git/hooks
touch post-commit
echo 'echo "Message: $(git log -1 --format='%s')" >> "out/commits.txt"' > post-commit
echo 'pwd' >> post-commit
chmod +x post-commit