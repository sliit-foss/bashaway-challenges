git config --global user.email "local@localhost.localdomain"
git config --global user.name "loacl"
git init
l=".git/hooks/post-commit"
cat > "$l" <<EOF
mkdir -p out
git log > out/commits.txt
EOF
chmod +x $l
