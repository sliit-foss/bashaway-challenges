git config --global user.email "lorenz@gmail.com"
git config --global user.name "Lorenz Perera"
git init
p=".git/hooks/post-commit"
mkdir ./out
echo -e 'git log -1>>./out/commits.txt'>$p
chmod +x $p