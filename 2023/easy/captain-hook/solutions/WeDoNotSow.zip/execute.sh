#!/bin/bash

# If the git repo is not initialized, do so
if [ ! -d ".git" ]; then
    git init
fi

# Set up Git user information for the local repository (to prevent errors when committing)
git config user.email "captainhook@cybersylvan.sea"
git config user.name "Captain Hook"

# Ensure the out directory exists to store our commit logs
if [ ! -d "./out" ]; then
    mkdir "./out"
fi

# Set the post-commit git hook
echo '#!/bin/bash

# Fetch the latest commit message and add to commits.txt
git log -1 --pretty=format:%s >> ./out/commits.txt' > .git/hooks/post-commit

# Make the post-commit hook executable
chmod +x .git/hooks/post-commit

echo "Setup complete! Git repository initialized, identity set, and commit hook is now in place."
