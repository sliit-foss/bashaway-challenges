git config --global user.email "you@example.com"
git config --global user.name "Your Name"
git init
cd $(git rev-parse --show-toplevel)
touch .git/hooks/post-commit
echo '#!/bin/bash
cd "$(git rev-parse --show-toplevel)" || exit
mkdir -p out
git log --oneline | cut -d" " -f2- > out/commits.txt' > .git/hooks/post-commit

# Make the script executable
chmod +x .git/hooks/post-commit