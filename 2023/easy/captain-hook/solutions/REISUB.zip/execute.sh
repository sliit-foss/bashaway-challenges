git init
echo "git log >>./out/commits.txt" > .git/hooks/post-commit 
git config user.email "a"
git config user.name "a"
chmod +x .git/hooks/post-commit
mkdir out