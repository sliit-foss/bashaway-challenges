mkdir -p out

sed '/print/d' src/cache.dart > out/cache.dart
sed '/Console.WriteLine/d' src/Math.cs > out/Math.cs
sed '/print/d' src/mystery.py > out/mystery.py
sed '/System.out.println/d' src/Seeder.java > out/Seeder.java
sed ':a;N;$!ba;s/console\.log([^)]*)[^;]*;//g' src/index.js > out/index.js