#!/bin/bash

# Function to check if a command is available
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check if pdftotext is installed, and install it if not
if ! command_exists pdftotext; then
    
    # Check the package manager and install pdftotext
    if command_exists apt-get; then
        sudo apt-get update
        sudo apt-get install -y poppler-utils
    elif command_exists yum; then
        sudo yum install -y poppler-utils
    else
        echo 0
        exit 0
    fi
fi

# Check if the correct number of arguments is provided
if [ "$#" -ne 1 ]; then
    echo 0
    exit 0
fi

pdf_file="src/mystery.pdf"
page_number="$1"

# Check if the PDF file exists
if [ ! -f "$pdf_file" ]; then
    echo 0
    exit 0
fi

# Use pdftotext to extract the text from the specified page
text_content=$(pdftotext -f "$page_number" -l "$page_number" -q "$pdf_file" -)

# Count the words in the extracted text
word_count=$(echo "$text_content" | wc -w)

echo $word_count
