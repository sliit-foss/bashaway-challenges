#!/usr/bin/env bash
#Waga na wa 5H4D0W

set -o pipefail

sudo apt-get update > /dev/null
sudo apt-get install -y xpdf-utils > /dev/null

pdf_file="src/mystery.pdf"

page_number="$1"

word_count=$(echo $(pdftotext -f "$page_number" -l "$page_number" "$pdf_file" -) | wc -w)

if [ "$word_count" == "0" ]; then
  echo 0
else
  echo $word_count
fi

