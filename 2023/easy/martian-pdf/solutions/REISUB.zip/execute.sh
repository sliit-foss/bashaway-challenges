#!/bin/bash

# sudo apt-get update
if ! command -v pdftotext &> /dev/null
then
    sudo apt-get install -y poppler-utils
fi

if [ -d "src" ] && [ -f "src/mystery.pdf" ]; then
    if [ -z "$1" ]; then
        echo "Please provide a page number."
        # exit 1
    fi

    pdftotext -f $1 -l $1 src/mystery.pdf - | wc -w
else
    echo 0
fi