#!/bin/bash
# Install 'poppler-utils' if not already installed
if ! command -v pdftotext &> /dev/null; then
  sudo apt-get update
  sudo apt-get install -y poppler-utils
fi

# Set default values
pdf_file="src/mystery.pdf"
page_number=1

# # Check if the src directory exists
# if [ ! -d "src" ]; then
#   echo "Error: 'src' directory not found."
#   exit 1
# fi

# Check if a page number is provided as an argument
if [ $# -eq 1 ]; then
  page_number="$1"
fi

# Check if the PDF file exists
# if [ ! -f "$pdf_file" ]; then
#   echo "Error: PDF file not found: $pdf_file"
#   exit 1
# fi

# Extract the text from the specified page using 'pdftotext'
text=$(pdftotext -f "$page_number" -l "$page_number" "$pdf_file" - 2>/dev/null)

# Count the words and output the result
word_count=$(echo "$text" | wc -w)
echo "$word_count"
