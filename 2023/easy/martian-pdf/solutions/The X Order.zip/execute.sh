#!/bin/bash
sudo apt update &> /dev/null
sudo apt install poppler-utils -y &> /dev/null
# Check if the page number is provided as an argument, default to 1 if not provided.
if [ -z "$1" ]; then
  page_number=1
else
  page_number="$1"
fi

# Check if the ./src directory exists and is not empty.
src_dir="./src"
if [ -d "$src_dir" ] && [ "$(ls -A "$src_dir")" ]; then
  # Define the PDF file path.
  pdf_file="$src_dir/mystery.pdf"

  # Check if the PDF file exists.
  if [ -f "$pdf_file" ]; then
    # Use pdftotext to extract text from the specified page and count words.
    #pdftotext -f "$page_number" -l "$page_number" "$pdf_file"
    pdftotext -f "$page_number" -l "$page_number" ./src/mystery.pdf - | wc -w
    #wc -w < ./src/mystery.txt
    #word_count=$(echo "$page_text" | wc -w)
    #echo "$word_count"
  else
    # If the PDF file doesn't exist, output 0.
    echo "0"
  fi
else
  # If the ./src directory is empty or doesn't exist, output 0.
  echo "0"
fi
