#!/bin/bash

# Function to check if a command is available
command_exists() {
  command -v "$1" &>/dev/null
}

# Check if pdftotext is available and install if necessary
if ! command_exists pdftotext; then
  echo "pdftotext is not installed. Attempting to install..."
  
  if command_exists apt-get; then
    sudo apt-get update
    sudo apt-get install -y poppler-utils
  elif command_exists yum; then
    sudo yum install -y poppler-utils
  else
    echo "Unable to install pdftotext. Please install it manually and try again."
    exit 1
  fi
fi

# Check if the src directory exists and is not empty
if [ -d "src" ] && [ "$(ls -A src)" ]; then
  # Check if a page number is provided as an argument
  if [ -n "$1" ]; then
    page_number="$1"
    pdf_file="src/mystery.pdf"
    
    # Check if the PDF file exists
    if [ -f "$pdf_file" ]; then
      # Use pdftotext to extract the text from the specified page
      text=$(pdftotext -f "$page_number" -l "$page_number" "$pdf_file" -)
      
      # Count the number of words in the extracted text
      word_count=$(echo "$text" | wc -w)
      
      echo "$word_count"
    else
      echo "0" # PDF file does not exist
    fi
  else
    echo "0" # Page number is not provided
  fi
else
  echo "0" # src directory is empty or does not exist
fi
