page=$1

if [ $# -eq 0 ]; then
  page=1
fi

if [[ ! $1 =~ ^[0-9]+$ ]]; then
    page=1
fi
sudo apt-get install poppler-utils -y >> /dev/null 2> /dev/null
pdftotext -f $page -l $page ./src/mystery.pdf - | wc -w
