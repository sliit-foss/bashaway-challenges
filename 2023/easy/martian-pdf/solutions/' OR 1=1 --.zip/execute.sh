# A pdf file will be generated within a src directory once the tests are run.

# Write your code here
#!/bin/bash

# Check if the src directory exists and if it contains the mystery.pdf file
if [ -d "src" ] && [ -f "src/mystery.pdf" ]; then
    # Check if a page number was provided
    if [ -z "$1" ]; then
        echo 0
    else
        # Use pdftotext to convert the specific page to text, then use wc to count the words
        pdftotext -f $1 -l $1 src/mystery.pdf - | wc -w
    fi
else
    echo 0
fi
