#!/bin/bash

# Check if the src folder exists
if [ ! -d "src" ]; then
    mkdir "src"
fi

# Check if the out folder exists or create it
if [ ! -d "out" ]; then
    mkdir "out"
fi

awk -v RS="(\n-+\\n*)+" '{
    # Remove leading and trailing whitespace from the section
    gsub(/^[ \t]+|[ \t]+$/, "")
    
    print $0 > "out/" NR ".env"
}' src/secrets.yml

for file in out/*.env; do
    file_content=$(cat "$file")

    found=0
    while read -r line; do
        if [[ $line == *"name:"* ]]; then
            name=$(echo "$line" | sed -n 's/.*name: \([^ ]*\).*/\1/p')

            data=$(echo "$file_content" | awk '/stringData:/ { found=1; next } found { gsub(/^[ \t]+/, ""); print }')
            cleaned_text=$(echo "$data" | sed '/^[[:space:]]*$/d' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

            # cleaned_text=$(echo "$cleaned_text" | sed '0,/:/s//=/')
            
            # for insideLine in $cleaned_text; do
            # echo "$insideLine"
            #     newLine=$(echo "$insideLine" | sed '0,/:/s//=/')
            
            #     echo "$newLine" > "$file"
            # done

            > "$file"
            echo "$cleaned_text" | while IFS= read -r line; do
                processed_line=$(echo "$line" | sed '0,/:/s//=/')
                
                echo "$processed_line" >> "$file"
            done

            # echo "$cleaned_text" > "$file"

            mv "$file" "out/.env.$(echo "$name" | cut -d '-' -f 1)"

            found=1
            break
        fi
    done < "$file"

    if [ $found -eq 0 ]; then
        rm "$file"
    fi
done



