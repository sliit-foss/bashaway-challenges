#!/bin/bash
#make directory if named out if not exists
mkdir -p out
#I need a regex that checks if a string contains screaming snake case
regex="^[[:space:]]*[A-Z_]+:[[:space:]]*\S+"
# #test regex
# if [[ " kind: SECRET" =~ $regex ]]; then
#     echo "match"
# else
#     echo "no match"
# fi
# Need 3 flags
kind=0
name=0
d=0

#initialize empty string current_name
current_name=""

#iterate through src/secrets.yml line by line
while IFS= read -r line; do
    #if line is a comment, skip
    if [[ $line == "#"* ]]; then
        continue
    fi

    #if line is empty, skip
    if [[ $line == "" ]]; then
        continue
    fi

    #if line is a kind, set kind flag
    if [[ $line == "kind: Secret"* ]]; then
        # echo "kind: $line"
        kind=1
        name=0
        d=0
        continue
    fi

    #if line is a name, set name flag
    if [[ $line == *"name:"* ]]; then
        # echo "name: $line"
        
        name_part="${line%%:*}"  # Extract "name"
        current_name=$(echo "$line" | cut -d':' -f2 | cut -d'-' -f1)
        #remove excess space from current_name
        current_name=$(echo $current_name | tr -d '[:space:]')
        # echo "current_name: $current_name"
        #create a .env.{current_name} file in the out folder
        touch "out/.env.$current_name"
        name=1
        continue
    fi

    #if line is stringData, set d flag
    if [[ $line == "stringData:"* ]]; then
        d=1
        continue
    fi

    if [[ $name == 1 && $d == 1 ]]; then
        # Remove excessive spaces from line
        line=$(echo "$line" | tr -s '[:space:]')
        
        # Check if the line matches a regex pattern
        if [[ "$line" =~ $regex ]]; then
            # echo "Matched: $line"
            #Remove anything that comes after two slashes
            line=$(echo "$line" | cut -d'/' -f1)
            #Replace only the first instance of ":" with "=" sign in line
            line=$(echo "$line" | sed 's/:/=/')
            
            echo "$line" >> "out/.env.$current_name"
            
        # else
            # echo "Not matched: $line"
        fi
    fi
done < src/secrets.yml
    
