#!/bin/bash

is_strong_password() {
  password="$1"
  
  if [ -z "$password" ] || [ ${#password} -lt 8 ] || ! [[ "$password" =~ [a-z] ]] || ! [[ "$password" =~ [A-Z] ]] || ! [[ "$password" =~ [0-9] ]]; then
    echo "false"
  else
    echo "true"
  fi
}


password="$1"
is_strong_password "$password"
