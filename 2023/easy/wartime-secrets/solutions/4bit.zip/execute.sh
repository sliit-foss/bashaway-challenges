#!/bin/bash

isStrongPassword() {
    password=$1

    # Check conditions
    has_lowercase=$(echo "$password" | grep -q '[a-z]'; echo $?)
    has_uppercase=$(echo "$password" | grep -q '[A-Z]'; echo $?)
    has_numeric=$(echo "$password" | grep -q '[0-9]'; echo $?)
    is_long_enough=$( [ ${#password} -ge 8 ] && echo 0 || echo 1 )

    # Print result
    if [ $has_lowercase -eq 0 ] && [ $has_uppercase -eq 0 ] && [ $has_numeric -eq 0 ] && [ $is_long_enough -eq 0 ]; then
        echo "true"
    else
        echo "false"
    fi
}

# Example usage
result=$(isStrongPassword "$1")
echo "$result"
