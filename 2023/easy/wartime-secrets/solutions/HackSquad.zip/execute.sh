#!/bin/bash

password="$1"

has_lowercase=false
has_uppercase=false
has_numeric=false
is_long_enough=false

for ((i = 0; i < ${#password}; i++)); do
    char="${password:$i:1}"
    
    if [[ "$char" =~ [a-z] ]]; then
        has_lowercase=true
    fi
    
    if [[ "$char" =~ [A-Z] ]]; then
        has_uppercase=true
    fi
    
    if [[ "$char" =~ [0-9] ]]; then
        has_numeric=true
    fi
done

if [ ${#password} -ge 8 ]; then
    is_long_enough=true
fi

if [ "$has_lowercase" = true ] && [ "$has_uppercase" = true ] && [ "$has_numeric" = true ] && [ "$is_long_enough" = true ]; then
    echo "true"
else
    echo "false"
fi
