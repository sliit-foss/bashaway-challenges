password="$1"

# Initialize variables to check conditions
has_lowercase=false
has_uppercase=false
has_numeric=false
is_long_enough=false

# Check each character in the password
for ((i = 0; i < ${#password}; i++)); do
  char="${password:$i:1}"
  if [[ $char =~ [a-z] ]]; then
    has_lowercase=true
  elif [[ $char =~ [A-Z] ]]; then
    has_uppercase=true
  elif [[ $char =~ [0-9] ]]; then
    has_numeric=true
  fi
done

# Check conditions
if [ ${#password} -ge 9 ]; then
  is_long_enough=true
fi

# Check if the password meets all conditions
if $has_lowercase && $has_uppercase && $has_numeric && $is_long_enough; then
  echo "true"
else
  echo "false"
fi
