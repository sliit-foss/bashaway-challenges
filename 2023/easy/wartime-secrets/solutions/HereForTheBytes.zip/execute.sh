is_strong_password() {
    local password="$1"

    if [[ ! "$password" =~ [a-z] ]]; then
        echo "false"
        return
    fi

    if [[ ! "$password" =~ [A-Z] ]]; then
        echo "false"
        return
    fi

    if [[ ! "$password" =~ [0-9] ]]; then
        echo "false"
        return
    fi

    if [ ${#password} -lt 8 ]; then
        echo "false"
        return
    fi

    echo "true"
}

randomPassword="$1"

is_strong_password "$randomPassword"
