#!/bin/bash

trim() {
  local string="$1"
  echo "$string" | xargs
}

contains_lowercase() {
  local string="$1"
  if [[ "$string" =~ [a-z] ]]; then
    return 0  
  else
    return 1  
  fi
}

contains_uppercase() {
  local string="$1"
  if [[ "$string" =~ [A-Z] ]]; then
    return 0  
  else
    return 1  
  fi
}

contains_numeric() {
  local string="$1"
  if [[ "$string" =~ [0-9] ]]; then
    return 0  
  else
    return 1  
  fi
}

if [ "$#" -ne 1 ]; then
  echo "false"
fi

password="$(trim "$1")"

if [ ${#password} -ge 8 ] && contains_lowercase "$password" && contains_uppercase "$password" && contains_numeric "$password"; then
  echo "true"
else
  echo "false"
fi
