#!/bin/bash

# Get the password from the command line arguments
password=$1

# Check the conditions
if [[ ${#password} -ge 8 ]] && [[ "$password" =~ [a-z] ]] && [[ "$password" =~ [A-Z] ]] && [[ "$password" =~ [0-9] ]]; then
    echo -n "true"
else
    echo -n "false"
fi
