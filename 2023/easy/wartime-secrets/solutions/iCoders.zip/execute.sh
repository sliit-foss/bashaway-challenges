#!/bin/bash

# Default password (change this to your desired default password)
default_password="BashWay@23"

# Function to check if a password is strong enough
isStrongPassword() {
  local password="$1"

  # Check if the password length is at least 8 characters
  if [ ${#password} -lt 8 ]; then
    echo "false"
    return
  fi

  # Check if the password contains at least 1 lowercase letter
  if [[ ! "$password" =~ [a-z] ]]; then
    echo "false"
    return
  fi

  # Check if the password contains at least 1 uppercase letter
  if [[ ! "$password" =~ [A-Z] ]]; then
    echo "false"
    return
  fi

  # Check if the password contains at least 1 numeric character
  if [[ ! "$password" =~ [0-9] ]]; then
    echo "false"
    return
  fi

  # If all conditions are met, the password is strong
  echo "true"
}

# Main script
if [ $# -eq 0 ]; then
  password="$default_password"
else
  password="$1"
fi

result=$(isStrongPassword "$password")
echo "$result"
