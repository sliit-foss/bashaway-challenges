#!/bin/bash

# Check if a string contains at least 1 lowercase character
contains_lowercase() {
  [[ $1 =~ [a-z] ]]
}

# Check if a string contains at least 1 uppercase character
contains_uppercase() {
  [[ $1 =~ [A-Z] ]]
}

# Check if a string contains at least 1 numeric character
contains_numeric() {
  [[ $1 =~ [0-9] ]]
}

# Check if a string is at least 8 characters long
is_long_enough() {
  [ ${#1} -ge 8 ]
}

# Main function to check password strength
check_password_strength() {
  password="$1"

  if contains_lowercase "$password" && contains_uppercase "$password" && contains_numeric "$password" && is_long_enough "$password"; then
    echo "true"
  else
    echo "false"
  fi
}

# Read the password from command line argument
if [ $# -ne 1 ]; then
  exit 0
fi

check_password_strength "$1"
