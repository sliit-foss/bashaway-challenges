#!/bin/bash

# Function to check if a string contains at least one lowercase character
contains_lowercase() {
  [[ "$1" =~ [a-z] ]]
}

# Function to check if a string contains at least one uppercase character
contains_uppercase() {
  [[ "$1" =~ [A-Z] ]]
}

# Function to check if a string contains at least one numeric character
contains_numeric() {
  [[ "$1" =~ [0-9] ]]
}

# Function to check if a string is exactly 8 characters long
is_length_valid() {
  local length=${#1}
  [ "$length" -ge 8 ]
}

# Main script
password="$1"

if contains_lowercase "$password" && contains_uppercase "$password" && contains_numeric "$password" && is_length_valid "$password"; then
  echo "true"
else
  echo "false"
fi
