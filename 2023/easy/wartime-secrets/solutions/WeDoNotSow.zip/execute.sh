#!/bin/bash

# Function to check if the password is strong
is_strong_password() {
    local password="$1"
    # Use regular expressions to check the conditions
    if [[ ${#password} -gt 9  &&       # Contains at least 1 lowercase character
          $password =~ [A-Z] &&       # Contains at least 1 uppercase character
          $password =~ [0-9] &&       # Contains at least 1 numeric character
          $password =~ [a-z] ]];     # Is at least 8 characters long
    then
        echo "true"
    else
        echo "false"
    fi
}

# Get the password as a command-line argument
password="$1"

# Check if the password is strong
is_strong_password "$password"
