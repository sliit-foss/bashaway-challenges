#!/bin/bash

# Read the password from the command-line argument
password=$1

# Define regex patterns for each condition
lowercase="[a-z]"
uppercase="[A-Z]"
numeric="[0-9]"

# Check if the password meets all conditions
if [[ $password =~ $lowercase && $password =~ $uppercase && $password =~ $numeric && ${#password} -ge 8 ]]; then
    echo "true"
else
    echo "false"
fi
