cd src

ln -sf a.txt b.txt