cd src
ln -s a.txt b.txt