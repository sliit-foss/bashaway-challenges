ln -s a.txt src/b.txt

