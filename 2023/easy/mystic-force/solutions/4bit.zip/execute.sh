cd src;ln -f a.txt b.txt
