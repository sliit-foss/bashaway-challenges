#!/bin/bash
directory="src"

total_size=$(find "$directory" -type f -exec du -cb {} + | grep total$ | awk '{sum+=$1} END {print sum}')

echo  $total_size