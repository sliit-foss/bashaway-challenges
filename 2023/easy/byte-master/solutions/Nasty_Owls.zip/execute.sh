# A random count of files will be generated within the src directory once the tests are run.

# Write your code here
cd src

sum=0
while IFS= read -r file; do
    bytes=$(wc -c < "$file")
    sum=$((sum + bytes))
done < <(find . -type f)

echo "$sum"
