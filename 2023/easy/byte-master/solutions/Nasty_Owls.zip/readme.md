## Instructions:

1. pnpm install
2. pnpm run test
