sum=0
for file in ./src/*; 
do
    if [ -f "$file" ]; then  # Check if it's a regular file
        size=$(stat -c %s "$file")  # Get the file size in bytes
        sum=$((sum + size))  # Add the file size to the sum
    fi
done

echo $sum