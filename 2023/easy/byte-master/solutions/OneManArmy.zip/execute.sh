# A random count of files will be generated within the src directory once the tests are run.

# Write your code here

src_folder="src"

file_list=$(find "$src_folder" -type f)

total_size=0

for file in $file_list; do
  size=$(stat -c %s "$file")
  total_size=$((total_size + size))
done

echo "$total_size"
