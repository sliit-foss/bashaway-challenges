# A random count of files will be generated within the src directory once the tests are run.

# Write your code here
total_size=$(du -sb src | awk '{print $1}')
adjusted_size=$((total_size - 4096))
echo $adjusted_size
