# A random count of files will be generated within the src directory once the tests are run.

# Print du src minus 4096
du ./src -sb | awk '{print $1-4096}'
