#!/bin/bash

# Check if the 'src' folder exists
if [ ! -d "src" ]; then
  echo "Folder not found: src"
  exit 1
fi

# Calculate the total byte size of all files within 'src'
total_size=$(find src -type f -print0 | sort -z | xargs -0 du -b | awk '{ total += $1 } END { print total }')

# Display the total size in bytes
echo "$total_size"
