#!/bin/bash

# Initialize total size variable
total_size=0

# Loop through files in the src directory
for file in src/*
do
    # Check if the file is a regular file
    if [ -f "$file" ]
    then
        # Get the size of the file and add it to the total
        file_size=$(wc -c < "$file")
        total_size=$((total_size + file_size))
    fi
done

# Print the total size in bytes
echo $total_size