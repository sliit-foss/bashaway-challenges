# A random count of files will be generated within the src directory once the tests are run.

# Write your code here

#!/bin/bash

# Initialize a variable to store the total size
total_size=0

# Use a 'find' command to recursively list all files in the 'src' folder
# and then calculate the size of each file and add it to the total_size
find src -type f -exec du -b {} + | awk '{sum+=$1} END {print sum}' > total_size.txt

# Read the total_size from the file and print it to the console
cat total_size.txt

# Clean up the temporary file
rm total_size.txt