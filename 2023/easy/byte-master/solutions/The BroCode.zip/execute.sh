# A random count of files will be generated within the src directory once the tests are run.

# Write your code here

#!/bin/bash
src_folder="src"
total_size=$(find "$src_folder" -type f -exec stat -c "%s" {} + | awk '{sum += $1} END {print sum}')
echo "$total_size"