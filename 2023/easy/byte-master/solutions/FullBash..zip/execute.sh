# A random count of files will be generated within the src directory once the tests are run.

# Write your code here
#!/bin/bash

# Define the path to the src directory
src_dir="./src"

# Check if the src directory exists
if [ ! -d "$src_dir" ]; then
    echo "Error: The 'src' directory does not exist."
    exit 1
fi

# Use the 'find' command to calculate the total size of all files in bytes
total_size=$(find "$src_dir" -type f -exec stat -c %s {} + | awk '{s+=$1} END {print s}')

# Output the total size in bytes directly to the console
echo "$total_size"


