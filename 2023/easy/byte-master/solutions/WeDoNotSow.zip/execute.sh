# A random count of files will be generated within the src directory once the tests are run.

# Write your code here
#!/bin/bash

# Set the path to your source folder

# Navigate to the source folder
cd "src/" || exit

# Loop through each file in the folder
total_bytes=0
for file in *; do
    if [[ -f "$file" ]]; then
        # Get the size of the file in bytes
        file_size=$(wc -c < "$file")
        ((total_bytes += file_size))
    fi
done

# Echo the total byte count
echo "$total_bytes"
