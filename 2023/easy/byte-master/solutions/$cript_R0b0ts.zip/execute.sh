#!/bin/bash

total_size=0

for file in "src"/*; do
  if [ -f "$file" ]; then

    file_size=$(stat -c %s "$file")
    total_size=$((total_size + file_size))
  fi
done

echo "$total_size"
