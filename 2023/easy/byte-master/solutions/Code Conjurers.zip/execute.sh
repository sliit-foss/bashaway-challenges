# A random count of files will be generated within the src directory once the tests are run.

# Write your code here

#!/bin/bash

src_directory="src"

total=0
# 7402435

for file in "$src_directory"/*; do
  filesize=$(wc -c <"$file")
  # add the file size to the total
  total=$((total + filesize))
done

echo "$total"