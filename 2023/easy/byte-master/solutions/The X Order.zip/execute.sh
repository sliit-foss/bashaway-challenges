# A random count of files will be generated within the src directory once the tests are run.

#!/bin/bash

# Use find to list all files in the src folder and calculate their total size
total_size=0
while IFS= read -r -d '' file; do
    file_size=$(stat -c %s "$file")
    total_size=$((total_size + file_size))
done < <(find src -type f -print0)

# Display the total size in bytes
echo "$total_size"


