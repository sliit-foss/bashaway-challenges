# A random count of files will be generated within the src directory once the tests are run.

# Write your code here
total_size=0

while read -r size file; do
  total_size=$((total_size + size))
done < <(find src -type f -exec du -b {} +)

echo $total_size