# check whether the first argument is empty.

if [ -z "$1" ]; then
    exit 0
fi

filename="src/logs.txt"
 
while IFS= read -r line
do
  if [[ "$line" == *"$1"* ]]; then
  echo "$line"
fi
done < "$filename"