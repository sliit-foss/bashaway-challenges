#!/bin/bash


correlation_id=$1
# Search for matching rows in the text file
grep "$correlation_id" ./src/logs.txt
