#!/bin/bash

filename="./src/logs.txt"

if grep -q $1 "$filename"; then
    grep $1 "$filename"
fi