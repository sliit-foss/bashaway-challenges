#!/bin/bash

line_start_target="{"

if [ -z "$1" ]; then # exit if no arg passed
    exit 0
else
    while read -r line || [ -n "$line" ]; do         # read each line
        if [[ $line = "$line_start_target"* ]]; then # if line starts with {
            # split file to get correlation_ID
            correlation_split=$(awk -F ',' '{print $1}' <<<"$line")
            correlation_id=$(awk -F '"' '{print $4}' <<<"$correlation_split")

            if [ "$correlation_id" = "$1" ]; then
                echo "$line"
            fi

        fi
    done <./src/logs.txt
fi
