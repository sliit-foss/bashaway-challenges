#!/bin/bash

# Check if a correlationId is provided as a command-line argument
if [ $# -ne 1 ]; then
  echo "Usage: $0 <correlationId>"
  exit 0
fi

# Store the provided correlationId in a variable
target_correlationId="$1"

# Specify the path to the text file
text_file="src/logs.txt"

# Check if the text file exists
if [ ! -f "$text_file" ]; then
  echo "Text file '$text_file' not found."
  exit 0
fi

# Search for and print lines with the specified correlationId
grep -F "\"correlationId\":\"$target_correlationId\"" "$text_file"
