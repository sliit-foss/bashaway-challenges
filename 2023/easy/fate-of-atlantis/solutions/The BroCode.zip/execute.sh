if [ ! -d "src" ] ; then
    exit 0
fi

if [ $# -lt 1 ]; then
    exit 0
fi

log_id=$1

while IFS= read -r line; do
  # Check if the line contains the target correlationId
  if [[ $line == *"$log_id"* ]]; then
    echo "$line"
  fi
done < src/logs.txt

