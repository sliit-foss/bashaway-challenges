#!/bin/bash

# Assuming your log file is named 'logfile.txt'
logfile="src/logs.txt"

# Check if the file exists
if [ ! -f "$logfile" ]; then
  echo "Error: $logfile does not exist."
  exit 1
fi

# Get the input from command line argument
search_input=$1

# # Check if input is provided
# if [ -z "$search_input" ]; then
#   echo "Error: No input provided."
#   exit 1
# fi

# Read the log file line by line
while IFS= read -r line; do
  if [[ "$line" == *"$search_input"* ]]; then
    echo "$line"
  fi
done < "$logfile"
