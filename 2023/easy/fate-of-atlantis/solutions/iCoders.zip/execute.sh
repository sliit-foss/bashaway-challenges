#!/bin/bash

# Check if a correlation id is provided
if [ -z "$1" ]; then
  echo "No correlation ID provided."
  exit 0
fi

correlation_id=$1
logfile="src/logs.txt"

# Check if log file exists
if [ ! -f "$logfile" ]; then
  echo "Log file '$logfile' does not exist."
  exit 1
fi

# Search for and print log entries with the given correlation id
found=0
while read -r line; do
  if [[ "$line" == *"$correlation_id"* ]]; then
    echo "$line"
    found=1
  fi
done < "$logfile"

if [ $found -eq 0 ]; then
  echo "No log entries found for the correlation ID '$correlation_id'."
fi

# Exit successfully
exit 0
