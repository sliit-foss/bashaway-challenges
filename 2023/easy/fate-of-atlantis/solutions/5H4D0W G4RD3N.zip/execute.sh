#!/bin/bash

# Define the path to the log file (e.g., src.log)
log_file="./src/logs.txt"

# Check if the log file exists
if [ ! -f "$log_file" ]; then
    echo "Log file not found: $log_file"
    exit 1
fi

# Check if a correlation code is provided as a command-line argument
if [ "$#" -eq 1 ]; then
    correlation_code="$1"
    # Use grep to search for log entries with the specified correlation code
    matching_entries=$(grep "$correlation_code" "$log_file")

    # Check if any matching entries were found
    if [ -n "$matching_entries" ]; then
        # Display the matching entries in the order they appear in the log file
        echo "$matching_entries"
    else
        echo "No matching log entries found for correlation code: $correlation_code"
    fi
else
    echo "Usage: $0 <correlation_code>"
fi
