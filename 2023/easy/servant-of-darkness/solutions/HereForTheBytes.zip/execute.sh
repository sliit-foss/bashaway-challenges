echo "127.0.0.1 	devstoreaccount1.blob.core.windows.net" | sudo tee -a /etc/hosts
docker run -d -p 12000:10000 mcr.microsoft.com/azure-storage/azurite
