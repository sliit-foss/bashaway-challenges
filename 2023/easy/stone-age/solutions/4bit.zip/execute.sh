sudo apt-get update
sudo apt-get install fpc


src_directory="src"
pascal_script="markings.pas"

cd "$src_directory" || exit 1

fpc -o"$pascal_script" "$pascal_script"

./"$pascal_script"

rm "$pascal_script"

cd - || exit 1
