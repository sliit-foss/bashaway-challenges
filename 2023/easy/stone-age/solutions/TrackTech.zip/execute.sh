#!bin/sh
if ! command -v fpc &> /dev/null
then
    sudo apt-get install -y fp-compiler
fi

program='./src/markings.pas'

if [ true ]; then
    binary_file="./src/program"
    fpc $program -o$binary_file
    "$binary_file"
    rm "$binary_file"
fi

sudo apt-get remove -y fp-compiler

