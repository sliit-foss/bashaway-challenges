sudo apt-get install fp-compiler -y
pc ./src/markings.pas
./src/markings