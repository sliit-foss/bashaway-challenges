sudo apt-get update

sudo apt-get install fpc

fpc src/markings.pas

./src/markings