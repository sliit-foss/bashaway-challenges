#!/bin/bash

# Set the path to your Pascal script
pascal_script="src/markings.pas"

# Function to check if a command is available
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check if fpc is installed, and install it if not
if ! command_exists fpc; then

    # Check the package manager and install fpc
    if command_exists apt-get; then
        sudo apt-get update
        sudo apt-get install -y fp-compiler
    elif command_exists yum; then
        sudo yum install -y fpc
    else
        exit 1
    fi
fi

# Check if the Pascal script exists
if [ ! -f "$pascal_script" ]; then
    exit 1
fi

# Compile the Pascal script
fpc "$pascal_script" > /dev/null 2>&1

# Check if compilation was successful
if [ $? -eq 0 ]; then
    ./src/markings

    # Delete the generated files
    rm ./src/markings ./src/*.o
fi
