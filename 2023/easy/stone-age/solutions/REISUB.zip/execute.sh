sudo apt-get install fp-compiler >> /dev/null

fpc ./src/markings.pas >> /dev/null
./src/markings