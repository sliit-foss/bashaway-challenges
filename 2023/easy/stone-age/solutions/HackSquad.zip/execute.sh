#!/bin/bash

if ! command -v fpc &> /dev/null; then
    sudo apt-get update
    sudo apt-get install -y fp-compiler
fi

cd src
fpc markings.pas
./markings