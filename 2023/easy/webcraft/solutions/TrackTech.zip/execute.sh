#!/bin/bash

# Define variables
DOCKER_IMAGE_NAME="webcraft"
HTML_FILE="./src/page.html"
DOCKERFILE_CONTENT="
FROM nginx:latest
COPY $HTML_FILE /usr/share/nginx/html/index.html
RUN chown -R nginx:nginx /usr/share/nginx/html && chmod -R 755 /usr/share/nginx/html

"

# Create a Dockerfile with the provided content
echo "$DOCKERFILE_CONTENT" > Dockerfile

# Build the Docker image
sudo docker build -t $DOCKER_IMAGE_NAME .

# Clean up the Dockerfile
rm -f Dockerfile

# Run the Docker container
sudo docker run -d -p 8085:80 $DOCKER_IMAGE_NAME

# Display container status
sudo docker ps | grep $DOCKER_IMAGE_NAME
