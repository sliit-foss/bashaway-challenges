#!/bin/bash

# Navigate to the directory containing page.html
cd ./src

# Start a Node.js HTTP server and serve page.html on port 8085 in the background
node -e "var http = require('http'), fs = require('fs');
http.createServer(function (req, res) {
    fs.readFile('page.html', 'utf8', function(err, data) {
        if (err) {
            res.writeHead(500);
            return res.end('Error loading page.html');
        }
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end(data);
    });
}).listen(8085, function() {
    console.log('Server running at http://localhost:8085/');
})" &

