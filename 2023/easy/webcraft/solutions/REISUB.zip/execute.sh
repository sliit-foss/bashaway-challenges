cd src
php -S localhost:8085 page.html &