docker build ./ -t nginx
docker run -d -p 8085:80 nginx
rm Dockerfile

