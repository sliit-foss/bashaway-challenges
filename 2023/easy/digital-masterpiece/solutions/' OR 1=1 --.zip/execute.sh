base64 src/input.txt
