f="src/input.txt"
c=$(base64 "$f")
echo "$c"
