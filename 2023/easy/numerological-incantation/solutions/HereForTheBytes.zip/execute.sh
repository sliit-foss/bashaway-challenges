#!/bin/bash

if [ $# -eq 0 ]; then
    echo "Please pass in a number as an argument to the script."
    exit 0
fi

function prime_factors {
    num=$1
    factors=()

    for ((i=2; i<=$num; i++)); do
        while ((num % i == 0)); do
            factors+=($i)
            num=$((num / i))
        done
    done

    echo "${factors[@]}" | tr ' ' 'x'
}

prime_factors "$1"