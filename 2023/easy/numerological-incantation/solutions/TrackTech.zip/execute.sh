#!/bin/bash
factors=()

re='^[0-9]+$'
if ! [[ $1 =~ $re ]] ; then
echo "Please pass in a number as an argument to the script.";
else



Num=$(($1))

#if input is not a number echo error

# Divide the input number by 2 until it is no longer divisible by 2
while [ $(($Num % 2)) -eq 0 ]
do
    factors+=("2")
    ((Num /= 2))
done

# Check if the resulting number is a prime number
if [ $1 -gt 2 ]
then
    # Find the smallest prime factor of the number
    for (( i=3; i<=$Num; i+=2 ))
    do
        while [ $(($Num % $i)) -eq 0 ]
        do
            # Add the smallest prime factor to the array of prime factors
            factors+=("$i")
            ((Num /= $i))
        done
    done
fi

# Print the array of prime factors
# echo "${factors[@]}"



separator="x"
foo=( "${factors[@]}")
regex="$( printf "${separator}%s" "${foo[@]}" )"
regex="${regex:${#separator}}" # remove leading separator
echo "${regex}"

# for i in "${factors[@]}"
# do
# echo "$i"
# # or do whatever with individual element of the array
# done

fi