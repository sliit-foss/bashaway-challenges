#!/bin/bash
if [ -z "$1" ]; then
  echo "Please pass in a number as an argument to the script."
else
  number=$1
  factors=""
  divisor=2
  while [ $number -gt 1 ]; do
    if [ $((number % divisor)) -eq 0 ]; then
      factors="${factors}$divisor"
      number=$((number / divisor))
      if [ $number -gt 1 ]; then
        factors="${factors} x "
      fi
    else
      divisor=$((divisor + 1))
    fi
  done
  echo $factors
fi