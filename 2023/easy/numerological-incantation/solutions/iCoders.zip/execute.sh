#!/bin/bash

# Function to check if a number is prime
is_prime() {
    local num=$1
    if [ "$num" -lt 2 ]; then
        return 1
    fi
    for ((i=2; i*i <= num; i++)); do
        if [ $(($num % $i)) -eq 0 ]; then
            return 1
        fi
    done
    return 0
}

# Function to compute prime factors of a number
prime_factors() {
    local num=$1
    local factors=""
    
    for ((i=2; i <= num; i++)); do
        while [ $(($num % $i)) -eq 0 ]; do
            if [ -z "$factors" ]; then
                factors="$i"
            else
                factors="$factors x $i"
            fi
            num=$(($num / $i))
        done
    done

    echo "$factors"
}

# Main script execution
if [ "$#" -ne 1 ]; then
    echo "Please pass in a number as an argument to the script."
else
    number=$1
    if is_prime "$number"; then
        echo "$number"
    else
        echo "$(prime_factors "$number")"
    fi
fi
