#!/bin/bash

# Check if an argument is provided
if [ $# -eq 0 ]; 
then
    echo "Please pass in a number as an argument to the script."
    exit 0 #doesnt crash
else
    N=$1
fi


#echo $1
#echo $Num

# Function to check if a number is prime
# Use the 'factor' command to find the prime factors and store the result
result=$(factor "$N")

# Count the number of prime factors
count=$(echo "$result" | awk '{print NF-1}')

# If there's only one prime factor, print it
if [ "$count" -eq 1 ]; then
  prime_factor=$(echo "$result" | awk '{print $2}')
  echo "$prime_factor"
else
  # If there are multiple prime factors, print them in the desired format
  prime_factors=$(echo "$result" | awk '{ for (i=2; i<=NF; i++) { printf "%s", $i; if (i != NF) printf " x " } }')
  echo "$prime_factors"
fi

# Use the 'factor' command to find the prime factors and store the result
