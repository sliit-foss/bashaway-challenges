#!/bin/bash

# Function to calculate and display prime factors of a number
calculate_prime_factors() {
  n=$1
  factors=""
  i=2

  while [ $i -le $n ]; do
    if [ $((n % i)) -eq 0 ]; then
      factors="$factors$i"
      n=$((n / i))
      if [ $n -gt 1 ]; then
        factors="${factors}x"
      fi
    else
      i=$((i + 1))
    fi
  done

  echo "$factors"
}

# Check if a number is provided as an argument
if [ $# -eq 1 ]; then
  number=$1

  # Check if the provided number is a positive integer
  if [[ $number =~ ^[1-9][0-9]*$ ]]; then
    echo "$(calculate_prime_factors $number)"
  else
    echo "Please provide a positive integer as an argument."
  fi
else
  echo "Please pass in a number as an argument to the script."
fi
