#!/bin/bash
is_prime() {
    local n=$1

    if [ $n -le 1 ]; then
        return 1
    fi

    if [ $n -le 3 ]; then
        return 0
    fi

    if [ $((n % 2)) -eq 0 ] || [ $((n % 3)) -eq 0 ]; then
        return 1
    fi

    local i=5
    while [ $((i * i)) -le $n ]; do
        if [ $((n % i)) -eq 0 ] || [ $((n % (i + 2))) -eq 0 ]; then
        return 1
        fi
        i=$((i + 6))
    done

    return 0
}

if [ $# -lt 1 ]; then
    echo "Please pass in a number as an argument to the script."
    exit 0
fi

number=$1

if is_prime "$number"; then
    echo "$number"
else    
    divisor=2
    prime_factors=()

    while [ $number -gt 1 ]; do
        if [ $((number % divisor)) -eq 0 ]; then
            prime_factors+=("$divisor")
            number=$((number / divisor))
        else
            divisor=$((divisor + 1))
        fi
    done

    num_factors=${#prime_factors[@]}

    for ((i=0; i<num_factors; i++)); do
        factor="${prime_factors[i]}"
        echo -n "$factor"

        if [ $i -ne $((num_factors - 1)) ]; then
            echo -n " x "
        fi
    done

    echo
fi
