#!/bin/bash
echo '{ "cpu": "'$(lscpu | grep "Model name" | awk -F ':' '{print $2}' | sed -e 's/^[ \t]*//')'", "cores": '$(nproc)', "memory": "'$(free -h | awk '/Mem/ {printf "%.1f GB", $2}')'", "hostname": "'$(hostname)'" }'
