#!/bin/bash
echo "{\"cpu\":\"$(lscpu | grep 'Model name' | cut -d ':' -f2 | xargs)\",\"cores\":$(nproc),\"memory\":\"$(awk '/MemTotal/ {printf "%.1f GB", $2/1024/1024}' /proc/meminfo)\",\"hostname\":\"$(hostname)\"}"
