cpu_cores=$(nproc)
cpu_name=$(lscpu | grep "Model name" | awk -F ':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')
memory=$(free -m | awk 'NR==2{printf "%.1f GB", $2/1024}')
hostname=$(hostname)
echo '{"cpu":"'$cpu_name'", "cores":'$cpu_cores', "memory":"'$memory'", "hostname":"'$hostname'"}'