[ "$1" = "$(rev <<< $1)" ]&& echo 1||echo 0
