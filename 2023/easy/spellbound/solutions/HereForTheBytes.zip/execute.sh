if [ -d "src" ]; then
    json_files=$(find src -type f -name "*.json")

    echo $(jq -r 'index(.[] | select(.name == "bashaway")) | tostring' "$json_files")
else
  exit 0
fi