#!/bin/bash

# Hardcoded file path and delimiter
file_path="src/grimoire.json"
delimiter='"name":"bashaway"'

# Check if the file exists
if [ ! -f "$file_path" ]; then
    # echo "File not found: $file_path"
    exit 0
fi

# Read the string from the file and remove newline characters
input_string=$(tr -d '\n' < "$file_path")

# Split the string using the hardcoded delimiter
first_piece=$(echo "$input_string" | awk -F "$delimiter" '{print $1}')
second_piece=$(echo "$input_string" | awk -F "$delimiter" '{print $2}')


# Count the number of "{" characters and print it
count_braces=$(grep -o "{" <<< "$first_piece" | wc -l)
count_braces=$((count_braces - 1))
echo "$count_braces"
