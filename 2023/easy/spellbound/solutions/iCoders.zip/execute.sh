#!/bin/bash

# Check if src directory exists and is not empty
if [ -d "src" ] && [ "$(ls -A src)" ]; then
    # Parse the JSON files in the src directory
    for file in src/*.json; do
        # Use jq to find the index of the object with key "name" and value "bashaway"
        jq 'to_entries | .[] | select(.value.name == "bashaway") | .key' "$file"
    done
else
    echo "src directory is empty or does not exist."
fi
