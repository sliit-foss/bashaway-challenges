file=$(<./src/grimoire.json)
echo $(( $(awk -F':' '{ print $1 }' <<< $(sed 's/},{/}\n{/g' <<< $file | grep "bashaway" -n)) - 1 ))