#!/bin/bash

# Check if the src directory exists
if [ ! -d "src" ]; then
    echo "The 'src' directory does not exist."
fi

# Check if the JSON file exists in the src directory
json_file="src/grimoire.json"
if [ ! -f "$json_file" ]; then
    echo "The JSON file 'src/file.json' does not exist."
fi

# Use jq to search for the object with key "name" holding the value "bashaway"
index=$(jq -c '.[] | select(.name == "bashaway")' "$json_file")

# Check if the index is not empty
if [ ! -z "$index" ]; then
    # Convert the JSON objects to an array and find the index
    array=($(jq -c '.[]' "$json_file"))
    array_length=${#array[@]}
    for i in "${!array[@]}"; do
        if [[ "${array[$i]}" == "$index" ]]; then
            echo "$i"
            exit 0
        fi
    done
fi

# If not found, print a message
echo "No object with key 'name' holding the value 'bashaway' found in 'src/file.json'."
