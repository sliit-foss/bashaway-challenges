docker pull mongo:latest

if [ ! "$(docker ps -a | grep bashaway-2k23-sunset)" ]; then
    docker run -d --name bashaway-2k23-sunset -p 27207:27017 mongo # Data will be populated into this instance once the tests are run.
fi

if [ ! "$(docker ps -a | grep bashaway-2k23-sunrise)" ]; then
    docker run -d --name bashaway-2k23-sunrise -p 27208:27017 mongo # Target instance to migrate data to.
fi

# Dump the data from bashaway-2k23-sunset
docker exec bashaway-2k23-sunset mongodump --archive=/data/db/dump.gz --gzip

# Copy the dump file from bashaway-2k23-sunset to the local working directory
docker cp bashaway-2k23-sunset:/data/db/dump.gz ./dump.gz

# Restore this data into bashaway-2k23-sunrise
docker cp ./dump.gz bashaway-2k23-sunrise:/data/db/dump.gz
docker exec bashaway-2k23-sunrise mongorestore --drop --archive=/data/db/dump.gz --gzip

# Cleanup
rm -f ./dump.gz
docker exec bashaway-2k23-sunrise rm -f /data/db/dump.gz
docker exec bashaway-2k23-sunset rm -f /data/db/dump.gz