module.exports = {
    maxWorkers: 1
};
