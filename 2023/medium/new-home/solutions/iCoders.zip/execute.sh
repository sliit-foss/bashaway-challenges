#!/bin/bash

# Pull the latest MongoDB Docker image
docker pull mongo:latest

# Check and start bashaway-2k23-sunset container if it doesn't exist
if [ ! "$(docker ps -a | grep bashaway-2k23-sunset)" ]; then
    docker run -d --name bashaway-2k23-sunset -p 27207:27017 mongo
fi

# Check and start bashaway-2k23-sunrise container if it doesn't exist
if [ ! "$(docker ps -a | grep bashaway-2k23-sunrise)" ]; then
    docker run -d --name bashaway-2k23-sunrise -p 27208:27017 mongo
fi

# Sleep for a few seconds to allow the MongoDB instances to initialize fully
sleep 10

# Export all databases from the first container
docker exec bashaway-2k23-sunset mongodump --archive=/tmp/dump.archive

# Copy the dump file from the first container to the host machine
docker cp bashaway-2k23-sunset:/tmp/dump.archive ./dump.archive

# Copy the dump file from the host machine to the second container
docker cp ./dump.archive bashaway-2k23-sunrise:/tmp/dump.archive

# Import all databases into the second container
docker exec bashaway-2k23-sunrise mongorestore --drop --archive=/tmp/dump.archive

# Clean up: remove the dump files from the containers and the host machine
docker exec bashaway-2k23-sunset rm /tmp/dump.archive
docker exec bashaway-2k23-sunrise rm /tmp/dump.archive
rm ./dump.archive
