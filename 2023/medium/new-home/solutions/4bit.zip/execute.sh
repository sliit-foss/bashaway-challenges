
# Write your code here
#!/bin/bash

container_name_sunset="your-sunset-container-name"
container_name_sunrise="your-sunrise-container-name"
port_sunset=27207
port_sunrise=27208

mongo_image="mongo:latest"

docker pull $mongo_image

if [ ! "$(docker ps -a | grep $container_name_sunset)" ]; then
    docker run -d --name $container_name_sunset -p $port_sunset:27017 $mongo_image
fi

if [ ! "$(docker ps -a | grep $container_name_sunrise)" ]; then
    docker run -d --name $container_name_sunrise -p $port_sunrise:27017 $mongo_image
fi

sleep 10

docker exec $container_name_sunset mongodump --archive=/tmp/dump.archive

docker cp $container_name_sunset:/tmp/dump.archive ./dump.archive

docker cp ./dump.archive $container_name_sunrise:/tmp/dump.archive

docker exec $container_name_sunrise mongorestore --drop --archive=/tmp/dump.archive

docker exec $container_name_sunset rm /tmp/dump.archive
docker exec $container_name_sunrise rm /tmp/dump.archive
rm ./dump.archive
