#!/bin/bash
# take input from bash execute.sh -c 100 -b "1 2 3 4 5 6 7 8 9 10"
valid=1
while [[ "$#" -gt 0 ]]; do
    case $1 in
        -c|--option1)
            option1="$2"
            shift
            ;;
        -b|--option2)
            option2=()
            shift
            while [[ ! $1 =~ ^- && "$#" -gt 0 ]]; do
                value="${1//\'/}"
                # echo "Value:$value"
                option2=("${option2[@]}" "$value")
                # echo "List: ${option2[@]}"
                shift
            done
            ;;
        *)
            echo "Unknown parameter: $1"
            valid=0
            ;;
    esac
    shift
done

#if valid, check if option1 and option2 are empty
if [ "$valid" = 1 ]; then
    if [[ -z "$option1" ]]; then
        echo "Option 1 is empty"
        valid=0
    fi
    if [ "$valid" = 1 ]; then
        if [[ -z "$option2" ]]; then
            echo 0
            valid=0
        fi
    fi
fi
# echo "Option 1 (-c): $option1"
# echo "Option 2 (-b): ${option2[@]}"


#if valid, do the below
if [ "$valid" = 1 ]; then
    # Sort the list in option2
    sorted_list=($(echo ${option2[@]} | tr ' ' '\n' | sort -nr | tr '\n' ' '))

    # echo "Sorted list: ${sorted_list[@]}"

    count=0
    #get first element of sorted list
    while (( $option1 > 0 )); do
        # echo "sorted list: ${sorted_list[@]}"
        # echo "option1: $option1"
        # echo "count: $count"
        if [ ${#sorted_list[@]} -eq 0 ]; then
            break
        fi
        if (( option1 >= ${sorted_list[0]} )); then
            
            # echo "Sorted list: ${sorted_list[@]}"
            count=$(($count+1))
            option1=$(($option1-${sorted_list[0]}))
            # echo "Option 1: $option1"
            new_sorted_list=()
            for ((i = 1; i < ${#sorted_list[@]}; i++)); do
                new_sorted_list=("${new_sorted_list[@]}" "${sorted_list[$i]}")
            done
            sorted_list=("${new_sorted_list[@]}")
        else
            new_sorted_list=()
            for ((i = 1; i < ${#sorted_list[@]}; i++)); do
                new_sorted_list=("${new_sorted_list[@]}" "${sorted_list[$i]}")
            done
            sorted_list=("${new_sorted_list[@]}")
        fi
    done

    echo $count
fi