#!/bin/bash

# Store all the arguments as a single string
args="$@"


#!/bin/bash

# Your input string
# input_string="-c 62 -b '2 1'"

# Extract the value after "-c" (assuming it's always followed by a number)
catapults=$(echo "$args" | grep -oP '\-c \K\d+')

# Extract the value after "-b" (assuming it's enclosed in single quotes)
battalions=$(echo "$args" | grep -oP '\-b '\''\K[^\047]*')





IFS=' ' read -r -a battalion_array <<< "$battalions"
unset IFS
IFS=$'\n' battalion_array_sort=($(sort -nr <<<"${battalion_array[*]}"))
unset IFS

destroyed=0

while [ "$catapults" -gt 0 ] && [ ${#battalion_array_sort[@]} -gt 0 ]; do
  battalion=${battalion_array_sort[0]}

  if [ "$catapults" -ge "$battalion" ]; then
    catapults=$((catapults - battalion))
    destroyed=$((destroyed + 1))
  elif [ ${#battalion_array_sort[@]} -eq 1 ]; then
    break
  fi

  battalion_array_sort=("${battalion_array_sort[@]:1}") 
done

echo "$destroyed"


