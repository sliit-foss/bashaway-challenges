#!/bin/bash

# Initialize an empty array
arg=()

# Initialize catapults variable
catapults=""

# Loop over all arguments
for arg_val in "$@"
do
    # If the argument is '-b', the next one is the target
    if [[ $arg_val == "-b" ]] ; then
        b_next=true
    elif [[ $arg_val == "-c" ]] ; then
        c_next=true
    elif [[ $b_next ]] ; then
        # Remove apostrophes from the argument
        arg_val=${arg_val//\'/}
        # echo "Argument b: $arg_val"
        
        # Split the argument into an array using space as a delimiter
        IFS=' ' read -r -a arr <<< "$arg_val"
        
        # Add each element of arr to arg
        for i in "${arr[@]}"
        do
            arg+=("$i")
        done
        
        b_next=false
    elif [[ $c_next ]] ; then
        # Ensure that catapults is an integer
        if [[ $arg_val =~ ^[0-9]+$ ]] ; then
            catapults=$arg_val
            # echo "Argument c: $catapults"
            c_next=false
        else
            echo "Error: Argument c must be an integer."
            exit 1
        fi
    fi
done


destroyed=0

while [ $catapults -gt 0 ] && [ ${#arg[@]} -gt 0 ]; do
    # Find the battalion with the highest catapult requirement but within the available catapult limit
    battalion_to_destroy=-1
    for idx in "${!arg[@]}"; do
        if [ ${arg[$idx]} -le $catapults ] && ( [ $battalion_to_destroy -eq -1 ] || [ ${arg[$idx]} -gt ${arg[$battalion_to_destroy]} ] ); then
            battalion_to_destroy=$idx
        fi
    done
    
    # If no such battalion is found, break out of the loop
    if [ $battalion_to_destroy -eq -1 ]; then
        break
    fi
    
    # Use catapults to destroy the battalion
    let catapults-=arg[$battalion_to_destroy]
    unset arg[$battalion_to_destroy]
    let destroyed+=1
done

echo $destroyed