sudo docker volume create vol
sudo docker run --name=seraphina -d  -v vol:/twilight alpine:3.14 sleep infinity

sudo docker exec seraphina /bin/sh -c "echo \"$(cat /proc/sys/kernel/random/uuid)\" >> /home/potions.txt"

# Write your code here
sudo docker run --name=isabella -d  -v vol:/twilight alpine:3.14 sleep infinity
# Copy potions.txt from seraphina to host
sudo docker cp seraphina:/home/potions.txt ./potions.txt
# Copy from host to isabella
sudo docker cp ./potions.txt isabella:/home/potions.txt

# sudo docker exec seraphina apk add rsync

# # Install rsync in the isabella container
# sudo docker exec isabella apk add rsync

# # Create /twilight directory in the seraphina container
# sudo docker exec seraphina mkdir /twilight

# # Create /twilight directory in the isabella container
# sudo docker exec isabella mkdir /twilight

# sudo docker network create supernatural_network

# # add to network
# sudo docker network connect supernatural_network seraphina
# sudo docker network connect supernatural_network isabella

# # get ip address of seraphina and store it in a variable
# sera_ip=$(sudo docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' seraphina)

# # get ip address of isabella and store it in a variable
# isa_ip=$(sudo docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' isabella)

# # rsync sera_ip:/home/potions.txt to isa_ip:/twilight/potions.txt
# sudo docker exec seraphina rsync /twilight $isa_ip:/twilight