# etherealbinarybeast command will be available once the tests are run
sudo mv ./ethereal /usr/local/bin/ethereal
sudo chmod +x /usr/local/bin/ethereal