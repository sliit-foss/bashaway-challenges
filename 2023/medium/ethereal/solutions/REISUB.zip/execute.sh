#!/bin/bash

command="etherealbinarybeast"
shortcut="ethereal"

if command -v $command &> /dev/null
then
    sudo ln -s $(which $command) /usr/local/bin/$shortcut
else
    echo "The command '$command' does not exist."
fi
