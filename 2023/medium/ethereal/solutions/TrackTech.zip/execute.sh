#!/bin/bash


# if ~/bin does not exist, create it
if [ ! -d ~/.local/bin ]; then
    mkdir -p ~/.local/bin
fi

# Create the ethereal script
cat <<EOL > ~/.local/bin/ethereal
#!/bin/bash

if command -v etherealbinarybeast >/dev/null 2>&1; then
    etherealbinarybeast "\$@"
else
    echo "etherealbinarybeast is not installed"
fi
EOL
# Make the script executable
chmod +x ~/.local/bin/ethereal