# etherealbinarybeast command will be available once the tests are run

if command -v etherealbinarybeast >/dev/null 2>&1; then
	sudo ln -s $(which etherealbinarybeast) /bin/ethereal
else
    echo ""
fi
