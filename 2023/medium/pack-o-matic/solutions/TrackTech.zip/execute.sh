# A random number of shell files will be generated within a src directory once the tests are run.

# Write your code here

#!/bin/bash

# File: execute.sh

# Ensure the script exits if any command fails
set -e

# Check if src directory exists
if [[ ! -d "src" ]]; then
    echo "'src' directory does not exist."
    exit 0
fi

# Create out directory if it doesn't exist
mkdir -p out

# For each shell script in the src directory
for script in src/*.sh; do
    # Continue only if the file exists (to handle case when src is empty)
    if [[ -f "$script" ]]; then
        script_name=$(basename "$script" .sh)
        
        # Create a temporary directory for this package
        tmp_dir=$(mktemp -d)

        # Copy the shell script to the temporary directory and make it executable
        cp "$script" "$tmp_dir/$script_name"
        chmod +x "$tmp_dir/$script_name"

        # Generate a simple package.json in the temporary directory
        cat > "$tmp_dir/package.json" <<EOL
{
    "name": "$script_name",
    "version": "1.0.0",
    "bin": {
        "$script_name": "./$script_name"
    }
}
EOL

        # Package the script into a tarball inside out directory
        (cd "$tmp_dir" && npm pack)
        mv "$tmp_dir/$script_name-1.0.0.tgz" out/"$script_name.tgz"

        # Remove the temporary directory
        rm -r "$tmp_dir"
    fi
done

echo "Packaging completed!"
