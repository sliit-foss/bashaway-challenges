#!/bin/bash

# Set the Redis server host, port, and password
REDIS_HOST="localhost"
REDIS_PORT="6380"
REDIS_USERNAME="default"
REDIS_PASSWORD='5ax4*1$2'
REDIS_URI="redis://$REDIS_USERNAME:$REDIS_PASSWORD@$REDIS_HOST:$REDIS_PORT"

# Number of keys to add
NUM_KEYS=499

# sudo apt-get install -y redis-tools redis-server

curl https://packages.redis.io/gpg | sudo apt-key add -
echo "deb https://packages.redis.io/deb $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/redis.list
sudo apt-get update -y
sudo apt-get install redis -y

# Change the Redis port to 6380 in the configuration file
sudo sed -i 's/port 6379/port 6380/' /etc/redis/redis.conf

# Restart the Redis server to apply the configuration changes
sudo systemctl restart redis-server

echo "Redis server is installed and configured to run on port 6380."

redis-cli -u $REDIS_URI PING

# Loop to generate and set random keys
for ((i = 1; i <= NUM_KEYS; i++)); do
  # Generate a random key using openssl
  RANDOM_KEY=$(openssl rand -hex 16)

  # Generate a random value (you can modify this as needed)
  RANDOM_VALUE="value_$i"

  # Use redis-cli to set the key-value pair with the password
  redis-cli -u $REDIS_URI  SET "$RANDOM_KEY" "$RANDOM_VALUE"
  
  # Check if the set operation was successful
  if [ $? -eq 0 ]; then
    echo "Key '$RANDOM_KEY' set to '$RANDOM_VALUE' successfully."
  else
    echo "Failed to set key '$RANDOM_KEY'."
  fi
done

# Add a timestamp in epoch format as the value for 'bashaway-2k23'
TIMESTAMP=$(($(date +%s%N)/1000000))  # Get the current Unix timestamp in epoch format
redis-cli -u $REDIS_URI SET "bashaway-2k23" "$TIMESTAMP"
echo "Key 'bashaway-2k23' set to timestamp '$TIMESTAMP' successfully."
