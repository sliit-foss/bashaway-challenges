docker pull mongo:latest

if [ ! "$(docker ps -a | grep bashaway-2k23-cluttered)" ]; then
    docker run -d --name bashaway-2k23-cluttered -p 27207:27017 mongo
fi

# Data will be populated into the above database instance once the tests are run.

# Write your code here
#!/bin/bash

# sudo apt-get install mongodb-clients -y
sudo apt-get update
sudo apt-get install -y mongodb-clients


# Define MongoDB parameters
MONGO_DB="bashaway-2k23-cluttered"
MONGO_HOST="localhost"
MONGO_PORT="27207"

# Connect to the MongoDB docker instance
mongo $MONGO_DB --host $MONGO_HOST --port $MONGO_PORT <<EOF
    // Get list of collections
    var collections = db.getCollectionNames();

    // Iterate over each collection
    for (var i = 0; i < collections.length; i++) {
        // If the collection is not "settings", drop it
        if (collections[i] !== "settings") {
            db[collections[i]].drop();
        }
    }
EOF
