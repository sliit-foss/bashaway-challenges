#!/bin/bash

# Pull the latest MongoDB image if not already present
docker pull mongo:latest

# Check if the MongoDB container with the desired name exists
if [ ! "$(docker ps -a | grep bashaway-2k23-cluttered)" ]; then
    # Create and run the MongoDB container
    docker run -d --name bashaway-2k23-cluttered -p 27207:27017 mongo
fi

# Wait for MongoDB to start (adjust the sleep time as needed)
sleep 10

# MongoDB connection details
MONGODB_HOST="localhost"
MONGODB_PORT="27207"
MONGODB_DATABASE="bashaway-2k23-cluttered"

# MongoDB username and password if applicable
MONGODB_USERNAME=""
MONGODB_PASSWORD=""

# Define collections to exclude from deletion
EXCLUDED_COLLECTIONS=("settings")

# Function to remove collections except the excluded ones
remove_collections() {
    for collection in $(mongo "$MONGODB_HOST:$MONGODB_PORT/$MONGODB_DATABASE" \
        --quiet --eval "db.getCollectionNames()" | jq -r '.[]'); do
        if [[ ! " ${EXCLUDED_COLLECTIONS[@]} " =~ " $collection " ]]; then
            echo "Dropping collection: $collection"
            mongo "$MONGODB_HOST:$MONGODB_PORT/$MONGODB_DATABASE" \
                --quiet --eval "db.getCollection('$collection').drop()"
        fi
    done
}

# Execute the function to remove collections
remove_collections

echo "Database cleanup completed."
