#!/usr/bin/env bash
#Waga na wa 5H4D0W

set -e
set -u
set -o pipefail

docker pull mongo:latest

if [ ! "$(docker ps -a | grep bashaway-2k23-cluttered)" ]; then
    docker run -d --name bashaway-2k23-cluttered -p 27207:27017 mongo
fi

# Data will be populated into the above database instance once the tests are run.

while ! docker exec bashaway-2k23-cluttered mongosh bashaway-2k23-cluttered --quiet --eval "show collections"; do
    sleep 1
done;

# Write your code here
IFS=
docker exec bashaway-2k23-cluttered mongosh bashaway-2k23-cluttered --quiet --eval "show collections" | while read -r collection; do
    if [[ "$collection" =~ ^settings$ ]]; then 
        continue 
    fi
	
	if [[ ! -n "$collection" ]]; then 
        continue 
    fi

    docker exec bashaway-2k23-cluttered mongosh bashaway-2k23-cluttered --quiet --eval "db.getCollection('"$collection"').drop()" 2>&1 /dev/null
done
