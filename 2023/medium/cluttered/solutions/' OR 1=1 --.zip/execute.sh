docker pull mongo:latest
docker run -d --name bashaway-2k23-cluttered -p 27207:27017 mongo
sleep 5

# Data will be populated into the above database instance once the tests are run.

# Write your code here
docker exec bashaway-2k23-cluttered mongosh --eval 'db.getCollectionNames().forEach(function(collection) { if (collection !== "settings") db[collection].drop() });' bashaway-2k23-cluttered
