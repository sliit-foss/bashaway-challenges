# Create the out directory if it doesn't exist
mkdir -p out

# Loop through all files in the src directory
for file in src/*; do
    # Check if the file is an image (you can adjust the file types as needed)
    if [[ -f "$file" && "$file" =~ \.(jpg|jpeg|png|gif)$ ]]; then
        # Get the filename without the path
        filename=$(basename "$file")
        
        # Resize the image to 4x and save it to the out directory
        convert "$file" -resize 400% "out/$filename"
        
        echo "Resized $filename and saved to out directory."
    fi
done

echo "All images resized and saved to the out directory."
