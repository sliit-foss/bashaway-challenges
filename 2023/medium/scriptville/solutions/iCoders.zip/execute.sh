#!/bin/bash

src_dir="src"
out_dir="out"

if [ ! -d "$src_dir" ]; then
  exit 0
fi

if [ -z "$(ls -A "$src_dir")" ]; then
  exit 0
fi

mkdir -p "$out_dir"

find "$src_dir" -type f -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.gif" -o -iname "*.bmp" | while read -r image; do
  filename=$(basename "$image")

  convert "$image" -resize 400% "$out_dir/$filename"
done

