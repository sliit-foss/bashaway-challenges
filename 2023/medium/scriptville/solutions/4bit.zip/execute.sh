#!/bin/bash

# Source and output directories
src_dir="src"
out_dir="out"

# Check if the source directory exists
if [ ! -d "$src_dir" ]; then
  echo "Source directory '$src_dir' not found. Exiting with code 0."
  exit 0
fi

# Check if the source directory is empty
if [ -z "$(ls -A "$src_dir")" ]; then
  echo "Source directory '$src_dir' is empty. Exiting with code 0."
  exit 0
fi

# Create the output directory if it doesn't exist
mkdir -p "$out_dir"

# Search for image files in the source directory
find "$src_dir" -type f -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.gif" -o -iname "*.bmp" | while read -r image; do
  # Get the filename without the path
  filename=$(basename "$image")

  # Resize the image by a factor of 4 and save it to the output directory
  convert "$image" -resize 400% "$out_dir/$filename"
  echo "Resized: $filename"
done

echo "Processing completed."
