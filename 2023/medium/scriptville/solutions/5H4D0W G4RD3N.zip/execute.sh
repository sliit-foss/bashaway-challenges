#!/bin/bash

sudo apt-get update -qq
sudo apt-get install -y -qq imagemagick

if [[ ! -d out ]]
then
    mkdir out
fi

if [[ ! -d src ]]
then
    exit 0
fi

mkdir out/src

find "src" -type f | while read -r file
do
    convert -resize 400% $file out/$file
done

mv out/src/* out/

rm -r out/src