mkdir out
base=../out/


cd src
for image in `ls *.jpg`; do
  echo $image
  size=$(identify -format "%wx%h" ${image})
  w=$(awk -F'x' '{ print $1}' <<< $size)
  h=$(awk -F'x' '{ print $2}' <<< $size)
  w=$(( w*4 ))
  h=$(( h*4 ))
  res=$w'x'$h

  echo $size
  echo $res


  basename=`echo $image | sed "s/.jpg//"`
  convert -resize $res $image ${base}${basename}.jpg
  ls -ltr | tail -1
done