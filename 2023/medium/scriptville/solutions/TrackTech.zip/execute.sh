#!/bin/bash

# install imagemagick if not installed
if ! [ -x "$(command -v convert)" ]; then
  sudo apt-get install imagemagick
fi

mkdir out

# if no src exit
if [ ! -d src ]; then
  exit 0
fi

# if src empty exit
if [ -z "$(ls -A src)" ]; then
  exit 0
fi

# for each image in the src directory, resize to 4x larger into out directory
for f in src/*; do
  convert $f -resize 400% out/$(basename $f)
done
