#!/bin/bash

# Check if the "src" directory exists, or create it if it doesn't
src_directory="src"
out_directory="out"

# if [ ! -d "$src_directory" ]; then
#   echo "The 'src' directory does not exist or is empty."
#   exit 1
# fi

# Check if ImageMagick is installed, and if not, try to install it
if ! command -v convert &> /dev/null; then
  echo "ImageMagick is not installed. Attempting to install..."
  
  # Check for the package manager and install ImageMagick
  if command -v apt-get &> /dev/null; then
    sudo apt-get -y install imagemagick
  elif command -v yum &> /dev/null; then
    sudo yum -y install ImageMagick
  elif command -v brew &> /dev/null; then
    brew install imagemagick
  else
    echo "ImageMagick installation failed. Please install ImageMagick manually."
    exit 1
  fi
fi

# Create the "out" directory if it doesn't exist
if [ ! -d "$out_directory" ]; then
  mkdir "$out_directory"
fi

# Iterate through each image in the "src" directory and resize it
for src_image in "$src_directory"/*; do
  if [ -f "$src_image" ]; then
    # Get the filename without the path
    filename=$(basename "$src_image")
    
    # Resize the image by a factor of 4 and save it to the "out" directory
    convert "$src_image" -resize 400% "$out_directory/$filename"
    
    echo "Resized $filename and saved to $out_directory"
  fi
done

echo "Image resizing complete."
