#!/bin/bash

# Define the source and output folders
src_folder="src"
out_folder="out"

# Create the output folder if it doesn't exist
mkdir -p "$out_folder"

# Use the find command to locate image files in the source folder
find "$src_folder" -type f -name "*.jpg" -o -name "*.jpeg" -o -name "*.png" -o -name "*.gif" | while read -r img; do
    # Define the new file name in the output folder
    new_img="$out_folder/$(basename "$img")"

    # Use the convert command to resize the image and save it in the output folder
    convert "$img" -resize 400% "$new_img"
done

echo "Image resizing and saving complete."
