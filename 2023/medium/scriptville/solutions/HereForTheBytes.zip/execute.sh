#!/bin/bash
# sudo apt-get update -y
# sudo apt-get install imagemagick -y

if [ ! -d "src" ] || [ -z "$(ls -A src)" ]; then
    exit 0
fi

mkdir -p out

for file in src/*; do
    filename=$(basename "$file")
    convert "./src/$filename" -resize 400% "./out/$filename"
done