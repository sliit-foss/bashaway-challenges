docker network create bashaway-2k23

docker compose up -d

sleep 60