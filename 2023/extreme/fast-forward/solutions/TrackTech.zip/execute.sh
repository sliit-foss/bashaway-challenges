rm -rf src

git clone https://github.com/sliit-foss/npm-catalogue.git src

wget https://raw.githubusercontent.com/newren/git-filter-repo/main/git-filter-repo

cd src

echo "def handle(commit):" > ../change_time.py
echo "    date_str = commit.committer_date.decode('utf-8')" >> ../change_time.py
echo "    [seconds, timezone] = date_str.split()" >> ../change_time.py
echo "    new_date = f'{str(int(seconds)+1123200)} {timezone}'" >> ../change_time.py
echo "    commit.committer_date = new_date.encode('utf-8')" >> ../change_time.py
echo "    commit.author_date = new_date.encode('utf-8')" >> ../change_time.py
echo "" >> ../change_time.py
echo "handle(commit)" >> ../change_time.py
echo "" >> ../change_time.py

python3 ../git-filter-repo --commit-callback "$(cat ../change_time.py)"

cd ..
rm git-filter-repo
rm change_time.py

echo "Done"