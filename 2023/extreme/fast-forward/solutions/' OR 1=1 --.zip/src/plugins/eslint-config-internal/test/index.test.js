describe("eslint-config-internal", () => {
  it("should work", () => {
    expect(true).toBe(true);
  });
});
