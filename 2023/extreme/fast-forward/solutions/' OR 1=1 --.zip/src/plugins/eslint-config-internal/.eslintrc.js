module.exports = {
  extends: "./src/index.js"
};
