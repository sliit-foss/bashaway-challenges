# @sliit-foss/eslint-config-internal

> Custom ESLint config for SLIIT FOSS

## Install

Using npm:

```sh
npm install --save-dev @sliit-foss/eslint-config-internal
```

or using yarn:

```sh
yarn add @sliit-foss/eslint-config-internal --dev
```
