describe("babel-plugin-transform-trace", () => {
  it("should work", () => {
    expect(true).toBe(true);
  });
});
