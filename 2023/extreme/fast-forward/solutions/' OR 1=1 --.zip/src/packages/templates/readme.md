# @sliit-foss/templates

### A simple template generator which can be invoked via the CLI

<br/>

## Installation

```bash
# using npm
npm install -g @sliit-foss/templates

# using yarn
yarn global add @sliit-foss/templates
```

## Usage

- Execute the following command in your terminal to see a list of available options

```bash
sft
```
