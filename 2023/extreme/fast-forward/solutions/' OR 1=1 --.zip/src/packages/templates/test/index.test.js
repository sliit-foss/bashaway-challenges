beforeEach(() => {
  jest.clearAllMocks();
});

describe("template-generator", () => {
  it("should work", () => {
    expect(true).toBe(true);
  });
});
