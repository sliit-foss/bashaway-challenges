describe("automatic-versioning", () => {
  it("should work", () => {
    expect(true).toBe(true);
  });
});
