rm -rf src

git clone https://github.com/sliit-foss/npm-catalogue.git src

# Write your code here