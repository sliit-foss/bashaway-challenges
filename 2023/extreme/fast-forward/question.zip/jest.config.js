module.exports = {
    modulePathIgnorePatterns: [
        '.*/out/'
    ],
    testPathIgnorePatterns: ['.*/node_modules/', '.*/src/', '.*/out/'],
    maxWorkers: 1
};
