#!/bin/bash
docker-compose up -d
sleep 70
while true
do
    docker exec -i kafka kafka-console-producer.sh --broker-list localhost:9092 --topic SOS --property "parse.key=true" --property "key.separator=:" < msg.txt
done &