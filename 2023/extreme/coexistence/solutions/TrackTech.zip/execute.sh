# Start Install Google Chrome (You may comment out these lines during local testing if you already have Chrome installed)

sudo apt update

wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo dpkg -i google-chrome-stable_current_amd64.deb

sudo apt-get install -f

rm google-chrome-stable_current_amd64.deb

# End Install Google Chrome

sudo apt install nginx
sudo ufw allow 'Nginx HTTP'

# Write your code here

cd src
cd cornerstone && npm install && npm run build
cd ..
cd dashboard && npm install && npm run build
cd ..
cd support && npm install && npm run build
cd ../..

rm -f src/support/node_modules/damerau-levenshtein/scripts/update-changelog.sh

cp -r src/cornerstone/dist src/build
cp -r src/dashboard/build src/build/dashboard
cp -r src/support/out src/build/support
cp -r src/build/support/_next src/build/_next
sudo cp -r src/build/* /var/www/html
rm -rf src/build

echo eshans kubernetes cluster is deploying
ls

# echo and create nginx config file for reverse proxy from localhost:8088 to the three servers
echo "server {
    listen 8088;
    server_name localhost;

    root /var/www/html;

    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # location /support {
    #     proxy_pass http://localhost:80/support/;
    # }
    # location / {
    #     proxy_pass http://localhost:80/;
    # }
}" | sudo tee /etc/nginx/sites-available/default

# restart nginx
sudo systemctl restart nginx