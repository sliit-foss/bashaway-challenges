# Start Install Google Chrome (You may comment out these lines during local testing if you already have Chrome installed)

sudo apt update

wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo dpkg -i google-chrome-stable_current_amd64.deb

sudo apt-get install -f

rm google-chrome-stable_current_amd64.deb

# End Install Google Chrome

wget https://edgedl.me.gvt1.com/edgedl/chrome/chrome-for-testing/118.0.5993.70/linux64/chromedriver-linux64.zip
unzip chromedriver-linux64.zip
sudo mv -f chromedriver-linux64/chromedriver /usr/bin/chromedriver
# !sudo chown root:root /usr/bin/chromedriver
sudo chmod +x /usr/bin/chromedriver

rm -rf chromedriver-linux64 chromedriver-linux64.zip


# Write your code here

cd src 

cd cornerstone
pnpm i
pnpm build

cd ../dashboard
pnpm i 
pnpm build
cp -r build ../cornerstone/dist/dashboard

cd ../support

sed -i 's/"title"/"title" style={{fontSize:"60px", color:"rgba(0, 0, 0, 1)"}} /' ./src/app/page.tsx
sed -i 's/"home-btn"/"home-btn" style={{fontSize:"20px" , backgroundColor:"rgba(0, 0, 0, 1)"}} /' ./src/app/page.tsx

pnpm i
pnpm build
cp -r out ../cornerstone/dist/support

cd ../cornerstone
pnpm preview --port 8088 &

