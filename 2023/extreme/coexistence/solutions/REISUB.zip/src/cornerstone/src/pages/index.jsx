export { default as NotFound } from "./404";
export { default as Home } from "./home";