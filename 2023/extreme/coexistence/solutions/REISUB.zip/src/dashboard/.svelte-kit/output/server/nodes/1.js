

export const index = 1;
export const component = async () => (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.364825b4.js","_app/immutable/chunks/scheduler.e108d1fd.js","_app/immutable/chunks/index.7e6a41e6.js","_app/immutable/chunks/singletons.d523d9d7.js"];
export const stylesheets = [];
export const fonts = [];
