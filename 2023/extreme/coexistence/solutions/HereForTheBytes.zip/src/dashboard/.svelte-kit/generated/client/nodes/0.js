import * as universal from "../../../../src/routes/+layout.js";
export { universal };
export { default as component } from "../../../../node_modules/.pnpm/@sveltejs+kit@1.20.4_svelte@4.0.5_vite@4.4.2/node_modules/@sveltejs/kit/src/runtime/components/layout.svelte";