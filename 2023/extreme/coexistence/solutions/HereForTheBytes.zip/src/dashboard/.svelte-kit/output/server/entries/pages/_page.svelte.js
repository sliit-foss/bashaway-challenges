import { c as create_ssr_component } from "../../chunks/ssr.js";
const styles = "";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${$$result.head += `<!-- HEAD_svelte-t9xcep_START -->${$$result.title = `<title>Dashboard</title>`, ""}<!-- HEAD_svelte-t9xcep_END -->`, ""} <div class="h-[100vh] w-screen flex flex-col justify-center items-center relative z-50" data-svelte-h="svelte-1mhdx6r"><svg xmlns="http://www.w3.org/2000/svg" width="150" height="150" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-layout-dashboard"><rect width="7" height="9" x="3" y="3" rx="1"></rect><rect width="7" height="5" x="14" y="3" rx="1"></rect><rect width="7" height="9" x="14" y="12" rx="1"></rect><rect width="7" height="5" x="3" y="16" rx="1"></rect></svg> <h1 class="text-black text-6xl font-bold mt-10 mb-4">Dashboard</h1> <a id="home-btn" href="/" class="flex justify-center items-center cursor-pointer rounded-full font-semibold outline-none splash bg-black text-white transition-all duration-medium gap-2 px-6 py-2.5 text-[20px] mt-10 min-w-[150px]">Back to Home</a></div>`;
});
export {
  Page as default
};
