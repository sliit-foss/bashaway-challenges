

export const index = 2;
export const component = async () => (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.b0ee6910.js","_app/immutable/chunks/scheduler.e108d1fd.js","_app/immutable/chunks/index.7e6a41e6.js"];
export const stylesheets = ["_app/immutable/assets/2.51abe33f.css"];
export const fonts = [];
