# Start Install Google Chrome (You may comment out these lines during local testing if you already have Chrome installed)

sudo apt update

wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo dpkg -i google-chrome-stable_current_amd64.deb

sudo apt-get install -f

rm google-chrome-stable_current_amd64.deb

# End Install Google Chrome

# Write your code here

cd src/cornerstone/
pnpm i
pnpm build
pnpm preview --host &>/dev/null &
cd ../dashboard/
pnpm i
pnpm build
pnpm preview --host &>/dev/null &
cd ../support/
pnpm i
pnpm build
sudo mkdir -p /var/www/support
sudo cp -r ./out /var/www/support
sudo mv ../../Default /etc/nginx/sites-available/default
sudo mv ../../def /etc/nginx/sites-available/def
sudo ln -s /etc/nginx/sites-available/def /etc/nginx/sites-enabled/
sudo nginx

