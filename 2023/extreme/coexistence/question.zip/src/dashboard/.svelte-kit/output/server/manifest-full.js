export const manifest = {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.svg","payhere.js","robots.txt"]),
	mimeTypes: {".svg":"image/svg+xml",".js":"application/javascript",".txt":"text/plain"},
	_: {
		client: {"start":"_app/immutable/entry/start.dfacd7fc.js","app":"_app/immutable/entry/app.bb23cf78.js","imports":["_app/immutable/entry/start.dfacd7fc.js","_app/immutable/chunks/scheduler.e108d1fd.js","_app/immutable/chunks/singletons.d523d9d7.js","_app/immutable/entry/app.bb23cf78.js","_app/immutable/chunks/scheduler.e108d1fd.js","_app/immutable/chunks/index.7e6a41e6.js"],"stylesheets":[],"fonts":[]},
		nodes: [
			() => import('./nodes/0.js'),
			() => import('./nodes/1.js'),
			() => import('./nodes/2.js')
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		}
	}
};
